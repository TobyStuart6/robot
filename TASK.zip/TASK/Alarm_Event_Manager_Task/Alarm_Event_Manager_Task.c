#include "Alarm_Event_Manager_Task.h"

static uint8_t read_Dnmotor_err1[8] = {0x40, 0x88, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00};
static uint8_t read_Dnmotor_err2[8] = {0x40, 0x89, 0x30, 0x00, 0x00, 0x00, 0x00, 0x00};
// extern const uint8_t Enable_Motor[8];   //ʹ�ܵ��
uint16_t Motor_fault_cnt = 0;																  // ����������
static uint8_t Read_R_motor_temp_value[8] = {0x40, 0x1B, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00}; // ��ȡ��챵���¶�
static uint8_t Read_L_motor_temp_value[8] = {0x40, 0x1B, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00}; // ��ȡ��챵���¶�
uint8_t inquire_DN_cur[8] = {0x40, 0x84, 0x30, 0x01, 0, 0, 0, 0};							  // ��ѯ���ܿ��Ƶĵ���ĵ���ֵ
// ��ѯ�Ƹ˵��״̬
static uint8_t Read_main_push[8] = {0x20,0x0c,0xec,0x00,0x00,0x00,0x55,0x66}; //��ȡ���ƴ�����
static uint8_t Read_side_push[8] = {0x21,0x0c,0xec,0x00,0x00,0x00,0x55,0x66}; //��ȡ���ƴ�����
extern const uint8_t M_Eable_Motor[8]; // ʹ�ܵ��
Cleaning_Motor_Error_ Cleaning_Motor_Error = {0};
uint8_t cleaning_motor_err_id = 0;
uint8_t err_times = 0;
cleaning_motor_protect_ mo_pro;
MotorStatus_t Left_Brush_MotorStatus ={0};
MotorStatus_t Right_Brush_MotorStatus={0};
MotorStatus_t Main_Brush_MotorStatus={0};
MotorStatus_t Fan_MotorStatus={0};
MotorStatus_t SidePush_MotorStatus ={0};
MotorStatus_t MainPush_MotorStatus ={0};
static uint8_t motor_time = 0;

void Alarm_Event_Manager_Task(void const *argument)
{
	delay_ms(3000);
	uint32_t notify_val = 0;
#if (Machine_model == SW55 || Machine_model == SW55L)
	mo_pro.cleaning_br_L_limit_current = 10;
	mo_pro.cleaning_br_R_limit_current = 10;
	mo_pro.cleaning_main_br_limit_current = 10;
	mo_pro.cleaning_vacuumfan_limit_current = 10;
	mo_pro.limit_time = 4;
#elif (Machine_model == SW80)
	mo_pro.cleaning_br_L_limit_current = 50;
	mo_pro.cleaning_br_R_limit_current = 4;
	mo_pro.cleaning_main_br_limit_current = 16;
	mo_pro.cleaning_vacuumfan_limit_current = 30;
	mo_pro.limit_time = 4;
#endif

	my_memcpy(&mo_pro, &param[3], 5);
	printf("��������������%d,%d,%d,%d,%d\r\n", mo_pro.cleaning_br_L_limit_current, mo_pro.cleaning_br_R_limit_current, mo_pro.cleaning_main_br_limit_current, mo_pro.cleaning_vacuumfan_limit_current, mo_pro.limit_time);
	memcpy(upload_data, &mo_pro, 5);
	//	printf("��������������%d,%d,%d,%d,%d\r\n",param[3],param[4],param[5],param[6],param[7]);
//	uint8_t inq_clean_mor_err = 0; // ����������ѯ����3088��3089�������ı�־λ
	osEvent Reset_Stop_Event;
	while (1)
	{
		MY_ERROR.tasks_heart.alarm = 0;
		//		if((Motor_fault_code.Left != 0)&&(Motor_fault_cnt<1000))
		//		{
		//			printf("Motor_fault_code.Left = %d\r\n",Motor_fault_code.Left);
		//            xTaskNotify(Motor_Task_Handle,Clean_Motor_eor_l,eSetBits);
		//			delay_ms(1000);
		//            xTaskNotify(Motor_Task_Handle,Motor_Enable,eSetBits);
		//            xTaskNotifyWait(0,Motor_Disable,&notify_val,0);
		//			Motor_fault_code.Left = 0;
		//			Motor_fault_cnt++;
		//		}
		//		else if((Motor_fault_code.Right != 0)&&(Motor_fault_cnt<1000))
		//		{
		//			printf("Motor_fault_code.Right = %d\r\n",Motor_fault_code.Right);
		//			xTaskNotify(Motor_Task_Handle,Clean_Motor_eor_r,eSetBits);
		//			delay_ms(1000);
		//            xTaskNotify(Motor_Task_Handle,Motor_Enable,eSetBits);
		//            xTaskNotifyWait(0,Motor_Disable,&notify_val,0);
		//			Motor_fault_code.Right = 0;
		//			Motor_fault_cnt++;
		//		}

		Reset_Stop_Event = osSignalWait(Clean_Motor_eor, 0);
		if ((Reset_Stop_Event.status == osEventSignal) && (Reset_Stop_Event.value.signals & Clean_Motor_eor))
		{
			printf("clean wheel motor error state 1\n");
			if (motor_info.Left_motor_error_code != 0)
				xTaskNotify(Motor_Task_Handle, Clean_Motor_eor_l, eSetBits);
			else if (motor_info.Right_motor_error_code != 0)
				xTaskNotify(Motor_Task_Handle, Clean_Motor_eor_r, eSetBits);
			else
				printf("no wheel motor error \n");

			delay_ms(1000);
			xTaskNotify(Motor_Task_Handle, Motor_Enable, eSetBits);
			xTaskNotifyWait(0, Motor_Disable, &notify_val, 0);
			xTaskNotify(Motor_Task_Handle, Read_Motor_eor, eSetBits);
		}

		if (Cleaning_Motor_Error.Code_Bits.BIT25 == 1 || Cleaning_Motor_Error.Code_Bits.BIT26 == 1 || Cleaning_Motor_Error.Code_Bits.BIT9 == 1)
		{
			err_times++;
			if (err_times > 5)
			{
				printf("��������\r\n");
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);
				delay_ms(2200);
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);
				Cleaning_Motor_Error.Code_Bits.BIT25 = 0;
				Cleaning_Motor_Error.Code_Bits.BIT26 = 0;
				Cleaning_Motor_Error.Code_Bits.BIT9 = 0;
				err_times = 0;
			}
		}

		// �ȴ���ѯָ��
		osSignalWait(require_motor_info, 400); /* �ȴ���ѯ��־λ,���500ms(���滹��100ms) */
		xTaskNotify(Motor_Task_Handle, Read_Motor_eor | Inquire_Motor_current, eSetBits);
//		inq_clean_mor_err++;
		//		if (inq_clean_mor_err % 2 == 0)//3088��3089�Ĵ������������ѯ
		//		{
		//			Can_Send_Msg(Cleaning_Motor_ID,read_Dnmotor_err1);//��ѯ���ܿ������������
		//		}
		//		else
		//		{
		//			Can_Send_Msg(Cleaning_Motor_ID,read_Dnmotor_err2);//��ѯ���ܿ������������
		//		}
		inquire_motor_info();
		//	motor_protect();
	}
}
void inquire_motor_info(void)
{

	for (int i = 1; i < 8; i++)
	{

		switch (i)
		{

		case 1:
			// #if(Machine_model == SW55)
			// inquire_DN_cur[3] = 0x01;//���ˢ
			//				Can_Send_Msg(Cleaning_Motor_ID,inquire_DN_cur);
			motor_time++;
			if (motor_time == 2)
			{ // ���ˢ
				memset(&Left_Brush_MotorStatus, 0, sizeof(Left_Brush_MotorStatus));
				cleaning_motor_check(leftBurshMotorID, &Left_Brush_MotorStatus);
				//				printf("Left_Brush_MotorStatus.phase_current_u=%d\r\n",Left_Brush_MotorStatus.phase_current_u);
				//				printf("Left_Brush_MotorStatus.run_error=%d\r\n",Left_Brush_MotorStatus.run_error);
				//				printf("Left_Brush_MotorStatus.current_voltage=%d\r\n",Left_Brush_MotorStatus.current_voltage);
				motor_info.Left_brush_current = Left_Brush_MotorStatus.phase_current_u / 1000;
			}

			break;

		case 2:
			// #elif(Machine_model == SW80)
			// inquire_DN_cur[3] = 0x02;//80���
			// Can_Send_Msg(Cleaning_Motor_ID,inquire_DN_cur);
			// #endif
			// ���
			if (motor_time == 4)
			{
				memset(&Fan_MotorStatus,0,sizeof(Fan_MotorStatus));
				cleaning_motor_check(fanMotorID,&Fan_MotorStatus);
				//				printf("Fan_MotorStatus.phase_current_u=%d\r\n",Fan_MotorStatus.phase_current_u);
				//				printf("Fan_MotorStatus.run_error=%d\r\n",Fan_MotorStatus.run_error);
				//				printf("Fan_MotorStatus.current_voltage=%d\r\n",Fan_MotorStatus.current_voltage);
				motor_info.Fan_current = Fan_MotorStatus.phase_current_u / 1000;
			}
			break;

		case 3:
			// inquire_DN_cur[3] = 0x03;//��ˢ
			//				Can_Send_Msg(Cleaning_Motor_ID,inquire_DN_cur);
			// ��ˢ
			if (motor_time == 6)
			{
				memset(&Main_Brush_MotorStatus,0,sizeof(Main_Brush_MotorStatus));
				cleaning_motor_check(mainBurshMotorID, &Main_Brush_MotorStatus);
				//				printf("Main_Brush_MotorStatus.phase_current_u=%d\r\n",Main_Brush_MotorStatus.phase_current_u);
				//				printf("Main_Brush_MotorStatus.run_error=%d\r\n",Main_Brush_MotorStatus.run_error);
				//				printf("Main_Brush_MotorStatus.current_voltage=%d\r\n",Main_Brush_MotorStatus.current_voltage);
				motor_info.Main_brush_current = Main_Brush_MotorStatus.phase_current_u / 1000;
			}
			break;

		case 4:
			//				inquire_DN_cur[3] = 0x04;//�ұ�ˢ
			//				Can_Send_Msg(Cleaning_Motor_ID,inquire_DN_cur);
			// �ұ�ˢ
			if (motor_time == 8)
			{
				memset(&Right_Brush_MotorStatus,0,sizeof(Right_Brush_MotorStatus));
				cleaning_motor_check(rightBurshMotorID, &Right_Brush_MotorStatus);
				//				printf("Right_Brush_MotorStatus.phase_current_u=%d\r\n",Right_Brush_MotorStatus.phase_current_u);
				//				printf("Right_Brush_MotorStatus.run_error=%d\r\n",Right_Brush_MotorStatus.run_error);
				//				printf("Right_Brush_MotorStatus.current_voltage=%d\r\n",Right_Brush_MotorStatus.current_voltage);
				motor_info.Right_brush_current = Right_Brush_MotorStatus.phase_current_u / 1000;
				uint16_t left_brush_err = Left_Brush_MotorStatus.run_error;
				uint16_t fan_err = Fan_MotorStatus.run_error;
				uint16_t main_brush_err = Main_Brush_MotorStatus.run_error;
				uint16_t right_brush_err = Right_Brush_MotorStatus.run_error;

				motor_info.Cleaning_motor_error_code1 = ((uint32_t)right_brush_err << 16) | left_brush_err;
				motor_info.Cleaning_motor_error_code2 = ((uint32_t)fan_err << 16) | main_brush_err;
				motor_time = 0;
			}
			break;

		case 5: // ����챵���¶�
			Can_Send_Msg(MOTOR_R_CAN_ID, Read_R_motor_temp_value);
			break;

		case 6: // ����챵���¶�
			Can_Send_Msg(MOTOR_L_CAN_ID, Read_L_motor_temp_value);
			break;

						case 7:
			// ��ˢ��ˢ�Ƹ˴�����
//			Can_Send_Msg(0xcc,Read_main_push);
//			Can_Send_Msg(0xcc,Read_side_push);
						break;

			//			case 8:
			
		
			//			break;
		}
		delay_ms(10);
	}
}
void cleaning_motor_check(uint8_t slaveAddr, MotorStatus_t *motorStatus)
{
	uint16_t regdata[2] = {0};
  uint16_t error_regs[2] = {0};
	static uint8_t err_debounce_cnt = 0; 
  static uint16_t last_potential_err = 0;
	
	if (MODBUS_OK == ModbusRTU_ReadInputRegisters(slaveAddr, 0x1004, 2, regdata))
	{
		// regdata[1] ���޷��ţ���Ҫת�� int16_t
		int16_t raw_value = (int16_t)regdata[1];
		// ȡ����ֵ
		motorStatus->phase_current_u = (uint16_t)abs(raw_value);
	}
	if (MODBUS_OK == ModbusRTU_ReadInputRegisters(slaveAddr, 0x1006, 2, error_regs))
	{
	  uint16_t err_high = error_regs[0]; // 0x1006
    uint16_t err_low  = error_regs[1]; // 0x1007
		if (err_high == 0)
    {
      if (err_high == 0)
    {
        uint16_t current_val = err_low;
        if (current_val != 0)
        {
            // ��������Ĵ��������һ�Ρ����ƴ���һ��
            if (current_val == last_potential_err)
            {
                err_debounce_cnt++;
                // ���� 3 �ζ���ͬһ�������룬�������ϱ�
                if (err_debounce_cnt >= 3)
                {
                    motorStatus->run_error = current_val;
                    err_debounce_cnt = 3; // �ⶥ
                }
            }
            else
            {
                // ����һ���µĴ����룬���ü�������ʼ��һ��ȷ��
                last_potential_err = current_val;
                err_debounce_cnt = 1;
            }
        }
        else
        {
            // ������ 0 (����)���Ҹ�λҲ�� 0
            // ����ѡ�������ָ�������Ҳ��һ��������ͨ�������ָ����ɡ�
            err_debounce_cnt = 0;
            last_potential_err = 0;
            motorStatus->run_error = 0;
        }
    }
    else
    {        
     printf("Modbus Noise Detected!\n");
    }
	 }
  }	
	if (MODBUS_OK == ModbusRTU_ReadInputRegisters(slaveAddr, 0x1008, 2, regdata))
	{
		motorStatus->current_voltage = regdata[1];
	}
}
void motor_protect()
{
	static uint32_t last_pro_time = 0;
	uint32_t time = HAL_GetTick();

	if (mo_pro.limit_flag > 0 && mo_pro.start_time != 0)
	{
		if (time - mo_pro.start_time > 1000 * mo_pro.limit_time && time - last_pro_time > 11000)
		{
			printf("%d,%d\n", time, mo_pro.start_time);
			// HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);//�������������
			motor_info.protect_err_code = mo_pro.limit_flag; // ���������ĵط��� motor_info.protect_err_code ��0
			if (mo_pro.limit_flag == 1)
				printf("���ˢ");
			else if (mo_pro.limit_flag == 2)
				printf("�ұ�ˢ");
			else if (mo_pro.limit_flag == 3)
				printf("��ˢ");
			else if (mo_pro.limit_flag == 4)
				printf("���");
			//	printf("�������ˣ��رմ��ܿ�����\r\n");
			last_pro_time = time;
		}
	}
	if (mo_pro.cleaning_br_L_limit_current < motor_info.Left_brush_current)
	{
		if (mo_pro.limit_flag != 1)
		{
			printf("���ˢ��������\n");
			mo_pro.start_time = HAL_GetTick();
			mo_pro.limit_flag = 1;
		}
	}
	else if (mo_pro.cleaning_br_R_limit_current < motor_info.Right_brush_current)
	{
		if (mo_pro.limit_flag != 2)
		{
			printf("�ұ�ˢ��������\n");
			mo_pro.start_time = HAL_GetTick();
			mo_pro.limit_flag = 2;
		}
	}
	else if (mo_pro.cleaning_main_br_limit_current < motor_info.Main_brush_current)
	{
		if (mo_pro.limit_flag != 3)
		{
			printf("��ˢ��������\n");
			mo_pro.start_time = HAL_GetTick();
			mo_pro.limit_flag = 3;
		}
	}
	else if (mo_pro.cleaning_vacuumfan_limit_current < motor_info.Fan_current)
	{
		if (mo_pro.limit_flag != 4)
		{
			printf("�����������\n");
			mo_pro.start_time = HAL_GetTick();
			mo_pro.limit_flag = 4;
		}
	}
	else
	{
		if (mo_pro.limit_flag != 0 || mo_pro.start_time != 0)
		{
			mo_pro.limit_flag = 0;
			mo_pro.start_time = 0;
			printf("����������0\n");
		}
	}
}

void *my_memcpy(void *dest, const void *src, size_t n)
{
	// �� void ָ��ת��Ϊ char ָ�룬���ֽڸ���
	unsigned char *d = (unsigned char *)dest;
	const unsigned char *s = (const unsigned char *)src;

	// ���ֽڸ�������
	while (n--)
	{
		if (*s != 0xff)
			*d = *s;
		d++;
		s++;
	}

	return dest; // ����Ŀ��ָ��
}
