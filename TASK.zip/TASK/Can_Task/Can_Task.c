#include "Can_Task.h"
uint8_t Encoder_R[4] = {0};
uint8_t Encoder_L[4] = {0};
// char InfoBuffer1[750];
//// ʹ�ð���
// char InfoBuffer2[1000];
uint8_t forbid_Shutdown = 0; // ��ֹ�ػ�ָ���־λ
int speed_l_10 = 0, speed_r_10 = 0, speed_l_100 = 0, speed_r_100 = 0;

// const uint8_t Reply_accelerated_speed[8] 	= {0x60,0x83,0x60,0x00,0xD0,0x40,0x00,0x00};	//���ü��ٶ�
const uint8_t Reply_accelerated_speed[8] = {0x60, 0x83, 0x60, 0x00, 0x88, 0x13, 0x00, 0x00}; // ���ü��ٶ�
// const uint8_t Reply_deceleration_speed[8] = {0x60,0x84,0x60,0x00,0xE8,0x03,0x00,0x00};   	//���ü��ٶ�		1000ms
// const uint8_t Reply_deceleration_speed[8] = {0x60,0x84,0x60,0x00,0xF4,0x01,0x00,0x00};  	//���ü��ٶ� 	500ms
const uint8_t Reply_deceleration_speed[8] = {0x60, 0x84, 0x60, 0x00, 0xFA, 0x0, 0x00, 0x00};  // ���ü��ٶ�		250ms
const uint8_t Reply_PVM_Motor[8] = {0x60, 0x60, 0x60, 0x00, 0x03, 0x00, 0x00, 0x00};		  // PVMģʽ���滮�ٶ�ģʽ
const uint8_t Reply_Stop_Motor[8] = {0x60, 0xff, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00};		  // ֹͣ���--ͨ���趨�ٶ�Ϊ0ʵ��
const uint8_t Reply_Enable_Motor_READY[8] = {0x60, 0x40, 0x60, 0x00, 0x06, 0x00, 0x00, 0x00}; // ʹ�ܵ��׼��
const uint8_t Reply_Disable_Motor[8] = {0x60, 0x40, 0x60, 0x00, 0x07, 0x00, 0x00, 0x00};	  // ʧ�ܵ��
const uint8_t Reply_Enable_Motor[8] = {0x60, 0x40, 0x60, 0x00, 0x0f, 0x00, 0x00, 0x00};		  // ʹ�ܵ��

const uint8_t Reply_TPDO1_6063H_1[8] = {0x60, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO1 stop
const uint8_t Reply_TPDO1_6063H_2[8] = {0x60, 0x00, 0x1A, 0x01, 0x20, 0x00, 0x63, 0x60}; // 6063H
const uint8_t Reply_TPDO1_6063H_3[8] = {0x60, 0x00, 0x1A, 0x00, 0x01, 0x00, 0x00, 0x00}; // TPDO1 enable
const uint8_t Reply_TPDO1_6063H_4[8] = {0x60, 0x00, 0x18, 0x05, 0x0A, 0x00, 0x00, 0x00}; // 10ms�ϱ�һ��
const uint8_t Reply_TPDO1_6063H_5[8] = {0x60, 0x00, 0x18, 0x03, 0x0A, 0x00, 0x00, 0x00}; //
const uint8_t Reply_TPDO1_6063H_6[8] = {0x60, 0x00, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //

const uint8_t Reply_TPDO2_3000H_1[8] = {0x60, 0x01, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO2 stop
const uint8_t Reply_TPDO2_3000H_2[8] = {0x60, 0x01, 0x1A, 0x01, 0x10, 0x00, 0x6C, 0x60}; //
const uint8_t Reply_TPDO2_3000H_3[8] = {0x60, 0x01, 0x1A, 0x00, 0x02, 0x00, 0x00, 0x00}; // TPDO2 enable
const uint8_t Reply_TPDO2_3000H_4[8] = {0x60, 0x01, 0x18, 0x05, 0x64, 0x00, 0x00, 0x00}; // 100ms�ϱ�һ��
const uint8_t Reply_TPDO2_3000H_5[8] = {0x60, 0x01, 0x18, 0x03, 0x64, 0x00, 0x00, 0x00}; //
const uint8_t Reply_TPDO2_3000H_6[8] = {0x60, 0x01, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //

const uint8_t Reply_TPDO3_6069H_1[8] = {0x60, 0x02, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO3 stop
const uint8_t Reply_TPDO3_6069H_2[8] = {0x60, 0x02, 0x1A, 0x01, 0x20, 0x00, 0x69, 0x60}; // 6069H
const uint8_t Reply_TPDO3_6069H_3[8] = {0x60, 0x02, 0x1A, 0x00, 0x03, 0x00, 0x00, 0x00}; // TPDO enable[4] 02 - 01
const uint8_t Reply_TPDO3_6069H_4[8] = {0x60, 0x02, 0x18, 0x05, 0x0a, 0x00, 0x00, 0x00}; // 10ms�ϱ�һ��
const uint8_t Reply_TPDO3_6069H_5[8] = {0x60, 0x02, 0x18, 0x03, 0x0a, 0x00, 0x00, 0x00}; //
const uint8_t Reply_TPDO3_6069H_6[8] = {0x60, 0x02, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //

uint8_t inquire_bat_info1[8] = {0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
uint8_t inquire_bat_info3[8] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
uint8_t inquire_bat_info6[8] = {0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

Motor_fault_code_ Motor_fault_code = {0}; // �����ֱ���������״̬
ENCODER Encoder = {0};
BAT_ BAT = {0};
motor_info_ motor_info = {0};
Atomization_ Atomization_l, Atomization_r;// wuhua
Push_Motor_ Main_push = {0};
Push_Motor_ Side_push = {0};
static uint8_t read_battery_state[8] = {0x21, 0xBB, 0xCF, 0x00, 0x00, 0x00, 0x00, 0x00}; // ��ȡ�����Ϣ
cleaning_controller Dn_Cleaning_Controller = {0};
send_cleaning_controller Send_Cleaning_Controller_Data = {0}, return_to_IPC = {0}; // ������λ���ĵ��״̬
peripheral_control_ peripheral_control = {0};
motor_monitoring_ motor_monitoring = {0};
Time_Clock_ Time_Clock = {0};
CAN_RxHeaderTypeDef CAN_RxMsg;
uint8_t Can_Receive_data[8] = {0};
Sensor_ Sensor = {0};
uint8_t atomization_l = 0, atomization_r = 0, times = 0;
cleaning_motor_speed clean_speed = {0};
BaseType_t Result, xHigherPriorityTaskWoken;

uint16_t Left_Motor_Current_Value = 0;	// ���ֵ������ֵ
uint16_t Right_Motor_Current_Value = 0; // ���ֵ������ֵ

uint8_t inquire_bat_err[8] = {0};
tasks_high_water_ tasks_high_water;
uint8_t charge_check_flag = 0; // ���Զ�����־
uint8_t received_mainpushMode = 0;
uint8_t received_sidepushMode = 0;

void Can_Task(void const *argument)
{
	delay_ms(1000);
	BAT.soft_version = 0;
	while (1)
	{
		times++;
		MY_ERROR.tasks_heart.can = 0;
		//  HAL_GPIO_TogglePin(LED_SYS_RUN_GPIO_Port,LED_SYS_RUN_Pin);//����״ָ̬ʾ��
		Can_Send_Msg(BMS_ID, read_battery_state); // 1S��ѯһ�ε��״̬
												  // Can_Send_Msg(0xcc,batterytest);

		if (times > 59)
		{
			times = 0;
			if (atomization_l == 0)
				Atomization_l.Liquid_level = 0;
			atomization_l = 0;
			if (atomization_r == 0)
				Atomization_r.Liquid_level = 0;
			atomization_r = 0;

			//			printf("Stack high water mark:\r\n");

			UBaseType_t stackHighWaterMark1 = uxTaskGetStackHighWaterMark(New_Cleaning_Motor_Control_Task_Handle);
			if ((uint16_t)stackHighWaterMark1 > 255)
				tasks_high_water.cleaning = 255;
			else
				tasks_high_water.cleaning = (uint16_t)stackHighWaterMark1;
			//			printf("Cleaning_Motor_Control_Task: \t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark1,(uint16_t)stackHighWaterMark1 * sizeof(UBaseType_t));

			UBaseType_t stackHighWaterMark2 = uxTaskGetStackHighWaterMark(Motor_Task_Handle);
			//			printf("Motor_Task: \t\t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark2,(uint16_t)stackHighWaterMark2 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark2 > 255)
				tasks_high_water.motor = 255;
			else
				tasks_high_water.motor = (uint16_t)stackHighWaterMark2;

			UBaseType_t stackHighWaterMark3 = uxTaskGetStackHighWaterMark(Data_Task_Handle);
			//			printf("Data_Task: \t\t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark3,(uint16_t)stackHighWaterMark3 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark3 > 255)
				tasks_high_water.data = 255;
			else
				tasks_high_water.data = (uint16_t)stackHighWaterMark3;

			UBaseType_t stackHighWaterMark4 = uxTaskGetStackHighWaterMark(Ultrasonic_Task_Handle);
			//			printf("Ultrasonic_Task: \t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark4,(uint16_t)stackHighWaterMark4 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark4 > 255)
				tasks_high_water.ultrasonic = 255;
			else
				tasks_high_water.ultrasonic = (uint16_t)stackHighWaterMark4;

			UBaseType_t stackHighWaterMark5 = uxTaskGetStackHighWaterMark(Can_Task_Handle);
			//			printf("Can_Task: \t\t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark5,(uint16_t)stackHighWaterMark5 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark5 > 255)
				tasks_high_water.can = 255;
			else
				tasks_high_water.can = (uint16_t)stackHighWaterMark5;

			UBaseType_t stackHighWaterMark6 = uxTaskGetStackHighWaterMark(Peripheral_Control_Task_Handle);
			//			printf("Peripheral_Control_Task: \t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark6,(uint16_t)stackHighWaterMark6 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark6 > 255)
				tasks_high_water.peripheral = 255;
			else
				tasks_high_water.peripheral = (uint16_t)stackHighWaterMark6;

			UBaseType_t stackHighWaterMark7 = uxTaskGetStackHighWaterMark(Light_Control_Task_Handle);
			//			printf("Light_Control_Task: \t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark7,(uint16_t)stackHighWaterMark7 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark7 > 255)
				tasks_high_water.light = 255;
			else
				tasks_high_water.light = (uint16_t)stackHighWaterMark7;

			UBaseType_t stackHighWaterMark8 = uxTaskGetStackHighWaterMark(IAP_Task_Handle);
			//			printf("IAP_Task: \t\t\t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark8,(uint16_t)stackHighWaterMark8 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark8 > 255)
				tasks_high_water.IAP = 255;
			else
				tasks_high_water.IAP = (uint16_t)stackHighWaterMark8;

			UBaseType_t stackHighWaterMark9 = uxTaskGetStackHighWaterMark(Alarm_Event_Manager_Task_Handle);
			//			printf("Alarm_Event_Manager_Task: \t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark9,(uint16_t)stackHighWaterMark9 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark9 > 255)
				tasks_high_water.alarm = 255;
			else
				tasks_high_water.alarm = (uint16_t)stackHighWaterMark9;

			UBaseType_t stackHighWaterMark0 = uxTaskGetStackHighWaterMark(Control_Data_Process_Task_Handle);
			//			printf("Control_Data_Process_Task: \t%u\twords (or %u bytes)\n",(uint16_t)stackHighWaterMark0,(uint16_t)stackHighWaterMark0 * sizeof(UBaseType_t));
			if ((uint16_t)stackHighWaterMark0 > 255)
				tasks_high_water.control_data = 255;
			else
				tasks_high_water.control_data = (uint16_t)stackHighWaterMark0;
			//			printf("\n");
			osSignalSet(Data_Task_Handle, high_water);
		}
		// ��ش�����벻Ϊ0ʱ��һ���ѯһ�Σ���Ϊ����״̬�ָ������ϴ���������벻���Զ���0������һֱ��ѯ��ֱ�����������0
		if (BAT.error1 != 0)
		{
			inquire_bat_err[0] = 0x01;
			Can_Send_Msg(inquire_bat_err_id, inquire_bat_err);
		}
		if (BAT.error2 != 0 || BAT.numbering_Undervoltage_cells != 0 || BAT.V_undervoltage_cell != 0)
		{
			inquire_bat_err[0] = 0x02;
			Can_Send_Msg(inquire_bat_err_id, inquire_bat_err);
		}
		//		Can_Send_Msg(ID_forbid_Shutdown,test_buf);
		if (BAT.soft_version) // ���ݵ�ز�ͬ�������汾�����Ͳ�ͬ�Ĳ�ѯ��Ϣ
		{
			Can_Send_Msg(bat_id, inquire_bat_info6);
			delay_ms(1000);
		}
		else
		{
			Can_Send_Msg(bat_id, inquire_bat_info1);
			delay_ms(500);
			Can_Send_Msg(bat_id, inquire_bat_info3);
			delay_ms(500);
		}
	}
}
void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *canHandle)
{
	if (canHandle->Instance == hcan.Instance)
	{
		if (HAL_CAN_GetRxMessage(&hcan, CAN_RX_FIFO0, &CAN_RxMsg, Can_Receive_data) == HAL_OK) // ��ý��յ�������ͷ������
		{
			Bump_Drop_Control(); // ��ײ�������
			BMS_light_Control();
			//   Cleaning_Motor_Online_Check();//���ܿ�����
			Motor_Encoder_Data();
			Analyze_the_motor_fault_state(); // ��ȡ�������״̬
			//    Dn_motor_monitoring_Function();
			MY_ERROR.module_heart.DN = 0;
			Motor_Initialization_Process_Control(); // �����ʼ�����̿���
			atomization();							// wuhua
													// Motor_Current_Value();//��챵��������ʾ
			pdu_check();							// ���Զ����ؼ��

			MY_ERROR.CAN_bus = 0;
		}
	}
}

void atomization(void) // wuhua
{
	if (CAN_RxMsg.StdId == 0x528)
	{
		if ((Can_Receive_data[1] & 0x01) == 1)
		{
			atomization_l = 1;
			Atomization_l.Version = Can_Receive_data[0];
			Atomization_l.state = (Can_Receive_data[1] & 0x40) >> 6;
			Atomization_l.Liquid_level_alarm = Can_Receive_data[2];
			Atomization_l.high_alarm = (Can_Receive_data[3] << 8) | Can_Receive_data[4];
			Atomization_l.low_alarm = Can_Receive_data[5];
			Atomization_l.Liquid_level = (Can_Receive_data[6] << 8) | Can_Receive_data[7];
		}
		else if ((Can_Receive_data[1] & 0x02) == 2)
		{
			atomization_r = 1;
			Atomization_r.Version = Can_Receive_data[0];
			Atomization_r.state = (Can_Receive_data[1] & 0x40) >> 6;
			Atomization_r.Liquid_level_alarm = Can_Receive_data[2];
			Atomization_r.high_alarm = (Can_Receive_data[3] << 8) | Can_Receive_data[4];
			Atomization_r.low_alarm = Can_Receive_data[5];
			Atomization_r.Liquid_level = (Can_Receive_data[6] << 8) | Can_Receive_data[7];
		}
	}
}

void Motor_Initialization_Process_Control(void) // �����ʼ�����̿���
{
	// �������ʹ��if		else if
	if (CAN_RxMsg.StdId == Rceive_MOTOR_L_CAN_ID || CAN_RxMsg.StdId == Rceive_MOTOR_R_CAN_ID)
	{
		if (memcmp(Can_Receive_data, Reply_accelerated_speed, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit1);
		}
		if (memcmp(Can_Receive_data, Reply_deceleration_speed, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit2);
		}
		if (memcmp(Can_Receive_data, Reply_PVM_Motor, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit3);
		}
		if (memcmp(Can_Receive_data, Reply_Stop_Motor, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit4);
		}
		if (memcmp(Can_Receive_data, Reply_Enable_Motor_READY, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit5);
		}
		if (memcmp(Can_Receive_data, Reply_Disable_Motor, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit6);
		}
		if (memcmp(Can_Receive_data, Reply_Enable_Motor, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Bit7);
		}

		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_1, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo1);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_2, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo2);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_3, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo3);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_4, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo4);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_5, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo5);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO1_6063H_6, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo6);
		}

		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_1, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo1);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_2, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo2);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_3, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo3);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_4, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo4);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_5, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo5);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO2_3000H_6, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo6);
		}

		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_1, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo1);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_2, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo2);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_3, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo3);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_4, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo4);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_5, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo5);
		}
		if (memcmp(Can_Receive_data, Reply_TPDO3_6069H_6, 8) == 0)
		{
			osSignalSet(Motor_Task_Handle, Motor_Init_Tpdo6);
		}
	}
}


void Dn_motor_monitoring_Function(void) // ���ܿ��������
{
	if (CAN_RxMsg.StdId == 0x585)
	{
		if ((Can_Receive_data[0] == 0x43) && (Can_Receive_data[1] == 0x88) && (Can_Receive_data[2] == 0x30))
		{
			Cleaning_Motor_Error.Code = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
			motor_info.Cleaning_motor_error_code1 = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
		}
		else if ((Can_Receive_data[0] == 0x43) && (Can_Receive_data[1] == 0x89) && (Can_Receive_data[2] == 0x30))
		{
			Cleaning_Motor_Error.Code = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
			motor_info.Cleaning_motor_error_code2 = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
		}
		else if ((Can_Receive_data[0] == 0x4b) && (Can_Receive_data[1] == 0x84) && (Can_Receive_data[2] == 0x30))
		{
			switch (Can_Receive_data[3])
			{
			case 1: // ��ˢ
				motor_info.Left_brush_current = Can_Receive_data[4];
				break;

			case 2: // 80�ķ��
				motor_info.Fan_current = Can_Receive_data[4];
				break;

			case 3: // ��ˢ
				motor_info.Main_brush_current = Can_Receive_data[4];
				break;

			case 4: // �ұ�ˢ
				motor_info.Right_brush_current = Can_Receive_data[4];
				break;
			}
		}
		else if (Can_Receive_data[0] == 0x4b && (Can_Receive_data[1] == 0x80) && (Can_Receive_data[2] == 0x30))
		{
			switch (Can_Receive_data[3])
			{
			case 1: // ���ˢ
				clean_speed.Left_side_brush = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
				break;

			case 2: // 80�ķ��
				clean_speed.vacuumfan = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
				break;

			case 3: // ��ˢ
				clean_speed.main_brush = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
				break;

			case 4: // �ұ�ˢ
				clean_speed.right_side_brush = (Can_Receive_data[7] << 24) | (Can_Receive_data[6] << 16) | (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
				break;
			}
		}
		MY_ERROR.module_heart.DN = 0;
	}
	else if (CAN_RxMsg.StdId == 0x1CE)
	{
		MY_ERROR.module_heart.Analog = 0;
	}
}
void Analyze_the_motor_fault_state(void) // ��ȡ��챵������״̬���������¶�
{
	if (CAN_RxMsg.StdId == Rceive_MOTOR_L_CAN_ID) // 581
	{
		if (Can_Receive_data[0] == 0X4b && Can_Receive_data[1] == 0X12 && Can_Receive_data[2] == 0X50)
		{
			//			Motor_fault_code.Left = (Can_Receive_data[5]<<8)|Can_Receive_data[4];
			motor_info.Left_motor_error_code = (Can_Receive_data[5] << 8) | Can_Receive_data[4];
		}
		else if (Can_Receive_data[0] == 0X4b && Can_Receive_data[1] == 0X1B && Can_Receive_data[2] == 0X50)
		{
			motor_info.Left_motor_temp = Can_Receive_data[4];
		}
		else if (Can_Receive_data[0] == 0x4b && Can_Receive_data[1] == 0x02 && Can_Receive_data[2] == 0x50)
		{
			motor_info.Left_motor_current_Value = (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
		}
		MY_ERROR.module_heart.wheel = 0;
	}
	if (CAN_RxMsg.StdId == Rceive_MOTOR_R_CAN_ID) // 582
	{
		if (Can_Receive_data[0] == 0X4b && Can_Receive_data[1] == 0X12 && Can_Receive_data[2] == 0X51)
		{
			//			Motor_fault_code.Right = (Can_Receive_data[5]<<8)|Can_Receive_data[4];
			motor_info.Right_motor_error_code = (Can_Receive_data[5] << 8) | Can_Receive_data[4];
		}
		else if (Can_Receive_data[0] == 0X4b && Can_Receive_data[1] == 0X1B && Can_Receive_data[2] == 0X51)
		{
			motor_info.Right_motor_temp = Can_Receive_data[4];
		}
		else if (Can_Receive_data[0] == 0x4b && Can_Receive_data[1] == 0x02 && Can_Receive_data[2] == 0x51)
		{
			motor_info.Right_motor_current_Value = (Can_Receive_data[5] << 8) | (Can_Receive_data[4]);
		}
		MY_ERROR.module_heart.wheel = 0;
	}
}
void Cleaning_Motor_Online_Check(void)
{
	if (CAN_RxMsg.StdId == Cleaning_Motor_Online_ID1)
	{
		//		osSignalSet(Cleaning_Motor_Control_Task_Handle,Cleaning_Motor_Heart);
	}
}
void Motor_Encoder_Data(void) // ��ȡ��������ֵ
{
#if (Machine_model == SW80)
	if (CAN_RxMsg.StdId == MotorL_Online_ID || CAN_RxMsg.StdId == Rceive_MOTOR_L_CAN_ID)
	{
		osSignalSet(Motor_Task_Handle, EVENTBIT_0);
	}
	if (CAN_RxMsg.StdId == MotorR_Online_ID || CAN_RxMsg.StdId == Rceive_MOTOR_R_CAN_ID)
	{
		osSignalSet(Motor_Task_Handle, EVENTBIT_1);
	}
#endif
	if (CAN_RxMsg.StdId == 0x181)
	{
		for (int i = 0; i < 4; i++)
		{
			Encoder_L[i] = Can_Receive_data[i];
		}
		MY_ERROR.module_heart.wheel_encoder = 0;
		BaseType_t xHigherPriorityTaskWoken;
		xQueueOverwriteFromISR(OdomL_Queue, Encoder_L, &xHigherPriorityTaskWoken); // ������з�������
		portYIELD_FROM_ISR(xHigherPriorityTaskWoken);							   // �����Ҫ�Ļ�����һ�������л�
	}
	if (CAN_RxMsg.StdId == 0x182)
	{
		for (int i = 0; i < 4; i++)
		{
			Encoder_R[i] = Can_Receive_data[i];
		}
		MY_ERROR.module_heart.wheel_encoder = 0;
		BaseType_t xHigherPriorityTaskWoken;
		xQueueOverwriteFromISR(OdomR_Queue, Encoder_R, &xHigherPriorityTaskWoken); // ������з�������
		portYIELD_FROM_ISR(xHigherPriorityTaskWoken);							   // �����Ҫ�Ļ�����һ�������л�
	}
	else if (CAN_RxMsg.StdId == 0x281)
	{
		speed_l_100 = Can_Receive_data[1] << 8 | Can_Receive_data[0];
	}
	else if (CAN_RxMsg.StdId == 0x282)
	{
		speed_r_100 = Can_Receive_data[1] << 8 | Can_Receive_data[0];
	}
	else if (CAN_RxMsg.StdId == 0x381)
	{
		speed_l_10 = Can_Receive_data[1] << 8 | Can_Receive_data[0];
	}
	else if (CAN_RxMsg.StdId == 0x382)
	{
		speed_r_10 = Can_Receive_data[1] << 8 | Can_Receive_data[0];
	}
}

void BMS_light_Control(void) // �����ƴ�����
{
	if (CAN_RxMsg.StdId == 0x00BB)
	{
		BAT.Voltage = (Can_Receive_data[0] * 256 + Can_Receive_data[1]);
		BAT.Current = (Can_Receive_data[2] * 256 + Can_Receive_data[3]);
		BAT.SOC = Can_Receive_data[4];
		BAT.Temp = Can_Receive_data[5] - 40;
		BAT.STA = Can_Receive_data[6]; // 0:�ŵ磻1:��� 2:���� 3:����
		MY_ERROR.module_heart.bat = 0;
	}
	else if (CAN_RxMsg.StdId == 0xe0)
	{
		if (Can_Receive_data[0] == 0x07)
		{
			BAT.BAT_Reboot = 0; // ���յ�����ָ�ֹͣ���͵������
		}
	}
	else if (CAN_RxMsg.StdId == bat_reply_id)
	{
		if (Can_Receive_data[0] == 0x01 && Can_Receive_data[1] == 0x01)
		{
			BAT.Cell_voltage_difference = Can_Receive_data[7];
		}
		else if (Can_Receive_data[0] == 0x01 && Can_Receive_data[1] == 0x02)
		{
			BAT.capacity_all = Can_Receive_data[5];
			BAT.capacity_now = Can_Receive_data[6];
		}
		else if (Can_Receive_data[0] == 0x01 && Can_Receive_data[1] == 0x04)
		{
			BAT.cycle_count = (Can_Receive_data[3] << 8) | Can_Receive_data[4];
			BAT.soft_version = (Can_Receive_data[5] << 8) | Can_Receive_data[6];
		}
		else if (Can_Receive_data[0] == 0x03 && Can_Receive_data[1] == 0x01)
		{
			BAT.temperature1 = Can_Receive_data[3];
			BAT.temperature2 = Can_Receive_data[4];
			BAT.temperature3 = Can_Receive_data[2];
		}
		else if (Can_Receive_data[0] == 0x06 && Can_Receive_data[1] == 0x01)
		{
			BAT.Cell_voltage_difference = (Can_Receive_data[6] << 8) | Can_Receive_data[7];
		}
		else if (Can_Receive_data[0] == 0x06 && Can_Receive_data[1] == 0x03)
		{
			BAT.capacity_all = Can_Receive_data[2];
			BAT.capacity_now = Can_Receive_data[3];
			BAT.temperature1 = Can_Receive_data[6];
			BAT.temperature2 = Can_Receive_data[7];
			BAT.temperature3 = Can_Receive_data[5];
		}
		else if (Can_Receive_data[0] == 0x06 && Can_Receive_data[1] == 0x04)
		{
			BAT.cycle_count = (Can_Receive_data[2] << 8) | Can_Receive_data[3];
			BAT.health_status = Can_Receive_data[6];
		}
	}
	else if (CAN_RxMsg.StdId == bat_err_id)
	{
		if (Can_Receive_data[0] == 0x01)
		{
			// �ŵ����(δ����0 ����1)����������MOS���¡�������������BMS���ϱ�������س��¡����MOS�ܹ���
			BAT.error1 = Can_Receive_data[1] | (Can_Receive_data[2] << 1) | (Can_Receive_data[3] << 2) | (Can_Receive_data[4] << 3) | (Can_Receive_data[5] << 4) | (Can_Receive_data[6] << 5) | (Can_Receive_data[7] << 6);
		}
		else if (Can_Receive_data[0] == 0x02)
		{
			// �ŵ�MOS�ܹ��ϡ���ص��¡����ѹ����󡢳�����
			BAT.error2 = Can_Receive_data[1] | (Can_Receive_data[2] << 1) | (Can_Receive_data[3] << 2) | (Can_Receive_data[4] << 3);
			// Ƿѹ��о���
			BAT.numbering_Undervoltage_cells = Can_Receive_data[5];
			//[6]����Ƿѹ(��ѹ��λmV),[7]����Ƿѹ(��ѹ��λmV)
			BAT.V_undervoltage_cell = (uint16_t)Can_Receive_data[6] << 8 | Can_Receive_data[7];
		}
	}

	if (CAN_RxMsg.StdId == ID_forbid_Shutdown)
	{
		if (Can_Receive_data[0] == 0x2f && Can_Receive_data[1] == 0x40 && Can_Receive_data[2] == 0x60)
		{
			if (Can_Receive_data[4] == 0x55 && Can_Receive_data[5] == 0xff)
			{
				forbid_Shutdown = 1; // ��ֹ�ػ�ָ��յ���ָ��󣬵ײ㽫����ϵ�
			}
			else if (Can_Receive_data[4] == 0xdb && Can_Receive_data[5] == 0xbd) // �����ֹ�ػ�ָ��
				forbid_Shutdown = 0;
		}
		else if (Can_Receive_data[0] == 0x2f && Can_Receive_data[1] == 0x47 && Can_Receive_data[2] == 0x23)
		{
			send_end_flag = 1;
		}
		else if (Can_Receive_data[0] == 0x2f && Can_Receive_data[1] == 0x08 && Can_Receive_data[2] == 0x24)
		{
			clean_color = 1;
		}
	}
}
void Bump_Drop_Control(void) // ��ײ�������
{
	if (CAN_RxMsg.StdId == 0xf1) // ���䴫�������
	{
		if ((Can_Receive_data[0] == 0xaf) | (Can_Receive_data[1] == 0xfa))
		{
			if ((Can_Receive_data[2] == 0x01) | (Can_Receive_data[3] == 0x01))
				Sensor.Drop_Flag = 1;
			else if ((Can_Receive_data[2] == 0x00) | (Can_Receive_data[3] == 0x00))
				Sensor.Drop_Flag = 0;
		}
	}
	if (CAN_RxMsg.StdId == 0xf2) // ��ײ������
	{
		if ((Can_Receive_data[0] == 0xbf) | (Can_Receive_data[1] == 0xfb)) // ǰ��ײ
		{
			if ((Can_Receive_data[2] == 0x01) | (Can_Receive_data[3] == 0x01))
				Sensor.Front_Bump_Flag = 1;
			else if ((Can_Receive_data[2] == 0x00) | (Can_Receive_data[3] == 0x00))
				Sensor.Front_Bump_Flag = 0;
		}
		if ((Can_Receive_data[0] == 0xcf) | (Can_Receive_data[1] == 0xfc)) // ����ײ
		{
			if ((Can_Receive_data[2] == 0x01) | (Can_Receive_data[3] == 0x01))
				Sensor.Back_Bump_Flag = 1;
			else if ((Can_Receive_data[2] == 0x00) | (Can_Receive_data[3] == 0x00))
				Sensor.Back_Bump_Flag = 0;
		}
	}
}
void pdu_check(void)
{
	if (CAN_RxMsg.StdId == 0xcd)
	{
		if (Can_Receive_data[0] == 0x09 && Can_Receive_data[1] == 0x09)
		{
			charge_check_flag = 1;
		}
		else if (Can_Receive_data[0] == 0x0a && Can_Receive_data[1] == 0x0a)
		{
			charge_check_flag = 0;
		}
		
		if(Can_Receive_data[0] == 0x20 && Can_Receive_data[1] == 0x5b)
		{
		 received_mainpushMode = Can_Receive_data[2];
		}

    if(Can_Receive_data[0] == 0x21 && Can_Receive_data[1] == 0x5b)
    {
		 received_sidepushMode = Can_Receive_data[2];
		}
    
    if(Can_Receive_data[0] == 0x20 && Can_Receive_data[1] == 0x0c && Can_Receive_data[2] == 0x06)
		{
      Main_push.push_motor_current = (uint16_t)((Can_Receive_data[4] << 8) | Can_Receive_data[3]) * 10;      
      Main_push.push_motor_voltage = (uint16_t)((Can_Receive_data[6] << 8) | Can_Receive_data[5]) * 10;     
      Main_push.push_motor_mode = Can_Receive_data[7];
			printf("Main Push -> Curr: %d (mA), Volt: %d (mV), Mode: %d\r\n", 
                   Main_push.push_motor_current, 
                   Main_push.push_motor_voltage, 
                   Main_push.push_motor_mode);
		}else if (Can_Receive_data[0] == 0x20 && Can_Receive_data[1] == 0x0C && Can_Receive_data[2] == 0xEC)
     {
      Main_push.push_motor_err = Can_Receive_data[3]; 
      printf("Main Push Error -> Code: 0x%02X\r\n", Main_push.push_motor_err);
     }
    
    if (Can_Receive_data[0] == 0x21 && Can_Receive_data[1] == 0x0C && Can_Receive_data[2] == 0x06)
    {
            
      Side_push.push_motor_current = (uint16_t)((Can_Receive_data[4] << 8) | Can_Receive_data[3]) * 10;           
      Side_push.push_motor_voltage = (uint16_t)((Can_Receive_data[6] << 8) | Can_Receive_data[5]) * 10;
      Side_push.push_motor_mode = Can_Receive_data[7];
			printf("Side Push -> Curr: %d (mA), Volt: %d (mV), Mode: %d\r\n", 
                   Side_push.push_motor_current, 
                   Side_push.push_motor_voltage, 
                   Side_push.push_motor_mode);
     }else if (Can_Receive_data[0] == 0x21 && Can_Receive_data[1] == 0x0C && Can_Receive_data[2] == 0xEC)
      {
      Side_push.push_motor_err = Can_Receive_data[3]; 
      printf("Side Push Error -> Code: 0x%02X\r\n", Side_push.push_motor_err);
      }	
	}
	
	
}
void Can_Send_Msg(uint32_t ID, uint8_t *msg)
{
	CAN_TxHeaderTypeDef Can_Tx;
	uint32_t pTx1Mailbox = 0;
	Can_Tx.StdId = ID;
	Can_Tx.ExtId = ID;
	Can_Tx.IDE = 0;
	Can_Tx.RTR = 0;
	Can_Tx.DLC = 8;
	while (HAL_CAN_AddTxMessage(&hcan, &Can_Tx, msg, &pTx1Mailbox) != HAL_OK)
	{
		printf("can_send_failed\r\n");
		delay_ms(10);
	}
	delay_ms(4);
}
void Can_Send_Msg_Cnt(uint32_t ID, uint8_t *msg, uint8_t cnt)
{
	CAN_TxHeaderTypeDef Can_Tx;
	uint32_t pTx1Mailbox = 0;
	Can_Tx.StdId = ID;
	Can_Tx.ExtId = ID;
	Can_Tx.IDE = 0;
	Can_Tx.RTR = 0;
	Can_Tx.DLC = cnt;
	HAL_CAN_AddTxMessage(&hcan, &Can_Tx, msg, &pTx1Mailbox);
	delay_ms(4);
}
void Multiple_Can_Send_Msg(uint32_t ID, uint8_t *msg)
{
	for (int i = 0; i < 3; i++)
	{
		Can_Send_Msg(ID, msg);
		delay_ms(10);
	}
}

// �������η��ͣ�����һ�γɹ�����0��ȫ��ʧ�ܷ���1
uint8_t Multiple_Can_Send_Msg_OTA(uint32_t ID, uint8_t *msg)
{
	CAN_TxHeaderTypeDef CAN_txHeader;
	uint32_t txMailbox = 0;

	CAN_txHeader.StdId = ID;
	CAN_txHeader.ExtId = ID;
	CAN_txHeader.IDE = 0;
	CAN_txHeader.RTR = 0;
	CAN_txHeader.DLC = 8;
	uint8_t success = 0;

	for (int i = 0; i < 3; i++)
	{
		if (HAL_CAN_AddTxMessage(&hcan, &CAN_txHeader, msg, &txMailbox) == HAL_OK)
		{
			success = 1;
		}
		else
		{
			printf("can_send_failed\r\n");
		}
		delay_ms(5);
	}

	if (success)
	{
		return 0;
	}

	return 1;
}
