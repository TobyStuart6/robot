//#include "Cleaning_Motor_Control_Task.h"

//#include <stdio.h>
//#include <stdlib.h> // ����rand()��srand()
//#include <time.h>   // ����time()

//uint8_t read_PWM_left_sidebrush[8] 	= {0x40,0X80,0X30,0X01,0X00,0x00,0x00,0x00};                //���ˢ
//uint8_t read_PWM_right_sidebrush[8] = {0x40,0X80,0X30,0X04,0X00,0x00,0x00,0x00};                //���
//uint8_t read_PWM_mainbrush[8] 		= {0x40,0X80,0X30,0X03,0X00,0x00,0x00,0x00};                //��ˢ
//uint8_t read_PWM_vacuumfan[8] 		= {0x40,0X80,0X30,0X02,0X00,0x00,0x00,0x00};                //�ұ�ˢ

///*------------------------��ʢ�Ƽ�-------------------------------*/
//uint8_t zs_vacuumfan_speed_high[8] = {0x13,0X80,0X00,0X00,0X00,0x00,0x00,0x00};   //5V            //��շ��ȸ���  
//uint8_t zs_vacuumfan_speed_medium[8] = {0x0E,0XA6,0X00,0X00,0X00,0x00,0x00,0x00}; //3.75V         //��շ�������  
//uint8_t zs_vacuumfan_speed_low[8] = {0x09,0Xc4,0X00,0X00,0X00,0x00,0x00,0x00};    //2.5V          //��շ��ȵ���
//uint8_t zs_vacuumfan_speed_off[8] = {0x00,0X00,0X00,0X00,0X00,0x00,0x00,0x00};                 //��շ��ȹر�
//uint8_t zs_vacuumfan_speed[8] = {0x00,0X00,0X00,0X00,0X00,0x00,0x00,0x00};                 //��շ���

///*------------------------�Ĵ�������������----------------------*/
///*M3�����ˢ���  M2Ϊ��շ���   M1Ϊ���ˢ  M4Ϊ�ұ�ˢ M6Ϊǰ�˱�ˢ���� M5Ϊ�����ˢ����*/
//M1 ǰ�����ˢ
//uint8_t left_sidebrush_off[8] = {0x2b,0X80,0X30,0X01,0X00,0x00,0x00,0x00};                //���ˢ�����
//uint8_t left_sidebrush_low[8] = {0x2b,0X80,0X30,0X01,0X88,0x13,0x00,0x00};                //���ˢ����� 
//uint8_t left_sidebrush_medium[8] = {0x2b,0X80,0X30,0X01,0X58,0x1B,0x00,0x00};             //���ˢ����� 
//uint8_t left_sidebrush_high[8] = {0x2b,0X80,0X30,0X01,0X40,0x1F,0x00,0x00};               //���ˢ����� 
//uint8_t left_sidebrush_speed[8] = {0x2b,0X80,0X30,0X01,0X00,0x00,0x00,0x00};                //���ˢ���

//M4  ǰ���ұ�ˢ
//uint8_t right_sidebrush_off[8] = {0x2b,0X80,0X30,0X04,0X00,0x00,0x00,0x00};                //�ұ�ˢ�����
//uint8_t right_sidebrush_low[8] = {0x2b,0X80,0X30,0X04,0X88,0x13,0x00,0x00};                 //�ұ�ˢ����� 
//uint8_t right_sidebrush_medium[8] = {0x2b,0X80,0X30,0X04,0X58,0x1B,0x00,0x00};             //�ұ�ˢ����� 
//uint8_t right_sidebrush_high[8] = {0x2b,0X80,0X30,0X04,0X40,0x1F,0x00,0x00};               //�ұ�ˢ�����
//uint8_t right_sidebrush_speed[8] = {0x2b,0X80,0X30,0X04,0X00,0x00,0x00,0x00};                //�ұ�ˢ���
//M3  �����ˢ
//uint8_t mainbrush_off[8] = {0x2b,0X80,0X30,0X03,0X00,0x00,0x00,0x00};                      //��ˢ�����
//int mainbrush_on[8] = {0x2b,0X80,0X30,0X01,0X10,0x27,0x00,0x00};                         //��ˢ����� 
//uint8_t mainbrush_speed_high[8] = {0x2b,0X80,0X30,0X03,0X70,0x17,0x00,0x00};               //��ˢ�������  
//uint8_t mainbrush_speed_medium[8] = {0x2b,0X80,0X30,0X03,0X88,0x13,0x00,0x00};             //��ˢ�������  
//uint8_t mainbrush_speed_low[8] = {0x2b,0X80,0X30,0X03,0XA0,0x0F,0x00,0x00};                //��ˢ�������
//uint8_t mainbrush_speed_high[8] = {0x2b,0X80,0X30,0X03,0X70,0x17,0x00,0x00};               //��ˢ�������  
//uint8_t mainbrush_speed_medium[8] = {0x2b,0X80,0X30,0X03,0X88,0x13,0x00,0x00};             //��ˢ�������  
//uint8_t mainbrush_speed_low[8] = {0x2b,0X80,0X30,0X03,0XC4,0x09,0x00,0x00};                //��ˢ�������
//uint8_t mainbrush_speed[8] = {0x2b,0X80,0X30,0X03,0X00,0x00,0x00,0x00};                //��ˢ���ת��

//uint8_t mainbrush_speed_accelerated[8] = {0x2b,0X81,0X30,0X03,0X50,0x00,0x00,0x00};              //�����ˢ���ٶ�
//uint8_t mainbrush_speed_deceleration[8] = {0x2b,0X82,0X30,0X03,0X50,0x00,0x00,0x00};             //�����ˢ���ٶ�

//M6 ǰ�˱�ˢ����
//uint8_t sidebrush_stop[8] = {0x2b,0X80,0X30,0X06,0X00,0x00,0x00,0x00};                     //ǰ�˱�ˢֹͣ
//uint8_t sidebrush_up[8] = {0x2b,0X80,0X30,0X06,0X10,0x27,0x00,0x00};                       //ǰ�˱�ˢ����
//uint8_t sidebrush_down[8] = {0x2b,0X80,0X30,0X06,0Xf0,0xd8,0x00,0x00};                     //ǰ�˱�ˢ�½�
//#if (Machine_model == SW55 || Machine_model == SW55L)
//uint8_t sidebrush_up[8] = {0x2b,0X80,0X30,0X06,0Xf0,0xd8,0x00,0x00};                       //ǰ�˱�ˢ����
//uint8_t sidebrush_down[8] = {0x2b,0X80,0X30,0X06,0X10,0x27,0x00,0x00};                     //ǰ�˱�ˢ�½�
//#elif(Machine_model == SW80)
//uint8_t sidebrush_down[8] = {0x2b,0X80,0X30,0X06,0Xf0,0xd8,0x00,0x00};                    //ǰ�˱�ˢ�½�
//uint8_t sidebrush_up[8] = {0x2b,0X80,0X30,0X06,0X10,0x27,0x00,0x00};                        //ǰ�˱�ˢ����
//#endif

//uint8_t sidebrush_accelerated[8] = {0x2b,0X81,0X30,0X06,0X64,0x00,0x00,0x00};              //ǰ�˱�ˢ���ٶ�
//uint8_t sidebrush_deceleration[8] = {0x2b,0X82,0X30,0X06,0X64,0x00,0x00,0x00};             //ǰ�˱�ˢ���ٶ�

//M5 �����ˢ����
//uint8_t mainbrush_stop[8] = {0x2b,0X80,0X30,0X05,0X00,0x00,0x00,0x00};                     //�����ˢֹͣ
//uint8_t mainbrush_up[8] = {0x2b,0X80,0X30,0X05,0X10,0x27,0x00,0x00};                       //�����ˢ����
//uint8_t mainbrush_down[8] = {0x2b,0X80,0X30,0X05,0Xf0,0xd8,0x00,0x00};                     //�����ˢ�½�
//uint8_t mainbrush_up[8] = {0x2b,0X80,0X30,0X05,0Xf0,0xd8,0x00,0x00};                       //�����ˢ����
//uint8_t mainbrush_down[8] = {0x2b,0X80,0X30,0X05,0X10,0x27,0x00,0x00};                     //�����ˢ�½�
//uint8_t mainbrush_accelerated[8] = {0x2b,0X81,0X30,0X05,0X64,0x00,0x00,0x00};              //�����ˢ�������ٶ�
//uint8_t mainbrush_deceleration[8] = {0x2b,0X82,0X30,0X05,0X64,0x00,0x00,0x00};             //�����ˢ�������ٶ�
//M2 ��շ���
//uint8_t vacuumfan_off[8] = {0x2b,0X80,0X30,0X02,0X00,0x00,0x00,0x00};                       //��շ��ȹ�
//uint8_t vacuumfan_on[8] = {0x2b,0X80,0X30,0X02,0X10,0x27,0x00,0x00};                      //��շ��ȿ�
//uint8_t vacuumfan_speed_high[8] = {0x2b,0X80,0X30,0X02,0X10,0x27,0x00,0x00};                //��շ��ȸ���  
//uint8_t vacuumfan_speed_medium[8] = {0x2b,0X80,0X30,0X02,0X4C,0x1D,0x00,0x00};              //��շ�������  
//uint8_t vacuumfan_speed_low[8] = {0x2b,0X80,0X30,0X02,0X88,0x13,0x00,0x00};                 //��շ��ȵ���
//uint8_t vacuumfan_speed[8] = {0x2b,0X80,0X30,0X02,0X00,0x00,0x00,0x00};                       //��շ���
//����
//uint8_t spray_left_off [8] = {0x01,0x06,0x00,0x80,0,0,0,0};//��������  wuhua
//uint8_t spray_left_no  [8] = {0x01,0x06,0x00,0xc0,0,0,0,0};//��������
//uint8_t spray_right_off[8] = {0x02,0x06,0x00,0x80,0,0,0,0};//��������
//uint8_t spray_right_no [8] = {0x02,0x06,0x00,0xc0,0,0,0,0};//��������
//�����״̬
//uint8_t Read_Cleaning_Controller_State[8] = {0x43,0X86,0X30,0X00,0X00,0x00,0x00,0x00};      //�����״̬
//��̺ģʽ
//uint8_t Brush_Pressure_Mode[8] = {0x2F,0x8d,0x30,0x01,0x01,0x00,0x00,0x00};//����ˢ�̵���ģʽ
//uint8_t Brush_Pressure_Current_L[8] = {0x2F,0x8d,0x30,0x02,0x05,0x00,0x00,0x00};//����ˢ�̵���ģʽ_5A
//uint8_t Brush_Pressure_Current_M[8] = {0x2F,0x8d,0x30,0x02,0x07,0x00,0x00,0x00};//����ˢ�̵���ģʽ_7A
//uint8_t Brush_Pressure_Current_H[8] = {0x2F,0x8d,0x30,0x02,0x09,0x00,0x00,0x00};//����ˢ�̵���ģʽ_9A
//uint8_t Brush_Pressure_Current[8] = {0x2F,0x8d,0x30,0x02,0x00,0x00,0x00,0x00};//��������ˢ�̵�����С
//uint8_t Brush_Mode_EN[8] = {0x2F,0x8d,0x30,0x04,0x01,0x00,0x00,0x00};//1��ʾ����ˢѹģʽˢ�̵����ˢ���Ƹ˵������0x3080�ڵ�PWMֵ����
//uint8_t Brush_Pressure_Open_EN[8] = {0x2F,0x8d,0x30,0x05,0x01,0x00,0x00,0x00};//1��ʾ����ˢ��ѹ��ģʽ��
//�˳���̺ģʽ
//uint8_t Brush_Pressure_Close_EN[8] = {0x2F,0x8d,0x30,0x05,0x00,0x00,0x00,0x00};//0��ʾ����ˢ��ѹ��ģʽ�ر�
//uint8_t Brush_Mode_Quit[8] = {0x2F,0x8d,0x30,0x04,0x00,0x00,0x00,0x00};//0��ʾˢ�̺�ˢ���Ƹ���0x3080�ڵ�PWMֵ����

//clean_motor_mode_ clean_motor_mode;
//send_cleaning_controller clean_state_from_IPC = {0};

//Clean_Device_Controller_ Clean_Device_Controller = {0};
//BRUSH_DOWN_DIS_ mainbrush_dis = {0};
//BRUSH_DOWN_DIS_ sidebrush_dis = {0};
//para_cle_mot_ para_cle_mot,para_cle_mot_South_Korea;

//void Cleaning_Motor_Control_Task(void const * argument)
//{
//	Dn_Cleaning_Controller.carpet_pattern_step = 0;
//	sidebrush_dis.finsh_flag = 1;
//	delay_ms(2000);
//    osEvent Restart_Stop_Event;
//    //	HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);//�رմ��ܿ�������Դ
//    //	delay_ms(1000);
//    HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//�򿪴��ܿ�������Դ
//    HAL_GPIO_WritePin(GPIOB,RS4_PWR_EN_Pin,GPIO_PIN_SET);  //��ʼ�����ȵ�Դ//����ʢ�Ƽ�ģ��ʹ��
//	
//	para_cle_mot.mainbrush = (float)(100 - mainbrush_min_speed) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	para_cle_mot.sidebrush = (float)(100 - sidebrush_min_speed) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	para_cle_mot.vacuumfan = (float)(100 - vacuumfan_min_speed) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	
//	para_cle_mot_South_Korea.mainbrush = (float)(32 - mainbrush_min_speed_South_Korea) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	para_cle_mot_South_Korea.sidebrush = (float)(60 - sidebrush_min_speed_South_Korea) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	para_cle_mot_South_Korea.vacuumfan = (float)(100 - vacuumfan_min_speed_South_Korea) / 10;//����10������ʱÿ���ȼ��Ĳ�ֵ
//	
//	printf("��ˢ����Ϊ%.2lf\r\n",para_cle_mot.mainbrush);
//	printf("��ˢ����Ϊ%.2lf\r\n",para_cle_mot.sidebrush);
//	printf("�������Ϊ%.2lf\r\n",para_cle_mot.vacuumfan);
//    while(1)
//    {
//		/*	
//		Restart_Stop_Event  = osSignalWait(Reset_Emergency_Stop_Event,0);    // �ȴ���ͣ��λ
//		if((Restart_Stop_Event.status == osEventSignal)&&(Restart_Stop_Event.value.signals&0x08))	
//		{
//		HAL_GPIO_WritePin(GPIOB,RS4_PWR_EN_Pin,GPIO_PIN_SET);  //��ʼ�����ȵ�Դ//����ʢ�Ƽ�ģ��ʹ��
//		HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//�������ܿ�������Դ
//		}
//		

//	
//		if (times == 10)
//		{
//			xQueueReceive(Clean_Device_Controller_Queue,&Clean_Device_Controller_Queue_Value,1000);
//			Clean_Device_Controller.motor = Clean_Device_Controller_Queue_Value>>8;
//			Clean_Device_Controller.level = Clean_Device_Controller_Queue_Value >> 16;
//			Clean_Device_Controller.Mode = Clean_Device_Controller_Queue_Value;
//			if (Clean_Device_Controller.motor != x || Clean_Device_Controller.Mode != y || Clean_Device_Controller.level != z)
//			{
//				printf("motor:%d,mode:%d,level:%d\r\n",Clean_Device_Controller.motor,Clean_Device_Controller.Mode,Clean_Device_Controller.level);
//				x = Clean_Device_Controller.motor; y = Clean_Device_Controller.Mode; z = Clean_Device_Controller.level;
//			}
//			Receive_Dn_Cleaning_Controller(Clean_Device_Controller.motor,Clean_Device_Controller.Mode,Clean_Device_Controller.level);
//			if(Stop_Mode)
//				Stop_Clean_Control();
//			else
//				Send_Dn_Cleaning_Controller();
//		}
//		*/
//		MY_ERROR.tasks_heart.cleaning = 0;
//		main_side_brush_up_down();
//		Send_Dn_Cleaning_Controller();
//		delay_ms(50);
//		times ++;	if (times > 10)		times = 0;
//    }
//}

//void main_side_brush_up_down(void)
//{
//	if(mainbrush_dis.enable_flag == 1)
//	{
//		if (mainbrush_dis.time <= 3000)
//		{
//			mainbrush_dis.time ++;
//			if (mainbrush_dis.send_times <= 3)
//			{
//				mainbrush_dis.send_times ++;
//				Can_Send_Msg(Cleaning_Motor_ID,Brush_Pressure_Close_EN);
//				printf("����-%d\r\n",mainbrush_dis.time);
//				Can_Send_Msg(Cleaning_Motor_ID,mainbrush_up);//��ˢ����
//			}
//		}
//		else if (mainbrush_dis.time >= 3000 && mainbrush_dis.time < (3000 + 320 * mainbrush_dis.down_dis))
//		{
//			if (mainbrush_dis.send_times < 6)
//			{
//				mainbrush_dis.send_times ++;
//				printf("����-%d\r\n",mainbrush_dis.time);
//				Can_Send_Msg(Cleaning_Motor_ID,mainbrush_down);//��ˢ�½� 2b 80 30 06 10 27
//			}
//		}
//		else 
//		{
//			printf("��ͣ-%d\r\n",mainbrush_dis.time);
//			Multiple_Can_Send_Msg(Cleaning_Motor_ID,mainbrush_stop);//��ˢֹͣ
//			mainbrush_dis.finsh_flag = 1;
//			mainbrush_dis.enable_flag = 0;
//			mainbrush_dis.time_flag = 0;
//			mainbrush_dis.send_times = 0;
//		}
//	}
//	else
//	{
//		mainbrush_dis.finsh_flag = 0;
//		mainbrush_dis.time_flag = 0;
//		mainbrush_dis.send_times = 0;
//		mainbrush_dis.time = 0;
//	}
//	
//	if(sidebrush_dis.enable_flag == 1)//ͨ��sidebrush_dis.time��ȷ���½��ľ��룬��sidebrush_dis.down_dis�����ж�
//	{
//		if (sidebrush_dis.time < 3000)
//		{
//			if (sidebrush_dis.send_times < 3)
//			{
//				sidebrush_dis.send_times ++;
//				printf("����-%d,%d\r\n",sidebrush_dis.time,sidebrush_dis.down_dis);
//				Can_Send_Msg(Cleaning_Motor_ID,sidebrush_up);//��ˢ���� 2b 80 30 06 f0 d8
//			}
//		}
//		else if (sidebrush_dis.time >= 3000 && sidebrush_dis.time < (3000 + 250 * sidebrush_dis.down_dis))
//		{
//			if (sidebrush_dis.send_times < 6)
//			{
//				sidebrush_dis.send_times ++;
//				printf("�߽�-%d\r\n",sidebrush_dis.time);
//				Can_Send_Msg(Cleaning_Motor_ID,sidebrush_down);//��ˢ�½� 2b 80 30 06 10 27
//			}
//		}
//		else 
//		{
//			printf("��ͣ-%d\r\n",sidebrush_dis.time);
//			Multiple_Can_Send_Msg(Cleaning_Motor_ID,sidebrush_stop);//��ˢֹͣ 2b 80 30 06 00 00
//			sidebrush_dis.finsh_flag = 1;
//			sidebrush_dis.enable_flag = 0;
//			sidebrush_dis.time_flag = 0;
//			sidebrush_dis.send_times = 0;
//		}
//	}
//}

///*
//�������ܣ�������λ������������������ָ��
//��ڲ�����clean_motor ������ࣻMode��ִ�ж���
//����  ֵ��У����
//*/
//void Receive_Dn_Cleaning_Controller(uint8_t clean_motor,uint8_t Mode,uint8_t level)
//{	
//	//�ϲ�Э����8��ʾ�أ�10����Ҳ��8�������߳�ͻ�����Եײ㽫0��ӦΪ��
//	if(Mode == 0 || Mode == 21 || Mode == 22 || Mode == 23 || Mode == 7 || clean_motor == 203)
//	{
//		switch(clean_motor)
//		{
//			case 13://���ˢ
//			{
//				if(level <= 10)
//				{
//					Dn_Cleaning_Controller.left_sidebrush = level;
//					Dn_Cleaning_Controller.right_sidebrush = level; 
//					printf("��ˢ%d\r\n",level);
//				}
//				else 
//				{
//					Dn_Cleaning_Controller.left_sidebrush = 0;
//					Dn_Cleaning_Controller.right_sidebrush = 0;
//					printf("��ˢ0\r\n");
//				}
//				clean_motor_mode.side_brush = Mode;
//				clean_motor_mode.side_brush = Mode;
//				clean_state_from_IPC.left_sidebrush_data = Mode;
//				clean_state_from_IPC.right_sidebrush_data = Mode;
//				break;
//			}
//			case 2://�ұ�ˢ
//			{
//				if(level <= 10)
//					Dn_Cleaning_Controller.right_sidebrush = level;
//				else 
//					Dn_Cleaning_Controller.right_sidebrush = 0;
//	//				printf("�ұ�ˢ%d\r\n",level);
//				Send_Cleaning_Controller_Data.right_sidebrush_data = Mode;
//	//			printf("###%d\r\n",Dn_Cleaning_Controller.right_sidebrush);
//				break;		
//			}			
//			case 10://��ˢ
//			{
//				printf("������%d,%d\n",Mode,level);
//				if(level <= 10)
//					Dn_Cleaning_Controller.mainbrush = level;
//				else
//					Dn_Cleaning_Controller.mainbrush = 0;
//				clean_motor_mode.main_brush = Mode;
//				clean_state_from_IPC.mainbrush_data = Mode;
//				break;			
//			}
//			case 31://��շ���
//			{
//				if(level <= 10)
//					Dn_Cleaning_Controller.vacuumfan = level;
//				else
//					Dn_Cleaning_Controller.vacuumfan = 0;
//				#if(Machine_model == SW55)
//				Send_Cleaning_Controller_Data.vacuumfan_data = Mode;
//				clean_state_from_IPC.vacuumfan_data = Mode;
//				#elif(Machine_model == SW80)
//				clean_motor_mode.vacuumfan = Mode;
//				clean_state_from_IPC.vacuumfan_data = Mode;
//				#endif
//	//			printf("fan = %d\n",Send_Cleaning_Controller_Data.vacuumfan_data);
//				break;			
//			}
//			case 23://ǰ�˱�ˢ����
//			{
//				if(level > 0 && level < 11)
//				{
//	//				printf("��ˢ%d,\r\n",level);
//					sidebrush_dis.down_dis = 11 - level;
//					if(sidebrush_dis.down_dis != sidebrush_dis.down_dis_old)
//					{
//						Send_Cleaning_Controller_Data.sidebrush_data = Mode;
//						sidebrush_dis.finsh_flag = 0;
//						sidebrush_dis.enable_flag = 1;
//						sidebrush_dis.time_flag = 1;
//						sidebrush_dis.time = 0;
//						sidebrush_dis.down_dis_old = sidebrush_dis.down_dis;
//					}
//					Dn_Cleaning_Controller.sidebrush = 0;
//				}
//				else 
//				{
//					sidebrush_dis.down_dis = 0;
//					sidebrush_dis.down_dis_old = 0;
//					Dn_Cleaning_Controller.sidebrush = 1;
//	//				printf("��ˢ����\r\n");
//				}
//				break;		
//			}			
//			case 22://�����ˢ����
//			{
//				if(level > 0 && level < 11)
//				{
//					printf("������%d,%d,%d\r\n",level,mainbrush_dis.down_dis,mainbrush_dis.down_dis_old);
//					mainbrush_dis.down_dis = 11 - level;
//					if(mainbrush_dis.down_dis != mainbrush_dis.down_dis_old)
//					{
//						printf("������1\n");
//						mainbrush_dis.finsh_flag = 0;
//						mainbrush_dis.enable_flag = 1;
//						mainbrush_dis.time = 0;
//						mainbrush_dis.time_flag = 1;
//						mainbrush_dis.down_dis_old = mainbrush_dis.down_dis;
//						Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode; 
//					}
//					Dn_Cleaning_Controller.mainbrush_up_dowm = 0;
//					Dn_Cleaning_Controller.carpet_pattern_step = 0;
//				}
//				else 
//				{
//					Dn_Cleaning_Controller.mainbrush_up_dowm = 1;
//					mainbrush_dis.down_dis = 0;
//					mainbrush_dis.down_dis_old = 0;
//					Dn_Cleaning_Controller.carpet_pattern_step = 0;
//					printf("��ˢ����\r\n");
//				}
//				break;
//			}
//			case 8://��������
//			{
//				if(Mode == 0)
//				{
//					Dn_Cleaning_Controller.left_sidebrush = 0;
//					Dn_Cleaning_Controller.right_sidebrush = 0;
//					Dn_Cleaning_Controller.mainbrush = 0;
//					Dn_Cleaning_Controller.vacuumfan = 0;
//					Dn_Cleaning_Controller.sidebrush = 1;
//					Dn_Cleaning_Controller.mainbrush_up_dowm = 1;
//					Dn_Cleaning_Controller.carpet_pattern_step = 0;
//				}						
//				else if(Mode == 1)
//				{
//					Dn_Cleaning_Controller.left_sidebrush = 1;
//					Dn_Cleaning_Controller.right_sidebrush = 1;
//					Dn_Cleaning_Controller.mainbrush = 1;
//					Dn_Cleaning_Controller.vacuumfan = 1;
//					Dn_Cleaning_Controller.sidebrush = 2;
//					Dn_Cleaning_Controller.mainbrush_up_dowm = 2;
//					Dn_Cleaning_Controller.carpet_pattern_step = 0;
//				}
//				break;
//			}
//			case 203://��̺ģʽ
//			{
//				if(Mode > 0 && Mode < 31)
//				{
//	//				printf("�أ���%d",Mode);
//					Dn_Cleaning_Controller.mainbrush_up_dowm = 0;
//					mainbrush_dis.enable_flag = 0;
//					Brush_Pressure_Current[4] = Mode;
//					Dn_Cleaning_Controller.carpet_pattern_step = Mode;
//					Send_Cleaning_Controller_Data.carpet_pattern_step_data = Mode;
//				}
//				else 
//				{
//					Dn_Cleaning_Controller.carpet_pattern_step = 0;
//					Send_Cleaning_Controller_Data.carpet_pattern_step_data = 0;
//				}
//				break;
//			}
//			case 42://����
//			{
//				if (Mode == 1)
//					Dn_Cleaning_Controller.spray_l = 1;
//				else if (Mode == 0)
//					Dn_Cleaning_Controller.spray_l = 0;
//				break;
//			}
//			case 43:
//			{
//				if (Mode == 1)
//					Dn_Cleaning_Controller.spray_r = 1;
//				else if (Mode == 0)
//					Dn_Cleaning_Controller.spray_r = 0;
//				break;
//			}
//			case 60:
//			{
//				Dn_Cleaning_Controller.UV_LED = Mode;
//				if(Mode == 7) 
//				{
//	//				printf("��\r\n");
//					HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET); 
//				}
//				else if (Mode == 0)
//				{
//					HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET); 
//	//				printf("�ر�\r\n");
//				}
//				break; 
//			}
//		}
//	}
//}

//void Send_Dn_Cleaning_Controller(void)
//{
//	static uint8_t num = 0,wait_flag= 0;
//	uint32_t Clean_Device_Controller_Queue_Value = 0;//�ϻ�������������������
//	uint8_t x = 0,y = 0,z = 0;//����ʱʹ��
//	num ++;	
//	
//	if (mainbrush_dis.enable_flag || sidebrush_dis.enable_flag)//��Ϊ����1S����ˢ����ˢ������׼ȷ��Ӱ��ϴ�����������ˢ����ʱ������ʱ��
//		xQueueReceive(Clean_Device_Controller_Queue,&Clean_Device_Controller_Queue_Value,0);
//	else if(wait_flag == 3)
//		xQueueReceive(Clean_Device_Controller_Queue,&Clean_Device_Controller_Queue_Value,1000);
//	else 
//		xQueueReceive(Clean_Device_Controller_Queue,&Clean_Device_Controller_Queue_Value,100);
//	
//	Clean_Device_Controller.motor = Clean_Device_Controller_Queue_Value>>8;
//	Clean_Device_Controller.level = Clean_Device_Controller_Queue_Value >> 16;
//	Clean_Device_Controller.Mode = Clean_Device_Controller_Queue_Value;
//	int a = 0, b = 5;//
//	int random_number_ab = (rand() % (b - a + 1)) + a;//ģ�ⶪ��
//	if (Clean_Device_Controller.motor != x || Clean_Device_Controller.Mode != y || Clean_Device_Controller.level != z)//
//	{
//		printf("motor:%d,mode:%d,level:%d\r\n",Clean_Device_Controller.motor,Clean_Device_Controller.Mode,Clean_Device_Controller.level);//
//		if(random_number_ab < 4)//ģ�ⶪ��
//		{//
//			printf("***pass:%d,%d,%d***\n",Clean_Device_Controller.motor,Clean_Device_Controller.level,Clean_Device_Controller.Mode);//
//			Clean_Device_Controller.motor = 0;//
//			Clean_Device_Controller.level = 0;//
//			Clean_Device_Controller.Mode = 0;//
//		}//
//		else //
//		x = Clean_Device_Controller.motor; y = Clean_Device_Controller.Mode; z = Clean_Device_Controller.level;
//		clean_motor_pro_param = 1;
//		//�ϲ�Э����8��ʾ�أ�10����Ҳ��8�������߳�ͻ�����Եײ㽫0��ӦΪ��
//		if (Clean_Device_Controller.Mode == 8)		Clean_Device_Controller.Mode = 0;
//	}
//	Receive_Dn_Cleaning_Controller(Clean_Device_Controller.motor,Clean_Device_Controller.Mode,Clean_Device_Controller.level);

//	wait_flag = 3;
//	if ( clean_state_from_IPC.left_sidebrush_data != Send_Cleaning_Controller_Data.left_sidebrush_data)
//	{
//		uint8_t gread = Dn_Cleaning_Controller.left_sidebrush;
//		float temp = gread / (gread + 0.0001);
//		uint16_t speed_leftbrush = 0;
//		if(country == 5)
//			 speed_leftbrush = (uint16_t)(para_cle_mot_South_Korea.sidebrush * gread + sidebrush_min_speed_South_Korea * temp) * 100;
//		else 
//			speed_leftbrush = (uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100;
//							//(uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100
//		left_sidebrush_speed[4] = (uint8_t)speed_leftbrush;
//		left_sidebrush_speed[5] = speed_leftbrush >> 8;
//		Can_Send_Msg(Cleaning_Motor_ID,left_sidebrush_speed);
//		wait_flag --;
//		printf("��ˢת�٣���%.2lf,%d����%d,%d\n",temp,speed_leftbrush,clean_state_from_IPC.left_sidebrush_data,Send_Cleaning_Controller_Data.left_sidebrush_data);
//	}
//	if (clean_state_from_IPC.right_sidebrush_data != Send_Cleaning_Controller_Data.right_sidebrush_data)
//	{
//		uint8_t gread = Dn_Cleaning_Controller.right_sidebrush;
//		float temp = gread / (gread + 0.0001);
//		uint16_t speed_rightbrush = 0;
//		if(country == 5)
//			 speed_rightbrush = (uint16_t)(para_cle_mot_South_Korea.sidebrush * gread + sidebrush_min_speed_South_Korea * temp) * 100;
//		else 
//			speed_rightbrush = (uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100;
//		right_sidebrush_speed[4] = (uint8_t)speed_rightbrush;
//		right_sidebrush_speed[5] = speed_rightbrush >> 8;
//		Can_Send_Msg(Cleaning_Motor_ID,right_sidebrush_speed);
//		wait_flag --;
//		printf("��ˢת�٣���%d,%d����%d,%d\n",gread,speed_rightbrush,clean_state_from_IPC.right_sidebrush_data,Send_Cleaning_Controller_Data.right_sidebrush_data);
//	}
//	if (clean_state_from_IPC.mainbrush_data != Send_Cleaning_Controller_Data.mainbrush_data)
//	{
//		uint8_t gread = Dn_Cleaning_Controller.mainbrush;
//		float temp = gread / (gread + 0.0001);
//		uint16_t speed_mainbrush = 0;
//		if(country == 5)
//			 speed_mainbrush = (uint16_t)(para_cle_mot_South_Korea.mainbrush * gread + mainbrush_min_speed_South_Korea * temp) * 100;
//		else 
//			speed_mainbrush = (uint16_t)(para_cle_mot.mainbrush * gread + mainbrush_min_speed * temp) * 100;
//		mainbrush_speed[4] = (uint8_t)speed_mainbrush;
//		mainbrush_speed[5] = speed_mainbrush >> 8;
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_speed);
//		wait_flag --;
//		printf("%d,%d,%d,%d,%.2lf\n",speed_mainbrush,(uint8_t)para_cle_mot.mainbrush,gread,(uint8_t)mainbrush_min_speed,temp);
//		printf("��ˢת�٣���%d,%d����%d,%d\n",gread,speed_mainbrush,clean_state_from_IPC.mainbrush_data,Send_Cleaning_Controller_Data.mainbrush_data);
//	}
//	else 
//		printf("111,%d,%d\n",clean_state_from_IPC.mainbrush_data,Send_Cleaning_Controller_Data.mainbrush_data);
//	if(Dn_Cleaning_Controller.sidebrush == 1)//��ˢ����
//	{
//		Can_Send_Msg(Cleaning_Motor_ID,sidebrush_up);
//		Send_Cleaning_Controller_Data.sidebrush_data = 8;
//		printf("��ˢ����\r\n");
//	}
//	if(Dn_Cleaning_Controller.mainbrush_up_dowm == 1)//��ˢ����
//	{
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_up); 
//		Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = 8;
//		printf("����\r\n");
//	}
//	if (Dn_Cleaning_Controller.UV_LED == 0)//UV��
//	{
//		HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET); 
//		Send_Cleaning_Controller_Data.UV_LED_data = 0;
//	}
//	else if (Dn_Cleaning_Controller.UV_LED == 7)//UV��
//	{
//		HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET); 
//		Send_Cleaning_Controller_Data.UV_LED_data = 7;
//	}
//	
//	if(Dn_Cleaning_Controller.vacuumfan == 0)//���ֹͣ
//	{
//		Can_Send_Msg(Cleaning_Motor_ID,vacuumfan_off);
//		Send_Cleaning_Controller_Data.vacuumfan_data = 8;
//		Multiple_Can_Send_Msg(Zhongshengkeji_ID,zs_vacuumfan_speed_off);
//		printf("�����\r\n");
//	}
//	else if(Dn_Cleaning_Controller.vacuumfan < 11)	//���ʮ������
//	{
//		uint8_t gread = Dn_Cleaning_Controller.vacuumfan;
//		uint16_t speed_vacuumfan = 0;
//		if(country == 5)
//			speed_vacuumfan = (uint16_t)(para_cle_mot_South_Korea.vacuumfan * gread + vacuumfan_min_speed) * 100;
//		else 
//			speed_vacuumfan = (uint16_t)(para_cle_mot_South_Korea.vacuumfan * gread + vacuumfan_min_speed) * 100;
//		vacuumfan_speed[4] = (uint8_t)speed_vacuumfan;
//		vacuumfan_speed[5] = speed_vacuumfan >> 8;
//		Can_Send_Msg(Cleaning_Motor_ID,vacuumfan_speed);
//		speed_vacuumfan /= 2;
//		zs_vacuumfan_speed[1] = (uint8_t)speed_vacuumfan;
//		zs_vacuumfan_speed[0] = speed_vacuumfan >> 8;
//		Multiple_Can_Send_Msg(Zhongshengkeji_ID,zs_vacuumfan_speed);
//		printf("���ת��%d,%x,%x\r\n",speed_vacuumfan,zs_vacuumfan_speed[0],zs_vacuumfan_speed[1]);
//	}
//	
//	if(Dn_Cleaning_Controller.carpet_pattern_step != 0)//��̺ģʽ�������
//	{
//		printf("�ؿ���%d\r\n",Dn_Cleaning_Controller.carpet_pattern_step);
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Pressure_Mode);
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Pressure_Current);
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Mode_EN);
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Pressure_Open_EN);
//		mainbrush_dis.time = 0;
//		mainbrush_dis.enable_flag = 0;
//		mainbrush_dis.down_dis = 0;
//	}
//	else if(Dn_Cleaning_Controller.carpet_pattern_step == 0)
//	{
//		printf("%d,%d\r\n",mainbrush_dis.down_dis,mainbrush_dis.down_dis_old);
//		if (mainbrush_dis.down_dis_old != mainbrush_dis.down_dis)//��һ���˳���̺ģʽ��Ҫ������һ�ε���ˢ����������ˢ�߶�
//		{
//			printf("�ع�,%d,%d\r\n",mainbrush_dis.down_dis,mainbrush_dis.down_dis_old);
//			if (mainbrush_dis.down_dis_old == 0)//�����һ����ˢ��0��Ҳ����û���½�������ˢ�������������
//				Dn_Cleaning_Controller.mainbrush_up_dowm = 1; 
//			else
//			{
//				mainbrush_dis.time_flag = 1;
//				mainbrush_dis.time = 0;
//				mainbrush_dis.enable_flag = 1;
//				mainbrush_dis.down_dis = mainbrush_dis.down_dis_old;
//			}
//		}
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Pressure_Close_EN);
//		Can_Send_Msg(Cleaning_Motor_ID,Brush_Mode_Quit);
//	}
//	
//	if (Dn_Cleaning_Controller.spray_l == 0)//��������  wuhua
//	{
//		Can_Send_Msg(Cleaning_spray_ID,spray_left_off);
//	}
//	else if (Dn_Cleaning_Controller.spray_l == 1)//��������
//	{
//		Can_Send_Msg(Cleaning_spray_ID,spray_left_no);
//	}

//	if (Dn_Cleaning_Controller.spray_r == 0)//��������
//	{
//		Can_Send_Msg(Cleaning_spray_ID,spray_right_off);
//	}
//	else if (Dn_Cleaning_Controller.spray_r == 1)//��������
//	{
//		Can_Send_Msg(Cleaning_spray_ID,spray_right_no);
//	}
//	
//	if (num >= 30)//ʵ��30������
//	{
//		num = 0;
//		Can_Send_Msg(Cleaning_Motor_ID,sidebrush_accelerated); 
//		Can_Send_Msg(Cleaning_Motor_ID,sidebrush_deceleration);
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_accelerated); 
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_deceleration);
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_speed_accelerated);
//		Can_Send_Msg(Cleaning_Motor_ID,mainbrush_speed_deceleration);
//		printf("send accelerated\r\n");
//	}
//	cleaning_motor_gears_judge();
//}
//���ݴ��ܷ��ص�ת���жϵ�ǰ�����λ
//void cleaning_motor_gears_judge(void)
//{ 
//	//�ϲ�Э����8��ʾ�أ�10����Ҳ��8�������߳�ͻ�����Եײ㽫15��ӦΪ��
//	uint8_t gread = Dn_Cleaning_Controller.left_sidebrush;
//	float temp = gread / (gread + 0.00001);
//	if (clean_speed.Left_side_brush == (uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100)
//	{
//		Send_Cleaning_Controller_Data.left_sidebrush_data = clean_motor_mode.side_brush;
//	}
//	else if(country == 5 && clean_speed.Left_side_brush == (uint16_t)(para_cle_mot_South_Korea.sidebrush * gread + sidebrush_min_speed_South_Korea * temp) * 100)
//	{
//		Send_Cleaning_Controller_Data.left_sidebrush_data = clean_motor_mode.side_brush;
//	}
//	delay_ms(5);
//	printf("%d,%d,%d,%d,%.2lf,%d\n",((uint16_t)(para_cle_mot_South_Korea.sidebrush * gread + sidebrush_min_speed_South_Korea * temp) * 100),
//									(uint8_t)para_cle_mot_South_Korea.sidebrush,gread,(uint8_t)sidebrush_min_speed_South_Korea,temp,gread);
//	
//	if (clean_speed.right_side_brush == (uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100)
//	{
//		Send_Cleaning_Controller_Data.right_sidebrush_data = clean_motor_mode.side_brush;
//	}
//	else if(country == 5 && clean_speed.right_side_brush == (uint16_t)(para_cle_mot_South_Korea.sidebrush * gread + sidebrush_min_speed_South_Korea * temp) * 100)
//	{
//		Send_Cleaning_Controller_Data.right_sidebrush_data = clean_motor_mode.side_brush;
//	}
//	delay_ms(5);
//	printf("222,,%d,%d\n",clean_speed.right_side_brush,((uint16_t)(para_cle_mot.sidebrush * gread + sidebrush_min_speed * temp) * 100));
//	
//	gread = Dn_Cleaning_Controller.mainbrush;
//	temp = gread / (gread + 0.00001);
//	if (clean_speed.main_brush == (int16_t)(para_cle_mot.mainbrush * gread + mainbrush_min_speed * (gread / (gread + 0.00001))) * 100)
//	{
//		Send_Cleaning_Controller_Data.mainbrush_data = clean_motor_mode.main_brush;
//	}
//	else if(country == 5 && clean_speed.main_brush == (int16_t)(para_cle_mot_South_Korea.mainbrush * gread + mainbrush_min_speed_South_Korea * (gread / (gread + 0.00001))) * 100)
//	{
//		Send_Cleaning_Controller_Data.mainbrush_data = clean_motor_mode.main_brush;
//	}
//	printf("%d,%d,%d,%d,%.2lf,%d\n",((uint16_t)(para_cle_mot_South_Korea.mainbrush * gread + mainbrush_min_speed_South_Korea * temp) * 100),
//									(uint8_t)para_cle_mot_South_Korea.mainbrush,gread,(uint8_t)mainbrush_min_speed_South_Korea,temp,gread);
//	
//#if(Machine_model == SW80)
//	delay_ms(5);
//	gread = Dn_Cleaning_Controller.vacuumfan;
//	if (gread == 0 && clean_speed.vacuumfan == 0)
//			Send_Cleaning_Controller_Data.vacuumfan_data = clean_motor_mode.vacuumfan;
//	else if (clean_speed.vacuumfan == (int16_t)(para_cle_mot.vacuumfan * gread + vacuumfan_min_speed) * 100)
//		Send_Cleaning_Controller_Data.vacuumfan_data = clean_motor_mode.vacuumfan;
//	
//	delay_ms(10);
//	Can_Send_Msg(Cleaning_Motor_ID,read_PWM_vacuumfan);
//#endif
//	delay_ms(10);
//	Can_Send_Msg(Cleaning_Motor_ID,read_PWM_left_sidebrush);
//	delay_ms(10);
//	Can_Send_Msg(Cleaning_Motor_ID,read_PWM_mainbrush);
//	delay_ms(10);
//	Can_Send_Msg(Cleaning_Motor_ID,read_PWM_right_sidebrush);
//}




