//#ifndef __CLEANING_MOTOR_CONTROL_TASK_H
//#define __CLEANING_MOTOR_CONTROL_TASK_H
//#include "FreeRTOS.h"
//#include "task.h"
//#include "main.h"
//#include "cmsis_os.h"
//#include "can.h"
//#include "Can_Task.h"
//#include <stdio.h>
//#include <string.h>
//#include "Can_Task.h"
//#include "Ultrasonic_Task.h"
//#include "Light_Control_Task.h"
//#include "Control_Data_Process_Task.h"

//#define Cleaning_Motor_ID     0x605
//#define Cleaning_Motor_Heart	1         //�������������ָ��
//#define Cleaning_spray_ID 0x428  // wuhua

//#define Zhongshengkeji_ID  0x1CE

//#define mainbrush_min_speed 16.67
//#define sidebrush_min_speed 44.5
//#define vacuumfan_min_speed 44.5

//#define mainbrush_min_speed_South_Korea 10
//#define sidebrush_min_speed_South_Korea 10
//#define vacuumfan_min_speed_South_Korea 44.5
//typedef struct
//{
//	uint8_t motor;
//	uint8_t Mode;
//	uint8_t level;
//}Clean_Device_Controller_;

//typedef struct
//{
//	uint16_t time;
//	uint8_t down_dis;
//	uint8_t time_flag;
//	uint8_t finsh_flag;
//	uint8_t send_times;
//	uint8_t enable_flag;
//	uint8_t down_dis_old;
//} BRUSH_DOWN_DIS_;
//extern BRUSH_DOWN_DIS_ mainbrush_dis;
//extern BRUSH_DOWN_DIS_ sidebrush_dis;

//typedef struct
//{
//	float mainbrush;
//	float sidebrush;
//	float vacuumfan;
//}
//para_cle_mot_;

//typedef struct
//{
//	uint8_t side_brush;
//	uint8_t main_brush;
//	uint8_t vacuumfan;
//}clean_motor_mode_;

//void Cleaning_Motor_Control_Task(void const * argument);
//void Receive_Dn_Cleaning_Controller(uint8_t clean_motor,uint8_t Mode,uint8_t level);
//void Send_Dn_Cleaning_Controller(void);//��KDSЭ�����Ĵ�����������������
//void main_side_brush_up_down(void);
//void Send_Dn_Cleaning_Controller1(void);
//void cleaning_motor_gears_judge(void);
//#endif








