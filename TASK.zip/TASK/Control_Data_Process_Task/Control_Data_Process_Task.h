#ifndef _CONTROL_DATA_PROCESS_TASK
#define _CONTROL_DATA_PROCESS_TASK
#include "Data_Task.h"
#include "Control_Data_Process_Task.h"
#include "pdu_iap.h"
#include "Motor_Task.h"
//#include "Can_Iap_Task.h"


extern uint8_t Uart2_Buffer[1050],country,country_flag;//���մ���2�����д��������




void Usart2_Receive_Data(void);


void Control_Data_Process_Task(void const * argument);
	

#endif


