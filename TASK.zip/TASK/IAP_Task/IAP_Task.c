#include "IAP_Task.h"

void IAP_Task(void const *argument)
{
	while (1)
	{
		osSignalWait(Start_Ota_Flag, osWaitForever); /* �ȴ�����������־λ,һֱ�� */
		MX_IWDG_Init_again();
		delay_ms(100);
		IAP_CHECK();
		delay_ms(100);
	}
}

void Writer_IAP_Version(void) // д�汾��
{
	STMFLASH_Write(Version_ADDR, (uint16_t *)&version, sizeof(version));
}
void Writer_IAP_Flag(void) // д���±�־λ
{
	uint16_t flag = 1;
	STMFLASH_Write(IAP_Flag, (uint16_t *)&flag, sizeof(flag));
}
static __INLINE void NVIC_CoreReset(void)
{
	__DSB();
	// ��λVECTRESET
	SCB->AIRCR = ((0x5FA << SCB_AIRCR_VECTKEY_Pos) |
				  (SCB->AIRCR & SCB_AIRCR_PRIGROUP_Msk) |
				  SCB_AIRCR_VECTRESET_Msk);
	__DSB();
	while (1)
		;
}
void Sys_Soft_Reset(void) // ϵͳ��λ
{
	printf(" >> boot reset <<\r\n ");
	__disable_fault_irq();
	__set_FAULTMASK(1);
	//	NVIC_SystemReset();
	NVIC_CoreReset();
}
void IAP_CHECK(void)
{
	printf("APP:��ʼ����\r\n");
	Writer_IAP_Flag(); // д���±�־λ
	Sys_Soft_Reset();
}
static void MX_IWDG_Init_again(void)
{

	hiwdg.Instance = IWDG;
	hiwdg.Init.Prescaler = IWDG_PRESCALER_64;
	hiwdg.Init.Reload = 100;
	if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
	{
		Error_Handler();
	}
}
