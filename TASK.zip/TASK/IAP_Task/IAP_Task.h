#ifndef __IAP_TASK_H
#define __IAP_TASK_H
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "Light.h"
#include "Can_Task.h"
#include "stdlib.h"
#include "iap.h"
#include "stmflash.h"
#include "Data_Task.h"


#define Start_Ota_Flag  (1<<4)

void IAP_Task(void const * argument);


void IAP_CHECK(void);

void Writer_IAP_Version(void);//д���±�־λ

static void MX_IWDG_Init_again(void);


#endif
