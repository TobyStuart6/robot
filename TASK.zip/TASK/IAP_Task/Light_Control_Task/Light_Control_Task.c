#include "Light_Control_Task.h"
uint8_t Stop_Mode = 0,param[100] = {0},task_stack_overflow = 0;
uint32_t Stop_Cnt = 0;
uint8_t stop_type = 0;//Ĭ��0��ʾΪ��ť��ͣ  1Ҳ��ʾΪ��ť��ͣ  2��ʾΪ�Ը�λ��ͣ
uint16_t stop_flag = 0;
uint16_t flash_params[50] = {0},write_flash_param = 0;//[0]�Ǽ�ͣ���� 
uint32_t connection_time = 0,connection_time_last = 0;
uint8_t task_stack_overflowbuf[50] = {0};
extern osThreadId New_Cleaning_Motor_Control_Task_Handle;

uint8_t send_end_flag = 0,clean_color = 0;
uint8_t color = 0;//��ǰ��ɫ
uint8_t color_type[100] = {3,0},color_times[100] = {0},color_send[8] = {0};
//#define dog_Addr		0x0800db00
//uint16_t dog_flag = 0,dog_time = 0;
uint8_t red[2] = {03,03};
uint8_t orange[2] = {04,04};
uint8_t greenbreath[2] = {05,05};
uint8_t green[2] = {06,06};
uint8_t blue[2] = {07,07};
uint8_t purple[2] = {0x08, 0x08};
uint8_t orangeflicker[2] = {0x15, 0x15};
uint8_t redbreath[2] = {0x16,0x16};
void Light_Control_Task(void const * argument)
{
	delay_ms(1200);
	STMFLASH_Read(stop_Addr,flash_params,50);//������б�����flash�е����ݶ�����param������
	for(int i=0;i<50;i++)
	{
		param[i*2] = flash_params[i];
		param[i*2+1] = flash_params[i] >> 8;
	}
	stop_type = param[2];
	printf("boot version:%d��%d�µ�%d��\n",flash_params[0]/1000,(flash_params[0]%1000)/10,flash_params[0]%10);//24 12 1 
	delay_ms(1000);
//	HAL_GPIO_WritePin(LED_SYS_ALM_GPIO_Port,LED_SYS_ALM_Pin|LED01_CON_Pin|LED03_CON_Pin,GPIO_PIN_SET); //LED��
//	check_flash();
//	active_stack_overflow(); //�ú�����ʹ��ջ���
//	STMFLASH_Read(dog_Addr,&dog_flag,1);
//	printf("dog_flag = %x\n",dog_flag);
	while(1)
	{
		MY_ERROR.tasks_heart.light = 0;
		if (stop_type == 2)
		{
			if(0 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
			{
				delay_ms(5);
				if(0 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
				{
					Stop_Mode = 2;
					Stop_Cnt=1;
				}
			}
		}
		else
		{
			if(0 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
			{
				delay_ms(5);
				if(0 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
				{
					Stop_Mode = 1;
					Stop_Cnt=1;
				}
			}
			else if(1 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
			{
				delay_ms(5);
				if(1 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
				{
					Stop_Mode = 0;
				}
			}
		}
		
		if(Stop_Cnt == 1)
		{
			if(1 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
			{
				delay_ms(5);
				if(1 == HAL_GPIO_ReadPin(IN_STOP_GPIO_Port,IN_STOP_Pin))
				{
					xQueueSend(Reset_Stop_Queue,&Stop_Cnt, 0);
					Stop_Cnt = 0;
//					osSignalSet(Motor_Task_Handle,Reset_Emergency_Stop_Event); 
//					osSignalSet(New_Cleaning_Motor_Control_Task_Handle,Reset_Emergency_Stop_Event); 
					
				}
			}		
		}	 
		
		if (0x02 == (clean_peripheral_sta & 0x02) && stop_type == 2)  //�����ͣ״̬
		{
			Stop_Mode = 0;
			clean_peripheral_sta &= 0xfd;
		}
		
		if (((clean_peripheral_sta >> 4) & 0x3) != 0)//д��ͣ����  ���޸������Ӧλ�ã�Ȼ��ȫ��д��ȥ
		{
			if (((clean_peripheral_sta >> 4) & 1) == 1)
				param[2] = 1;
			else 
				param[2] = 2;
			flash_params[1] = param[2] | (uint16_t)(param[3] << 8);
			STMFLASH_Write(stop_Addr,flash_params,50);
			delay_ms(10);
			STMFLASH_Read(stop_Addr,flash_params,50);//���ڲ�flash�ж�ȡ���� 
			param[2] = flash_params[1];
			stop_type = param[2];
			if (((clean_peripheral_sta >> 4) & 1) == 1)
				clean_peripheral_sta &= 0xef;
			else 
				clean_peripheral_sta &= 0xdf;
			
			if (stop_type == 1)
				printf("��ť\r\n");
			else if (stop_type == 2)
				printf("�Ը�λ\r\n");
		}
		if(xQueueReceive(write_flash_Queue,&write_flash_param,0))//���������������д�������Ӧλ�ã�Ȼ��д��flash��
		{
			param[write_flash_param >> 8] = write_flash_param & 0xff;
			printf("param[%d] = %d\r\n",write_flash_param >> 8,param[write_flash_param >> 8]);
			for(int i=0;i<50;i++)
				flash_params[i] = param[i*2] | (uint16_t)(param[i*2+1] << 8);
			STMFLASH_Write(stop_Addr,flash_params,50);
			delay_ms(10);
			STMFLASH_Read(stop_Addr,flash_params,50);//���ڲ�flash�ж�ȡ���� 
			for(int i=0;i<50;i++)
			{
				param[i*2] = flash_params[i];
				param[i*2+1] = flash_params[i] >> 8;
			}
			stop_type = param[2];
			my_memcpy(&mo_pro,&param[3],5);
			printf("��������������%d,%d,%d,%d,%d\r\n",mo_pro.cleaning_br_L_limit_current,mo_pro.cleaning_br_R_limit_current
			,mo_pro.cleaning_main_br_limit_current,mo_pro.cleaning_vacuumfan_limit_current,mo_pro.limit_time);
			memcpy(upload_data,&mo_pro,5);
		}

  	light_control();
		delay_ms(100);
	}
}

#if (Machine_model == SW55 || Machine_model == SW55L)
void light_control(void)
{
	uint32_t Clean_Motor_Notify = light_reboot;
    uint32_t notify_val = 0;
    BaseType_t err;
	static uint8_t light_flag = 0,light_times = 0; //ֻ�еƴ�״̬�ı�ʱ�ı���ɫ
	
	connection_time = HAL_GetTick();
	err = xTaskNotifyWait(0,Clean_Motor_Notify,&notify_val,0);
	if (err == pdPASS)
	{
		if ((notify_val & light_reboot) == light_reboot)
			light_times = 0;
		else if((notify_val & connection_flag) == connection_flag)
		{
			connection_time_last = connection_time;
		}
	}
	
	if (Stop_Mode == 1 || Stop_Mode == 2)
	{
		if (light_flag != 1)
		{
			light_times = 0;
			light_flag = 1;
		}
	}
	else if (connection_time - connection_time_last > 3000 && connection_time > 1000 * 60 * 2 && connection_time >= connection_time_last)
	{
		if(light_flag !=4)
		{
		  light_times = 0;
		  light_flag = 4;
		}
	}
	else if(BAT.STA == 1)
	{
		if(BAT.SOC < 5){
		  if(light_flag !=7)
		   {
		     light_times = 0;
		     light_flag = 7;
	 	   }
		}
		else if(BAT.SOC > 4 && BAT.SOC < 18)
		{
		  if(light_flag !=2)
		   {
		     light_times = 0;
		     light_flag = 2;
	 	   }	
		}else if(BAT.SOC > 17 && BAT.SOC < 77)
		{
		   if(light_flag !=5)
		   {
		     light_times = 0;
		     light_flag = 5;
	 	   }
		}else if(BAT.SOC > 76)
    {
			
		   if(light_flag !=6)
		   {
		     light_times = 0;
		     light_flag = 6;
	 	   }
		}
		
	}
	else
	{
		if(BAT.SOC < 18){
		  if (light_flag != 8)
		  {
			light_times = 0;
			light_flag = 8;
		  }
		} else {
		if (light_flag != 3)
		{
			light_times = 0;
			light_flag = 3;
		}
	 }
	}
	
	if (light_times < 3)
	{
		switch(light_flag)
		{
			case 1:				//��ͣ ���
//				Set_Color_Front(255, 0, 0);
//				Set_Color(255, 0, 0);
			Can_Send_Msg(light_id,red);
				color = 1;
				break;
			
			case 2:				//��� ��ɫ ������
//				if(BAT.SOC < 21)	//5% < X <= 20%  ��ɫ����
		//		{
					//Breathing_lights(255,165,0,100);
					Can_Send_Msg(light_id,orange);
		//		}
//				else if (BAT.SOC > 20 && BAT.SOC < 91)	//20% < X <= 90% ��ɫ����
//				{
////					ws2812_breathe(2);
////					delay_ms(2);
////					ws2812_breathe_Front(2);
////					delay_ms(2);
//					Can_Send_Msg(light_id,greenbreath);
//				}
//				else if (BAT.SOC > 90)	//90% ������ɫ����
//				{
////					Set_Color_Front(0,255,0);
////					Set_Color(0,255,0);
//					Can_Send_Msg(light_id,green);
//				}
//				color = 2;
				break;
//			
			case 3:				//��ͨ��� ����
//				Set_Color_Front(0, 0, 255);
//				Set_Color(0, 0, 255);
//			 if(MODBUS_OK == ModbusRTU_WriteSingleCoil(0x01, 0x0007, 1)){   //  �ӻ� 0x01����Ȧ��ַ 0x0007��д 1 = ��ɫ
//        			 
//			 }
			Can_Send_Msg(light_id,blue);
				color = 3;
				break;
			
			case 4:				//���� ��ɫ������
//				Breathing_lights(128, 0, 128,30);
			Can_Send_Msg(light_id,purple);
				color = 4;
				break;
			case 5:
			Can_Send_Msg(light_id,greenbreath);
			  break;
			case 6:
			Can_Send_Msg(light_id,green);
		  	break;
			case 7:
			Can_Send_Msg(light_id,redbreath);
			 break;
			case 8:
			Can_Send_Msg(light_id,orangeflicker);	
			 break;
		}
		light_times ++;
	}  

	/*if (Stop_Mode == 1 || Stop_Mode == 2)
	{
		Set_Color_Front(255, 0, 0);
		Set_Color(255, 0, 0);
		color = 1;
	}
	else if (connection_time - connection_time_last > 3000 && connection_time > 1000 * 60 * 2 && connection_time >= connection_time_last)
	{
		Breathing_lights(128, 0, 128,30);
		color = 4;
	}
	else if(BAT.STA == 1)//��� ��ɫ ������
	{			
		if(BAT.SOC < 21)	//5% < X <= 20%  ��ɫ����
		{
			Breathing_lights(255,165,0,100);
		}
		else if (BAT.SOC > 20 && BAT.SOC < 91)	//20% < X <= 90% ��ɫ����
		{
			ws2812_breathe(2);
			delay_ms(2);
			ws2812_breathe_Front(2);
			delay_ms(2);
		}
		else if (BAT.SOC > 90)	//90% ������ɫ����
		{
			Set_Color_Front(0,255,0);
			Set_Color(0,255,0);
		}
		color = 2;
	}
	else
	{
		Set_Color_Front(0, 0, 255);
		Set_Color(0, 0, 255);
		color = 3;
	}
	
	if (color_type[i-1] != color && send_end_flag == 0 && clean_color == 0)
	{
		color_type[i] = color;
		color_times[i] ++;
		i ++;
		if (i >= 100)
			i = 1;
	}
	else if (color_times[i-1] < 200 && send_end_flag == 0 && clean_color == 0)
	{
		color_times[i-1] ++;
	}
	else if (send_end_flag)
	{
		color_send[0] = color_type[send_num];
		color_send[1] = color_times[send_num];
		send_num ++;
		color_send[2] = color_type[send_num];
		color_send[3] = color_times[send_num];
		send_num ++;
		color_send[4] = color_type[send_num];
		color_send[5] = color_times[send_num];
		send_num ++;
		color_send[6] = color_type[send_num];
		color_send[7] = color_times[send_num];
		send_num ++;
		Can_Send_Msg(0x123,color_send);
		
		if (color_type[send_num] == 0)
		{
			send_end_flag = 0;
			send_num = 0;
		}
	}
	else if (clean_color)
	{
		send_num = 0;
		while(color_type[send_num])
		{
			color_type[send_num] = 0;
			color_times[send_num] = 0;
			send_num ++;
		}
		send_num = 0;
		clean_color = 0;
		i= 0;
	}
	*/
}
#elif(Machine_model == SW80)
void light_control(void)
{
	uint32_t Clean_Motor_Notify = light_reboot;
    uint32_t notify_val = 0;
    BaseType_t err;
	static uint8_t light_flag = 0,light_times = 0; 
    
	err = xTaskNotifyWait(0,Clean_Motor_Notify,&notify_val,0);
	if ((notify_val & light_reboot) == light_reboot && err == pdPASS)
		light_times = 0;
	
	if (Stop_Mode == 1 || Stop_Mode == 2)
	{
		if (light_flag != 1)
		{
			light_times = 0;
			light_flag = 1;
		}
	}
	else if(BAT.STA == 1)
	{
		light_times = 0;
		light_flag = 2;
	}
	else
	{
		if (light_flag != 3)
		{
			light_times = 0;
			light_flag = 3;
		}
	}
	
	if (light_times < 3)
	{
		switch(light_flag)
		{
			case 1:				//��ͣ �Ƶ�
				Set_Color(255, 0, 0);
				Set_Color_Front(255, 0, 0);
				break;
			
			case 2:				//��� ������
				ws2812_breathe(2);
				delay_ms(2);
				ws2812_breathe_Front(2);
				delay_ms(2);
				break;
			
			case 3:				//��ͨ��� 
                Set_Color_Front(50,150,23);//�������̵�
                Set_Color(50,150,23);//�������̵�
				break;
		}
		light_times ++;
	}
}

#endif

void check_flash(void)
{
	for(int i=0;i<25;i++)
	{
		if (flash_params[i+8] != 0xffff)
		{
			task_stack_overflow = 1;// ����ջ�����־λ
			printf("ջ���\r\n");
			break;
		}
	}
	
	if (task_stack_overflow)
	{
		for(int i=0;i<25;i++)
		{
			task_stack_overflowbuf[2*i+1] = flash_params[8+i];
			task_stack_overflowbuf[2*i] = flash_params[8+i] >> 8;
		}
		printf("task_stack_overflow:%s \r\n", (char *)task_stack_overflowbuf);
	}
}

/*static void active_stack_overflow(void)//�������������ջ���(�����汾��һ��)
{
	uint8_t num1[100] = {0};
	uint16_t num2[50]= {0},num3[50] = {0};
	
	for(int i=0;i<100;i++)
		num1[i] = i+1;
	
	combineCharArrayToUint16Array((char *)num1,num2,100);
	
	STMFLASH_Write(stop_Addr,num2,50);
	delay_ms(100);
	STMFLASH_Read(stop_Addr,num3,50);
	
	HAL_IWDG_Refresh(&hiwdg);   //���Ź�ι��
	for(int i=0;i<25;i++)
	{
		HAL_IWDG_Refresh(&hiwdg);   //���Ź�ι��
		printf("%x ",num3[i]);
		delay_ms(100);
	}
	HAL_IWDG_Refresh(&hiwdg);   //���Ź�ι��
	printf("\n");
}*/
