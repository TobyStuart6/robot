#include "Motor_Task.h"
EventGroupHandle_t MotorOnlineEventGroupHandler; // �¼���־����
SPEED_DATA Speed_Data = {0};

uint8_t stop_time = 0;

volatile uint8_t RPM_Set[8] = {0x23, 0xff, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00}; // ����Ϊ�ٶ����132RPM �ٶ�=����ֵ ����ֱ�����븺������ֵ����

const uint8_t NODE_STA_Motor[2] = {0x01, 0x00};											// ���ýڵ�Ϊ�ɲ�����,����������
const uint8_t PVM_Motor[8] = {0x2f, 0x60, 0x60, 0x00, 0x03, 0x00, 0x00, 0x00};			// PVMģʽ���滮�ٶ�ģʽ
const uint8_t Enable_Motor_READY[8] = {0x2b, 0x40, 0x60, 0x00, 0x06, 0x00, 0x00, 0x00}; // ʹ�ܵ��׼��
const uint8_t Enable_Motor[8] = {0x2b, 0x40, 0x60, 0x00, 0x0f, 0x00, 0x00, 0x00};		// ʹ�ܵ��
const uint8_t Disable_Motor[8] = {0x2b, 0x40, 0x60, 0x00, 0x07, 0x00, 0x00, 0x00};		// ʧ�ܵ��
const uint8_t Stop_Motor[8] = {0x23, 0xff, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00};			// ֹͣ���--ͨ���趨�ٶ�Ϊ0ʵ��
const uint8_t Read_Position[8] = {0x40, 0x63, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00};		// ��ȡ������λ��
// const uint8_t accelerated_speed[8] 	= {0x23,0x83,0x60,0x00,0xD0,0x40,0x00,0x00};   //���ü��ٶ�
const uint8_t accelerated_speed[8] = {0x23, 0x83, 0x60, 0x00, 0x88, 0x13, 0x00, 0x00}; // ���ü��ٶ�
// const uint8_t deceleration_speed[8] = {0x23,0x84,0x60,0x00,0xE8,0x03,0x00,0x00};   //���ü��ٶ�		1000ms
// const uint8_t deceleration_speed[8] = {0x23,0x84,0x60,0x00,0xF4,0x01,0x00,0x00};   //���ü��ٶ� 	500ms
const uint8_t deceleration_speed[8] = {0x23, 0x84, 0x60, 0x00, 0xFA, 0x0, 0x00, 0x00}; // ���ü��ٶ�		250ms

const uint8_t Reduce_Electricity_6A_1[8] = {0x23, 0x2A, 0x24, 0x00, 0x58, 0x02, 0x00, 0x00};  // ���״̬�¼��ٵ������Ϊ6A
const uint8_t Reduce_Electricity_6A_2[8] = {0x23, 0x2A, 0x34, 0x00, 0x58, 0x02, 0x00, 0x00};  //
const uint8_t Recover_Electricity_1[8] = {0x23, 0x2A, 0x24, 0x00, 0xB8, 0x0B, 0x00, 0x00};	  // ����״̬�»ָ��������Ϊ30A
const uint8_t Recover_Electricity_2[8] = {0x23, 0x2A, 0x34, 0x00, 0xB8, 0x0B, 0x00, 0x00};	  //
const uint8_t Reduce_Electricity_10A_1[8] = {0x23, 0x2A, 0x24, 0x00, 0xE8, 0x03, 0x00, 0x00}; // ���״̬�¼��ٵ������Ϊ10A
const uint8_t Reduce_Electricity_10A_2[8] = {0x23, 0x2A, 0x34, 0x00, 0xE8, 0x03, 0x00, 0x00}; //

static uint8_t Read_motor_fault_status_L[8] = {0x40, 0x12, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00};	 // ��ȡ��������״̬
static uint8_t Read_motor_fault_status_R[8] = {0x40, 0x12, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00};	 // ��ȡ�ҵ������״̬
static uint8_t Clear_motor_fault_state[8] = {0x23, 0x02, 0x46, 0x00, 0x01, 0x00, 0x00, 0x00};	 // ����������״̬
static uint8_t Read_R_motor_current_value[8] = {0x40, 0x02, 0x51, 0x00, 0x00, 0x00, 0x00, 0x00}; // ��ȡ��챵������
static uint8_t Read_L_motor_current_value[8] = {0x40, 0x02, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00}; // ��ȡ��챵������
#if (Machine_model == SW55 || Machine_model == SW55L)
static uint8_t Write_P_param_L[8] = {0X2B, 0X00, 0X23, 0X00, 0X5A, 0X00, 0X00, 0X00}; // �����ٶȻ���һ��������
static uint8_t Write_P_param_R[8] = {0X2B, 0X00, 0X33, 0X00, 0X5A, 0X00, 0X00, 0X00}; // �����ٶȻ���һ��������
static uint8_t Write_I_param_L[8] = {0X2B, 0X01, 0X23, 0X00, 0X01, 0X00, 0X00, 0X00}; // �����ٶȻ���һ��������
static uint8_t Write_I_param_R[8] = {0X2B, 0X01, 0X33, 0X00, 0X01, 0X00, 0X00, 0X00}; // �����ٶȻ���һ��������
static uint8_t Write_D_param_L[8] = {0X2B, 0X02, 0X23, 0X00, 0X02, 0X00, 0X00, 0X00}; // �����ٶȻ���һ΢������
static uint8_t Write_D_param_R[8] = {0X2B, 0X02, 0X33, 0X00, 0X02, 0X00, 0X00, 0X00}; // �����ٶȻ���һ΢������
#endif
const uint8_t TPDO1_6063H_1[8] = {0x2F, 0x00, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO1 stop
const uint8_t TPDO1_6063H_2[8] = {0x23, 0x00, 0x1A, 0x01, 0x20, 0x00, 0x63, 0x60}; // 6063H
const uint8_t TPDO1_6063H_3[8] = {0x2F, 0x00, 0x1A, 0x00, 0x01, 0x00, 0x00, 0x00}; // TPDO1 enable
const uint8_t TPDO1_6063H_4[8] = {0x2F, 0x00, 0x18, 0x05, 0x0A, 0x00, 0x00, 0x00}; // 10ms�ϱ�һ��
const uint8_t TPDO1_6063H_5[8] = {0x2F, 0x00, 0x18, 0x03, 0x0A, 0x00, 0x00, 0x00}; //
const uint8_t TPDO1_6063H_6[8] = {0x2F, 0x00, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //

const uint8_t TPDO2_3000H_1[8] = {0x2F, 0x01, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO2 stop
const uint8_t TPDO2_3000H_2[8] = {0x23, 0x01, 0x1A, 0x01, 0x10, 0x00, 0x6C, 0x60}; //[4] 20 - 10
const uint8_t TPDO2_3000H_3[8] = {0x2F, 0x01, 0x1A, 0x00, 0x02, 0x00, 0x00, 0x00}; // TPDO2 enable[4] 02 - 01
const uint8_t TPDO2_3000H_4[8] = {0x2F, 0x01, 0x18, 0x05, 0x64, 0x00, 0x00, 0x00}; // 100ms�ϱ�һ��
const uint8_t TPDO2_3000H_5[8] = {0x2F, 0x01, 0x18, 0x03, 0x64, 0x00, 0x00, 0x00}; //
const uint8_t TPDO2_3000H_6[8] = {0x2F, 0x01, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //

const uint8_t TPDO3_6069H_1[8] = {0x2F, 0x02, 0x1A, 0x00, 0x00, 0x00, 0x00, 0x00}; // TPDO3 stop
const uint8_t TPDO3_6069H_2[8] = {0x23, 0x02, 0x1A, 0x01, 0x20, 0x00, 0x69, 0x60}; // 6069H
const uint8_t TPDO3_6069H_3[8] = {0x2F, 0x02, 0x1A, 0x00, 0x03, 0x00, 0x00, 0x00}; // TPDO enable[4] 02 - 01
const uint8_t TPDO3_6069H_4[8] = {0x2F, 0x02, 0x18, 0x05, 0x0a, 0x00, 0x00, 0x00}; // 10ms�ϱ�һ��
const uint8_t TPDO3_6069H_5[8] = {0x2F, 0x02, 0x18, 0x03, 0x0a, 0x00, 0x00, 0x00}; //
const uint8_t TPDO3_6069H_6[8] = {0x2F, 0x02, 0x18, 0x02, 0xFE, 0x00, 0x00, 0x00}; //
osEvent Reset_Stop_Event, Open_Motor_Power_Event, Motor_Init_Event;

void Motor_Task(void const *argument)
{
	// osEvent event;
	// HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,FAN_PWR_EN_Pin|DIS_PWR_EN_Pin|EC20_PWR_EN_Pin|RS3_PWR_EN_Pin|RS4_PWR_EN_Pin,GPIO_PIN_SET); //·����
	Close_ALL_Power(); // �ر����������Դ

	// ��鵽PDU������ɺ����ֱ�Ӵ�PAD�͹��ػ����磬���û�м�⵽��־λ��
	static uint16_t pdu_ota_state_OP = 0;
	STMFLASH_Read(PDU_OTA_State, &pdu_ota_state_OP, 1);
	// Motor_Task��Data_Task�ȴ��������Ա�־λPDU_OTA_State��Data_Task��������
	if (pdu_ota_state_OP != 1)
	{
		// delay_ms(2000);
	//	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);					  // ƽ���Դ
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);						  // ���ػ���Դ
		HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);					  // ����������� ��pdu�ͷ��
		HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_SET);			  // breakout�ĵ�Դ
//		HAL_GPIO_WritePin(CORE_EN_GPIO_Port, CORE_EN_Pin, GPIO_PIN_SET);		  // breakout�ĵ�Դ
																				  //	HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port, RTR_PWR_EN_Pin, GPIO_PIN_SET);	  // PAD��Դ
		HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET);	  // ���ػ�
		HAL_GPIO_WritePin(GPIOB, OUT_MTR_Pin, GPIO_PIN_SET);					  // ��ʼ����Դ״̬->��챵����Դ
//		HAL_GPIO_WritePin(GPIOB, FAN_PWR_EN_Pin, GPIO_PIN_SET);					  
//		HAL_GPIO_WritePin(GPIOB, EC20_PWR_EN_Pin | RS3_PWR_EN_Pin, GPIO_PIN_SET); // ·����
																				  // HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,RS4_PWR_EN_Pin,GPIO_PIN_SET);
	}
	else if (pdu_ota_state_OP == 1)
	{
		delay_ms(2000);
	//	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET);					  // ƽ���Դ
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);						  // ���ػ���Դ
		HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);					  // ����������� ��pdu�ͷ��
		HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_SET);			  // breakout�ĵ�Դ
//		HAL_GPIO_WritePin(CORE_EN_GPIO_Port, CORE_EN_Pin, GPIO_PIN_SET);		  // breakout�ĵ�Դ
																				  //	HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port, RTR_PWR_EN_Pin, GPIO_PIN_SET);	  // PAD��Դ
		HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET);	  // ���ػ�
		HAL_GPIO_WritePin(GPIOB, OUT_MTR_Pin, GPIO_PIN_SET);					  // ��ʼ����Դ״̬->��챵����Դ
//		HAL_GPIO_WritePin(GPIOB, FAN_PWR_EN_Pin, GPIO_PIN_SET);					 
//		HAL_GPIO_WritePin(GPIOB, EC20_PWR_EN_Pin | RS3_PWR_EN_Pin, GPIO_PIN_SET); // ·����

		// ���PDU OTA״̬��־�������´���������ʱ����
		uint16_t clear_flag = 0xFFFF;				   // ʹ��0xFFFF��ʾδ����OTA���Ѵ���
		STMFLASH_Write(PDU_OTA_State, &clear_flag, 1); // HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,RS4_PWR_EN_Pin,GPIO_PIN_SET);
	}

#if (Machine_model == SW55 || Machine_model == SW55L)
	while (1)
	{
		Open_Motor_Power_Event = osSignalWait(EVENTBIT_1, 2000); /* �ȴ��������,һֱ�� */
																 //		if(Open_Motor_Power_Event.status == osEventSignal)
																 //		{
																 //			if((Open_Motor_Power_Event.value.signals&0x02) == 0x02)
																 //			{
		Motor_Init(MOTOR_R_CAN_ID);
		Motor_Init(MOTOR_L_CAN_ID);
		printf("��ʼ�����\r\n");
		delay_ms(10);
		Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_P_param_L);
		delay_ms(10);
		Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_P_param_R);
		delay_ms(10);
		Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_I_param_L);
		delay_ms(10);
		Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_I_param_R);
		delay_ms(10);
		Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_D_param_L);
		delay_ms(10);
		Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_D_param_R);
		delay_ms(10);
		break;
		//			}
		//		}
		//		delay_ms(10);
	}
#elif (Machine_model == SW80)
	while (1)
	{
		Open_Motor_Power_Event = osSignalWait(EVENTBIT_1, osWaitForever); /* �ȴ��������,һֱ�� */
		if (Open_Motor_Power_Event.status == osEventSignal)
		{
			if ((Open_Motor_Power_Event.value.signals & 0x02) == 0x02)
			{
				Motor_Init(MOTOR_R_CAN_ID);
				Motor_Init(MOTOR_L_CAN_ID);
				printf("��ʼ�����\r\n");
				break;
			}
		}
		delay_ms(10);
	}
#endif

	const TickType_t Motor_TimeIncrement = pdMS_TO_TICKS(30); // ��ʱ30ms������ʱʱ��ת��Ϊ������
	TickType_t lasttick = xTaskGetTickCount();
	while (1)
	{
		//		Open_Motor_Power_Event = osSignalWait(EVENTBIT_1,0);
		//		if(Open_Motor_Power_Event.status == osEventSignal)
		//		{
		//			if((Open_Motor_Power_Event.value.signals&0x02) == 0x02)
		//			{
		//			  Motor_set();
		//			}
		//		}
		MY_ERROR.tasks_heart.motor = 0;
		Motor_Control();
		if (Stop_Mode == 1 || Stop_Mode == 2)
		{
			Set_Motor(0, 0);
			delay_ms(10);
			if (stop_time >= 50)
			{
				if (low_power_sta == 0)
				{
					Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Disable_Motor);
					Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Disable_Motor);
				}
			}
			else
				stop_time++;
		}
		else if (Stop_Mode == 0)
		{
			stop_time = 0;
		}

//		Reset_Stop_Event = osSignalWait(Reset_Emergency_Stop_Event, 0); /* �ȴ���ͣ��λ */
//		if ((Reset_Stop_Event.status == osEventSignal) && (Reset_Stop_Event.value.signals & 0x08))
//		{
//			//			HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_SET);  //������챵����Դ
//			//			osSignalWait(EVENTBIT_ALL,osWaitForever);    /* �ȴ��������,һֱ�� */
//			//			Motor_Init(MOTOR_L_CAN_ID);
//			//			Motor_Init(MOTOR_R_CAN_ID);
//		if(hard_auto_sta == 0 ||low_power_sta == 1){
//			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Enable_Motor);
//			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID,(uint8_t*)Enable_Motor);
//			}
//		}

		osEvent queue_event = osMessageGet(Reset_Stop_Queue, 0);
		if (queue_event.status == osEventMessage) 
     {
    // ��ȡ��Ϣ����
    uint32_t message_content = queue_event.value.v;
    
    // �ж���Ϣ�����Ƿ�Ϊ���Ƕ���� "1" (��λָ��)
    if (message_content == 1) 
        {
       
        if (hard_auto_sta == 0 || low_power_sta == 1) {
             
             Multiple_Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t*)Enable_Motor);
             Multiple_Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t*)Enable_Motor);
           }
         }
     }
		if (Stop_Mode == 0 && (flag_charge_sta == 0 || flag_charge_sta == 1))
		{
			Set_Motor(Speed.angular, Speed.linear);
		}
		else if (flag_charge_sta == 2 || flag_charge_sta == 3)
		{
			Set_Motor(0, 0);
		}
		else
		{
			Set_Motor(0, 0);
		}

		Read_Position_Message();
		vTaskDelayUntil(&lasttick, Motor_TimeIncrement);
	}
}
void Motor_Control(void)
{
	uint32_t Clean_Motor_Notify = 0;
	uint32_t notify_val = 0;
	BaseType_t err;
	Clean_Motor_Notify = Motor_Enable | Motor_Disable | Recover_Electricity | Reduce_Electricity_6A | Reduce_Electricity_10A | Read_Motor_eor | Clean_Motor_eor_l |
						 Clean_Motor_eor_r | Inquire_Motor_current | Motor_Init_Bit8;
	err = xTaskNotifyWait(0, Clean_Motor_Notify, &notify_val, 0);
	if (err == pdPASS) // ����֪ͨ��ȡ�ɹ�
	{				   // ʧ�� �� ʹ��
		if (((notify_val & Motor_Enable) == Motor_Enable) && ((notify_val & Motor_Disable) == 0))
		{
			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Enable_Motor);
			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Enable_Motor);
		}
		else if (((notify_val & Motor_Disable) == Motor_Disable) && ((notify_val & Motor_Enable) == 0))
		{
			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Disable_Motor);
			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Disable_Motor);
		}
		// ������Ƶ����ͻָ�����
		if (((notify_val & Recover_Electricity) == Recover_Electricity) && ((notify_val & Reduce_Electricity_6A) == 0) && ((notify_val & Reduce_Electricity_10A) == 0))
		{
			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Recover_Electricity_1);
			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Recover_Electricity_2);
		}
		else if (((notify_val & Recover_Electricity) == 0) && ((notify_val & Reduce_Electricity_6A) == Reduce_Electricity_6A) && ((notify_val & Reduce_Electricity_10A) == 0))
		{
			Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Reduce_Electricity_6A_1);
			Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Reduce_Electricity_6A_2);
		}
		else if (((notify_val & Recover_Electricity) == 0) && ((notify_val & Reduce_Electricity_6A) == 0) && ((notify_val & Reduce_Electricity_10A) == Reduce_Electricity_10A))
		{
			Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Reduce_Electricity_10A_1);
			Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Reduce_Electricity_10A_2);
		}
		// ��ѯ����״̬���������״̬
		if ((notify_val & Read_Motor_eor) == Read_Motor_eor)
		{
			Can_Send_Msg(MOTOR_L_CAN_ID, Read_motor_fault_status_L); // 1S��ѯ�������״̬
			delay_ms(3);
			Can_Send_Msg(MOTOR_R_CAN_ID, Read_motor_fault_status_R); // 1S��ѯ�������״̬
		}
		else if ((notify_val & Clean_Motor_eor_l) == Clean_Motor_eor_l)
		{
			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID, Clear_motor_fault_state); // �������״̬
			printf("clean wheel motor error state 2L\n");
		}
		else if ((notify_val & Clean_Motor_eor_r) == Clean_Motor_eor_r)
		{
			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID, Clear_motor_fault_state); // �������״̬
			printf("clean wheel motor error state 2R\n");
		}

		if ((notify_val & Inquire_Motor_current) == Inquire_Motor_current)
		{
			Can_Send_Msg(MOTOR_L_CAN_ID, Read_L_motor_current_value); // ��ѯ������챵������
			Can_Send_Msg(MOTOR_R_CAN_ID, Read_R_motor_current_value); // ��ѯ������챵������
		}
		if ((notify_val & Motor_Init_Bit8) == Motor_Init_Bit8)
		{
			HAL_GPIO_WritePin(GPIOB, OUT_MTR_Pin, GPIO_PIN_SET); // ������챵����Դ
			osSignalWait(EVENTBIT_ALL, 2000);					 /* �ȴ��������,һֱ�� */
			Motor_Init(MOTOR_L_CAN_ID);
			Motor_Init(MOTOR_R_CAN_ID);
		}
	}
	else
		delay_ms(5);
}
void Motor_Init(uint32_t ID)
{
	delay_ms(50);
	while (1)
	{
		for (int i = 0; i < 3; i++)
		{
			Can_Send_Msg_Cnt(0x000, (uint8_t *)NODE_STA_Motor, 2);
			delay_ms(50);
		}
		// step2:SET accelerated_speed
		Can_Send_Msg(ID, (uint8_t *)accelerated_speed);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit1, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit1) == Motor_Init_Bit1)
		{
			break;
		}
		delay_ms(100);
	}
	while (1)
	{
		Can_Send_Msg(ID, (uint8_t *)deceleration_speed);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit2, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit2) == Motor_Init_Bit2)
		{
			break;
		}
	}
	while (1)
	{
		// step3:SET PVM
		Can_Send_Msg(ID, (uint8_t *)PVM_Motor);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit3, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit3) == Motor_Init_Bit3)
		{
			break;
		}
	}
	while (1)
	{

		// STEP4��SET V = 0��
		Can_Send_Msg(ID, (uint8_t *)Stop_Motor);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit4, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit4) == Motor_Init_Bit4)
		{
			break;
		}
	}
	while (1)
	{
		// step5:SET ENABLE :��һ��ʹ����Ҫ����3��ָ��
		Can_Send_Msg(ID, (uint8_t *)Enable_Motor_READY);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit5, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit5) == Motor_Init_Bit5)
		{
			break;
		}
	}
	while (1)
	{
		// step5:SET ENABLE :��һ��ʹ����Ҫ����3��ָ��
		Can_Send_Msg(ID, (uint8_t *)Disable_Motor);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit6, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit6) == Motor_Init_Bit6)
		{
			break;
		}
	}

	while (1)
	{
		// step5:SET ENABLE :��һ��ʹ����Ҫ����3��ָ��
		Can_Send_Msg(ID, (uint8_t *)Enable_Motor);
		Motor_Init_Event = osSignalWait(Motor_Init_Bit7, 10);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Bit7) == Motor_Init_Bit7)
		{
			break;
		}
	}

	while (1)
	{
		// TPdo1
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_1);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo1, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo1) == Motor_Init_Tpdo1)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_2);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo2, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo2) == Motor_Init_Tpdo2)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo3
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_3);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo3, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo3) == Motor_Init_Tpdo3)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo4
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_4);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo4, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo4) == Motor_Init_Tpdo4)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo5
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_5);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo5, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo5) == Motor_Init_Tpdo5)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo6
		Can_Send_Msg(ID, (uint8_t *)TPDO1_6063H_6);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo6, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo6) == Motor_Init_Tpdo6)
		{
			break;
		}
	}
	/**/ while (1)
	{
		// TPdo2.1
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_1);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo1, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo1) == Motor_Init_Tpdo1)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.2
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_2);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo2, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo2) == Motor_Init_Tpdo2)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.3
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_3);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo3, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo3) == Motor_Init_Tpdo3)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.4
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_4);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo4, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo4) == Motor_Init_Tpdo4)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.5
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_5);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo5, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo5) == Motor_Init_Tpdo5)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO2_3000H_6);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo6, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo6) == Motor_Init_Tpdo6)
		{
			break;
		}
	}
	/**/
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_1);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo1, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo1) == Motor_Init_Tpdo1)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_2);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo2, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo2) == Motor_Init_Tpdo2)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_3);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo3, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo3) == Motor_Init_Tpdo3)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_4);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo4, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo4) == Motor_Init_Tpdo4)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_5);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo5, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo5) == Motor_Init_Tpdo5)
		{
			break;
		}
	}
	while (1)
	{
		// TPdo2.6
		Can_Send_Msg(ID, (uint8_t *)TPDO3_6069H_6);
		Motor_Init_Event = osSignalWait(Motor_Init_Tpdo6, 20);
		if ((Motor_Init_Event.status == osEventSignal) && (Motor_Init_Event.value.signals & Motor_Init_Tpdo6) == Motor_Init_Tpdo6)
		{
			break;
		}
	}
}
void Set_Walkingmotor(uint32_t ID, int32_t speed) // rpm
{
	uint8_t *data;
	speed = speed * 10;
	data = (uint8_t *)&speed;
	for (int i = 4; i < 8; i++)
	{
		RPM_Set[i] = data[i - 4];
	}

	Can_Send_Msg(ID, (uint8_t *)RPM_Set);
}
void Read_Position_Message(void)
{
	Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Read_Position);
	Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Read_Position);
}

#if (Machine_model == SW55 || Machine_model == SW55L)
void Set_Motor(float angular_temp, float linear_temp)
{
	Speed_Data.left = linear_temp - 0.5f * angular_temp * Wheels_Distance;
	Speed_Data.right = linear_temp + 0.5f * angular_temp * Wheels_Distance;
	Speed_Data.left = Speed_Data.left * 60 / Wheel_Circumference;
	Speed_Data.right = -(Speed_Data.right * 60 / Wheel_Circumference);
	if ((fabs(Speed_Data.left) < 180) && (fabs(Speed_Data.right) < 180))
	{
		Set_Walkingmotor(MOTOR_L_CAN_ID, Speed_Data.left);
		Set_Walkingmotor(MOTOR_R_CAN_ID, Speed_Data.right);
	}
	else
	{
		Set_Walkingmotor(MOTOR_L_CAN_ID, 0);
		Set_Walkingmotor(MOTOR_R_CAN_ID, 0);
	}
}
#elif (Machine_model == SW80)
void Set_Motor(float angular_temp, float linear_temp)
{
	Speed_Data.left = linear_temp - 0.5f * angular_temp * Wheels_Distance;
	Speed_Data.right = linear_temp + 0.5f * angular_temp * Wheels_Distance;
	Speed_Data.left = Speed_Data.left * 60 / Wheel_Circumference;
	Speed_Data.right = -(Speed_Data.right * 60 / Wheel_Circumference);
	if ((fabs(Speed_Data.left) < 180) && (fabs(Speed_Data.right) < 180))
	{
		// ������ײ�����ƶ�
		if (Sensor.Front_Bump_Flag == 1)
		{
			if (Speed_Data.left < 0)
			{
				Speed_Data.left = 0;
			}
			if (Speed_Data.right > 0)
			{
				Speed_Data.right = 0;
			}
		}
		if (Sensor.Back_Bump_Flag == 1)
		{
			if (Speed_Data.left > 0)
			{
				Speed_Data.left = 0;
			}
			if (Speed_Data.right < 0)
			{
				Speed_Data.right = 0;
			}
		}
		Set_Walkingmotor(MOTOR_L_CAN_ID, Speed_Data.left);
		Set_Walkingmotor(MOTOR_R_CAN_ID, Speed_Data.right);
	}
	else
	{
		Set_Walkingmotor(MOTOR_L_CAN_ID, 0);
		Set_Walkingmotor(MOTOR_R_CAN_ID, 0);
	}
}
#endif

void Motor_set(void)
{
	Motor_Init(MOTOR_R_CAN_ID);
	Motor_Init(MOTOR_L_CAN_ID);
	printf("��ʼ�����\r\n");
	delay_ms(10);
	Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_P_param_L);
	delay_ms(10);
	Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_P_param_R);
	delay_ms(10);
	Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_I_param_L);
	delay_ms(10);
	Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_I_param_R);
	delay_ms(10);
	Can_Send_Msg(MOTOR_L_CAN_ID, (uint8_t *)Write_D_param_L);
	delay_ms(10);
	Can_Send_Msg(MOTOR_R_CAN_ID, (uint8_t *)Write_D_param_R);
	delay_ms(10);
}
