#ifndef __MOTOR_TASK_H
#define __MOTOR_TASK_H
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "Can_Task.h"
#include "can.h"
#include "Time.h"
#include "FreeRTOSConfig.h"
#include "Data_Task.h"
#include "Peripheral_Control_task.h"
#include "math.h"
#include "pdu_iap.h"

#define EVENTBIT_0	(1<<0)				//���������¼���־λ
#define EVENTBIT_1	(1<<1)         //���������¼���־λ
#define EVENTBIT_ALL	(EVENTBIT_0|EVENTBIT_1)   

#define Reset_Emergency_Stop_Event	(1<<3)				//��ͣ��λ�¼�

#define MOTOR_L_CAN_ID 0x0601
#define MOTOR_R_CAN_ID 0x0602

#define Rceive_MOTOR_L_CAN_ID 0x0581
#define Rceive_MOTOR_R_CAN_ID 0x0582


//#define Wheels_Distance     0.53170   //���ּ�࣬��λ��m
//#define Wheel_Circumference 0.4084   //�����ܳ�����λ��m//ֱ��Ϊ130mm

//#define Wheels_Distance     0.5850   //���ּ�࣬��λ��m
//#define Wheel_Circumference 0.4398   //�����ܳ�����λ��m//ֱ��Ϊ140mm

#define Motor_Init_Bit1  1<<4
#define Motor_Init_Bit2  1<<5
#define Motor_Init_Bit3  1<<6
#define Motor_Init_Bit4  1<<7
#define Motor_Init_Bit5  1<<8
#define Motor_Init_Bit6  1<<9
#define Motor_Init_Bit7  1<<10
#define Motor_Init_Bit8  1<<11



#define Motor_Init_Tpdo1  1<<21
#define Motor_Init_Tpdo2  1<<22
#define Motor_Init_Tpdo3  1<<23
#define Motor_Init_Tpdo4  1<<24
#define Motor_Init_Tpdo5  1<<25
#define Motor_Init_Tpdo6  1<<26


#define Motor_Enable            1<<12
#define Motor_Disable           1<<13
#define Recover_Electricity     1<<14
#define Reduce_Electricity_6A   1<<15
#define Reduce_Electricity_10A  1<<16
#define Read_Motor_eor          1<<17
#define Clean_Motor_eor_l       1<<18
#define Clean_Motor_eor_r       1<<19
#define Inquire_Motor_current   1<<20

//extern const uint8_t M_Eable_Motor[8];   //ʹ�ܵ��
//extern const uint8_t M_Disable_Motor[8];   //ʧ�ܵ��

#if (Machine_model == SW55 || Machine_model == SW55L)
#define Wheels_Distance     0.5300   //���ּ�࣬��λ��m
#define Wheel_Circumference 0.4398   //�����ܳ�����λ��m//ֱ��Ϊ140mm
#elif(Machine_model == SW80)
#define Wheels_Distance     0.7400   //���ּ�࣬��λ��m
#define Wheel_Circumference 0.6283   //�����ܳ�����λ��m
#endif
typedef struct
{
	float right;
	float left;
}SPEED_DATA;
extern SPEED_DATA Speed_Data;

void Motor_Init(uint32_t ID);
void Motor_Task(void const * argument);
void Set_Walkingmotor(uint32_t ID , int32_t speed);//rpm
void Set_Motor(float angular_temp,float linear_temp);
void Read_Position_Message(void);
void Motor_Control(void);
void Motor_set(void);
#endif



