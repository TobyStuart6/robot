#include "New_Cleaning_Motor_Control_Task.h"

Clean_Device_Controller_ Clean_Device_Controller = {0};
Clean_Device_Mode_ Clean_Device_Mode = {0};
uint16_t mainMotorSpeed[2] = {0, 0};
uint16_t leftBurshMotorSpeed[2] = {0, 0};
uint16_t rightBurshMotorSpeed[2] = {0, 0};
uint16_t fanMotorSpeed[2] = {0, 0};

uint16_t mainPushMotorPosition = 0;
uint16_t sidePushMotorPosition = 0;
// uint16_t mainPushMotorPosition[4] = {0x03E8,0x0000,0x0000,0x0000};
// uint16_t sidePushMotorPosition[4] = {0x03E8,0x0000,0x0000,0x0000};

// �Ƹ˵��canЭ��
//uint8_t CanPushMotorPosition[8] = {0x2B, 0x49, 0x40, 0x00, 0x00, 0x00, 0x00, 0x00}; // ����λ��
//uint8_t PushMotorSQ1[8] = {0x2B, 0xcf, 0x40, 0x00, 0x02, 0x00, 0x00, 0x00};			// SQ1��λ
//uint8_t PushMotorSQ2[8] = {0x2B, 0xcf, 0x40, 0x00, 0x03, 0x00, 0x00, 0x00};			// SQ2��λ
//uint8_t RevokeMotorPosition[8] = {0x2B, 0xcf, 0x40, 0x00, 0x01, 0x00, 0x00, 0x00};	// ȡ����λ

uint8_t mainpushCan[8] = {0x20,0x00,0x00,0x00,0x00,0x00,0x00,0x00};
uint8_t siderpushCan[8] = {0x21,0x00,0x00,0x00,0x00,0x00,0x00,0x00};

uint8_t poss[9] = {0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99};

uint16_t Do_leftBurshMotorSpeed[2] = {0, 0};
uint16_t Do_mainBurshMotorSpeed[2] = {0, 0};
//uint16_t Do_rightBurshMotorSpeed[2] = {0, 0};
int32_t Do_rightBurshMotorSpeed = 0;
uint16_t Do_fanMotorSpeed[2] = {0, 0};
static uint32_t sidepushtime = 0;
static uint32_t mainpushtime = 0;
void New_Cleaning_Motor_Control_Task(void const *argument)
{
	int cnt = 0;
	ModbusRTU_Init(&huart3);

	delay_ms(2000);
	uint32_t Clean_Device_Controller_Queue_Value = 0; // �ϻ�������������������
	// ��ˢSQ2��λ
//	Can_Send_Msg(sideCanPushMotorID, PushMotorSQ2); // SQ2��λ
//													// ��ˢSQ1��λ
//	Can_Send_Msg(mainCanPushMotorID, PushMotorSQ1); // SQ1��λ
	while (1)
	{

		if (xQueueReceive(Clean_Device_Controller_Queue, &Clean_Device_Controller_Queue_Value, 100))
		{
			Clean_Device_Controller.motor = Clean_Device_Controller_Queue_Value >> 8;
			Clean_Device_Controller.level = Clean_Device_Controller_Queue_Value >> 16;
			Clean_Device_Controller.Mode = Clean_Device_Controller_Queue_Value;
			// �ϲ�Э����8��ʾ�أ�10����Ҳ��8�������߳�ͻ�����Եײ㽫0��ӦΪ��
			if (Clean_Device_Controller.Mode == 8)
				Clean_Device_Controller.Mode = 0;

			Receive_Dn_Cleaning_Controller(Clean_Device_Controller.motor, Clean_Device_Controller.Mode, Clean_Device_Controller.level);
			
		}
		//				   delay_ms(500);
		//	  mainMotorSpeed[1] = 1000;
		//
		//				if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(mainBurshMotorID,0x00,0x02,mainMotorSpeed)){
		//					   Send_Cleaning_Controller_Data.mainbrush_data = 123;//��ˢ
		//					}
		//		   delay_ms(500);
		//	  sidePushMotorPosition[3] = 0;
		//
		//				if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(sidePushMotorID,absolutePositionRegAddr,0x04,sidePushMotorPosition)){
		//					   Send_Cleaning_Controller_Data.sidebrush_data = 123;//��ˢ����
		//					}
		Query_Check_Cleaning_Controller();
		MY_ERROR.tasks_heart.cleaning = 0;
		delay_ms(50);
	}
}

/*
�������ܣ�������λ������������������ָ��
��ڲ�����clean_motor ������ࣻMode��ִ�ж���
����  ֵ��У����
*/
void Receive_Dn_Cleaning_Controller(uint8_t clean_motor, uint8_t Mode, uint8_t level)
{
	// �ϲ�Э����8��ʾ�أ�10����Ҳ��8�������߳�ͻ�����Եײ㽫0��ӦΪ��
	if (Mode == 0 || Mode == 21 || Mode == 22 || Mode == 23 || Mode == 7 || clean_motor == 203)
	{
		switch (clean_motor)
		{
		case 13: // ���ˢ
		{
			if (level > 0 && level <= 10)
			{
//				int32_t leftBurshspeed = -(uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
//				leftBurshMotorSpeed[0] = (uint16_t)(leftBurshspeed >> 16);	  // �� 16 λ
//				leftBurshMotorSpeed[1] = (uint16_t)(leftBurshspeed & 0xFFFF); // �� 16 λ
				
				leftBurshMotorSpeed[1] = (uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				
				int32_t rightBurshspeed = -(uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				rightBurshMotorSpeed[0] = (uint16_t)(rightBurshspeed >> 16);  // �� 16 λ
				rightBurshMotorSpeed[1] = (uint16_t)(rightBurshspeed & 0xFFFF);
//				rightBurshMotorSpeed[1] = (uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);

//				Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
				Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
				Clean_Device_Mode.leftbrushmode = Mode;
			  Do_rightBurshMotorSpeed = rightBurshspeed;
				Clean_Device_Mode.rightbrushmode = Mode;
			}
			else
			{
				leftBurshMotorSpeed[0] = 0;
				leftBurshMotorSpeed[1] = 0;
				rightBurshMotorSpeed[0] = 0;
				rightBurshMotorSpeed[1] = 0;
				Do_leftBurshMotorSpeed[1] = 0;
				Do_rightBurshMotorSpeed = 0;
				Clean_Device_Mode.rightbrushmode = Mode;
				Clean_Device_Mode.leftbrushmode = Mode;
			}

			if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(leftBurshMotorID, 0x00, 0x02, leftBurshMotorSpeed))
			{

				//						if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID,0x00,0x02,rightBurshMotorSpeed)){
				//						 Send_Cleaning_Controller_Data.left_sidebrush_data = Mode;
				//					   Send_Cleaning_Controller_Data.right_sidebrush_data = Mode;
				//				 }
			}
			if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID, 0x00, 0x02, rightBurshMotorSpeed))
			{
				//					   Send_Cleaning_Controller_Data.right_sidebrush_data = Mode;
//				Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
//				Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
//				Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];
			}
		  	
			break;
		}
		case 2: // �ұ�ˢ
		{
			if (level > 0 && level <= 10)
			{
//				rightBurshMotorSpeed[1] = (uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				int32_t rightBurshspeed = -(uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				rightBurshMotorSpeed[0] = (uint16_t)(rightBurshspeed >> 16);  // �� 16 λ
				rightBurshMotorSpeed[1] = (uint16_t)(rightBurshspeed & 0xFFFF);
				Do_rightBurshMotorSpeed = rightBurshspeed;
				Clean_Device_Mode.rightbrushmode = Mode;
			}
			else
			{
				rightBurshMotorSpeed[0] = 0;
				rightBurshMotorSpeed[1] = 0;
				Do_rightBurshMotorSpeed = 0;
				Clean_Device_Mode.rightbrushmode = Mode;
			}
			if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID, 0x00, 0x02, rightBurshMotorSpeed))
			{
				//  Send_Cleaning_Controller_Data.left_sidebrush_data = Mode;
			//	Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];
			}
//			Do_rightBurshMotorSpeed[0] = rightBurshMotorSpeed[0];
//			Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];
			break;
		}
		case 10: // ��ˢ
		{
			if (level > 0 && level <= 10)
			{
				mainMotorSpeed[1] = (uint16_t)(mainbrushMinSpeed + level * mainbrushSpeedStep);
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				Clean_Device_Mode.mainbrushmode = Mode;
			}
			else
			{
				mainMotorSpeed[1] = 0;
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				Clean_Device_Mode.mainbrushmode = Mode;
			}
			if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(mainBurshMotorID, 0x00, 0x02, mainMotorSpeed))
			{
				//  Send_Cleaning_Controller_Data.mainbrush_data = Mode;//��ˢ
			//	Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
			}
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
			break;
		}
		case 31: // ��շ���
		{
			if (level > 0 && level <= 10)
			{
				fanMotorSpeed[1] = (uint16_t)(vacuumfanMinSpeed + level * vacuumfanSpeedStep);
				Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				Clean_Device_Mode.fanmode = Mode;
			}
			else
			{
				fanMotorSpeed[1] = 0;
				Clean_Device_Mode.fanmode = Mode;
			}
			if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(fanMotorID, 0x00, 0x02, fanMotorSpeed))
			{
				//					   Send_Cleaning_Controller_Data.vacuumfan_data = Mode;//���
				//Do_fanMotorSpeed[1] = fanMotorSpeed[1];
			}
			Do_fanMotorSpeed[1] = fanMotorSpeed[1];
			break;
		}
		case 23: // ǰ�˱�ˢ����
		{

//			if (level > 0 && level <= 10)
//			{
////				sidePushMotorPosition = (uint16_t)(sidePushMotorMinPosition + level * sidePushMotorPositionStep);

////				if (sidePushMotorPosition == 0x02EE)
////				{
////					sidePushMotorPosition = 0x00A5;
////				}
////				else if (sidePushMotorPosition == 0x00A5)
////				{
////					sidePushMotorPosition = 0x02EE;
////				}

////				CanPushMotorPosition[4] = sidePushMotorPosition & 0xFF;		   // ��8λ;
////				CanPushMotorPosition[5] = (sidePushMotorPosition >> 8) & 0xFF; // ��8λ;

////				Can_Send_Msg(sideCanPushMotorID, RevokeMotorPosition); // ȡ����λ
//				
////				//  Can_Send_Msg(sideCanPushMotorID,CanPushMotorPosition);
////				Multiple_Can_Send_Msg(sideCanPushMotorID, CanPushMotorPosition);
////				Send_Cleaning_Controller_Data.sidebrush_data = Mode; // ��ˢ����

//				//						sidePushMotorPosition[3] = (uint16_t)(sidePushMotorMinPosition + level*sidePushMotorPositionStep);
//				//					if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(sidePushMotorID,absolutePositionRegAddr,0x04,sidePushMotorPosition)){
//				//					  Send_Cleaning_Controller_Data.sidebrush_data = Mode;
//				//					}
//				Clean_Device_Mode.sidepushmode = Mode;
//				siderpushCan[1] = Mode;
//				siderpushCan[2] = level;
//				Can_Send_Msg(pduCanID,siderpushCan);
////				Send_Cleaning_Controller_Data.sidebrush_data = Mode;
//			}
//			else
//			{
////				sidePushMotorPosition = 0;
////				Multiple_Can_Send_Msg(sideCanPushMotorID, PushMotorSQ2); // SQ2��λ
////				Send_Cleaning_Controller_Data.sidebrush_data = Mode;	 // ��ˢ����
//				siderpushCan[1] = Mode;
//				siderpushCan[2] = level;
//				Can_Send_Msg(pduCanID,siderpushCan);

//				//						sidePushMotorPosition[3] = 0;
//				//					if(MODBUS_OK == ModbusRTU_WriteSingleRegister(sidePushMotorID,resetPositionRegAddr,0x03)) //SQ2��λ
//				//					{
//				//					  Send_Cleaning_Controller_Data.sidebrush_data = Mode;//��ˢ����
//				//					}
//			}

        Clean_Device_Mode.sidepushmode = Mode;
				siderpushCan[1] = Mode;
				siderpushCan[2] = level;
				Can_Send_Msg(pduCanID,siderpushCan);
			
			break;
		}
		case 22: // �����ˢ����
		{

				Clean_Device_Mode.mainpushmode = Mode;
				mainpushCan[1] = Mode;
				mainpushCan[2] = level;
				Can_Send_Msg(pduCanID,mainpushCan);
			 
//			if (level > 0 && level <= 10)
//			{
////				mainPushMotorPosition = mainPushMotorMaxPosition - (uint16_t)(mainPushMotorMinPosition + level * mainPushMotorPositionStep);
////				if (mainPushMotorPosition == 0x0000)
////				{
////					mainPushMotorPosition = 0x0249;
////				}
////				else if (mainPushMotorPosition == 0x0249)
////				{
////					mainPushMotorPosition = 0x0000;
////				}
////				CanPushMotorPosition[4] = mainPushMotorPosition & 0xFF;		   // ��8λ;
////				CanPushMotorPosition[5] = (mainPushMotorPosition >> 8) & 0xFF; // ��8λ;

////				Can_Send_Msg(mainCanPushMotorID, RevokeMotorPosition); // ȡ����λ
////				//			 delay_ms(30);
////				//		 Can_Send_Msg(mainCanPushMotorID,CanPushMotorPosition);//��ˢ����
////				Multiple_Can_Send_Msg(mainCanPushMotorID, CanPushMotorPosition);

////				Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode;
//				Clean_Device_Mode.mainpushmode = Mode;
//				mainpushCan[1] = Mode;
//				mainpushCan[2] = level;
//				Can_Send_Msg(pduCanID,mainpushCan);

//				//					mainPushMotorPosition[3] = (uint16_t)(mainPushMotorMinPosition + level*mainPushMotorPositionStep);
//				//					if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(sidePushMotorID,absolutePositionRegAddr,0x04,mainPushMotorPosition)){
//				//						 Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode;//��ˢ����
//				//					}
//			}
//			else
//			{
////				mainPushMotorPosition = 0;
////				// ��ˢSQ1��λ
////				Multiple_Can_Send_Msg(mainCanPushMotorID, PushMotorSQ1);	 // SQ1��λ
////				Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode; // ��ˢ����
//				mainpushCan[1] = Mode;
//				mainpushCan[2] = level;
//				Can_Send_Msg(pduCanID,mainpushCan);

//				//					mainPushMotorPosition[3] = 0;
//				//				 if(MODBUS_OK == ModbusRTU_WriteSingleRegister(mainPushMotorID,resetPositionRegAddr,0x02)) //SQ1��λ
//				//					{
//				//					  Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode;//��ˢ����
//				//					}
//			}

			break;
		}
		case 8: // ��������
		{
			if (Mode == 0)
			{
				leftBurshMotorSpeed[0] = 0;
				leftBurshMotorSpeed[1] = 0;
				Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
				Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
				Clean_Device_Mode.leftbrushmode = 0;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(leftBurshMotorID, 0x00, 0x02, leftBurshMotorSpeed))
				{
					//  Send_Cleaning_Controller_Data.left_sidebrush_data = 0;
//					Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
//					Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
				}
//				Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
//				Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
        rightBurshMotorSpeed[0] = 0;
				rightBurshMotorSpeed[1] = 0;
				Do_rightBurshMotorSpeed = 0;
			
				Clean_Device_Mode.rightbrushmode = 0;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID, 0x00, 0x02, rightBurshMotorSpeed))
				{
					//					  Send_Cleaning_Controller_Data.left_sidebrush_data = 0;
				//	Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];
				}
//				Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];

				mainMotorSpeed[1] = 0;
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				Clean_Device_Mode.mainbrushmode = 0;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(mainPushMotorID, 0x00, 0x02, mainMotorSpeed))
				{
					//					   Send_Cleaning_Controller_Data.mainbrush_data = 0;
				//	Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				}
		//		Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];

				fanMotorSpeed[1] = 0;
				Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				Clean_Device_Mode.fanmode = 0;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(fanMotorID, 0x00, 0x02, fanMotorSpeed))
				{
					//					   Send_Cleaning_Controller_Data.vacuumfan_data = 0;//���
				//	Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				}
//          Do_fanMotorSpeed[1] = fanMotorSpeed[1];
//				CanPushMotorPosition[4] = 0; // ��8λ;
//				CanPushMotorPosition[5] = 0; // ��8λ;

//				Can_Send_Msg(sideCanPushMotorID, PushMotorSQ2);	  // SQ2��λ
//				Send_Cleaning_Controller_Data.sidebrush_data = 8; // ��ˢ����

//				Can_Send_Msg(mainCanPushMotorID, PushMotorSQ1);			  // SQ1��λ
//				Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = 8; // ��ˢ����
				Clean_Device_Mode.sidepushmode = Mode;
				siderpushCan[1] = Mode;
				siderpushCan[2] = level;
				Can_Send_Msg(pduCanID,siderpushCan);
		
				
				Clean_Device_Mode.mainpushmode = Mode;
				mainpushCan[1] = Mode;
				mainpushCan[2] = level;
				Can_Send_Msg(pduCanID,mainpushCan);
				
       
				//					sidePushMotorPosition[3] = 0;
				//					if(MODBUS_OK == ModbusRTU_WriteSingleRegister(sidePushMotorID,resetPositionRegAddr,0x03)) //SQ2��λ
				//					{
				//					  Send_Cleaning_Controller_Data.sidebrush_data = 8;//��ˢ����
				//					}
				//
				//					mainPushMotorPosition[3] = 0;
				//				 if(MODBUS_OK == ModbusRTU_WriteSingleRegister(mainPushMotorID,resetPositionRegAddr,0x02)) //SQ1��λ
				//					{
				//					  Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = 8;//��ˢ����
				//					}
			}
			else if (Mode == 1)
			{
//				int32_t leftBurshspeed = -(uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
//				leftBurshMotorSpeed[0] = (uint16_t)(leftBurshspeed >> 16);	  // �� 16 λ
//				leftBurshMotorSpeed[1] = (uint16_t)(leftBurshspeed & 0xFFFF); // �� 16 λ
//				Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
				leftBurshMotorSpeed[1] = (uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
				Clean_Device_Mode.leftbrushmode = 1;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(leftBurshMotorID, 0x00, 0x02, leftBurshMotorSpeed))
				{
					//					  Send_Cleaning_Controller_Data.left_sidebrush_data = 1;
//					Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
//					Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];
				}
//					Do_leftBurshMotorSpeed[0] = leftBurshMotorSpeed[0];
					Do_leftBurshMotorSpeed[1] = leftBurshMotorSpeed[1];

//				rightBurshMotorSpeed[1] = (uint16_t)(sidebrushMinSpeed + 5 * sidebrushSpeedStep);
				int32_t rightBurshspeed = -(uint16_t)(sidebrushMinSpeed + level * sidebrushSpeedStep);
				rightBurshMotorSpeed[0] = (uint16_t)(rightBurshspeed >> 16);  // �� 16 λ
				rightBurshMotorSpeed[1] = (uint16_t)(rightBurshspeed & 0xFFFF);
				Do_rightBurshMotorSpeed = rightBurshspeed;
			
				Clean_Device_Mode.rightbrushmode = 1;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID, 0x00, 0x02, rightBurshMotorSpeed))
				{
				//  Send_Cleaning_Controller_Data.left_sidebrush_data = 1;
				//	Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];
				}
//				Do_rightBurshMotorSpeed[1] = rightBurshMotorSpeed[1];

				mainMotorSpeed[1] = (uint16_t)(mainbrushMinSpeed + 5 * mainbrushSpeedStep);
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				Clean_Device_Mode.mainbrushmode = 1;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(mainPushMotorID, 0x00, 0x02, mainMotorSpeed))
				{
				//	Send_Cleaning_Controller_Data.mainbrush_data = 1;
				//	Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];
				}
				Do_mainBurshMotorSpeed[1] = mainMotorSpeed[1];

				fanMotorSpeed[1] = (uint16_t)(vacuumfanMinSpeed + level * vacuumfanSpeedStep);
				Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				Clean_Device_Mode.fanmode = 1;
				if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(fanMotorID, 0x00, 0x02, fanMotorSpeed))
				{
				//	Send_Cleaning_Controller_Data.vacuumfan_data = Mode;//���
				//	Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				}
          Do_fanMotorSpeed[1] = fanMotorSpeed[1];
				
			  Clean_Device_Mode.sidepushmode = Mode;
				siderpushCan[1] = Mode;
				siderpushCan[2] = level;
				Can_Send_Msg(pduCanID,siderpushCan);
				
				
				Clean_Device_Mode.mainbrushmode = Mode;
				mainpushCan[1] = Mode;
				mainpushCan[2] = level;
				Can_Send_Msg(pduCanID,mainpushCan);

//				sidePushMotorPosition = (uint16_t)(sidePushMotorMinPosition + 10 * sidePushMotorPositionStep);
//				CanPushMotorPosition[4] = sidePushMotorPosition & 0xFF;		   // ��8λ;
//				CanPushMotorPosition[5] = (sidePushMotorPosition >> 8) & 0xFF; // ��8λ;

//				Can_Send_Msg(sideCanPushMotorID, RevokeMotorPosition); // ȡ����λ
//				//	delay_ms(30);
//				Multiple_Can_Send_Msg(sideCanPushMotorID, CanPushMotorPosition);
//				Send_Cleaning_Controller_Data.sidebrush_data = Mode; // ��ˢ����

//				mainPushMotorPosition = mainPushMotorMaxPosition - (uint16_t)(mainPushMotorMinPosition + level * mainPushMotorPositionStep);
//				CanPushMotorPosition[4] = mainPushMotorPosition & 0xFF;		   // ��8λ;
//				CanPushMotorPosition[5] = (mainPushMotorPosition >> 8) & 0xFF; // ��8λ;
//				Can_Send_Msg(mainCanPushMotorID, RevokeMotorPosition);		   // ȡ����λ
//				//		delay_ms(30);
//				Multiple_Can_Send_Msg(mainCanPushMotorID, CanPushMotorPosition);
//				Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Mode; // ��ˢ����

				//					sidePushMotorPosition[3] = (uint16_t)(sidePushMotorMinPosition + 10*sidePushMotorPositionStep);
				//					if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(sidePushMotorID,absolutePositionRegAddr,0x04,sidePushMotorPosition)){
				//					  Send_Cleaning_Controller_Data.sidebrush_data = 0;
				//					}
				//
				//					mainPushMotorPosition[3] = (uint16_t)(mainPushMotorMinPosition + 10*mainPushMotorPositionStep);
				//					if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(sidePushMotorID,absolutePositionRegAddr,0x04,mainPushMotorPosition)){
				//						 Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = 0;
				//				  }
			}
			break;
		}
		}
	}
}

// ���Ͳ�ѯ���������ٶ������鵲λ�Ƿ���ȷ�������ջ�����

void Query_Check_Cleaning_Controller()
{

	static uint16_t Last_leftBurshMotorSpeed = 0;
	static uint16_t Last_mainBurshMotorSpeed = 0;
	static int32_t Last_rightBurshMotorSpeed = 0;
	static uint16_t Last_fanMotorSpeed = 0;

	static uint8_t left_time = 0, right_time = 0, main_time = 0, fan_time = 0;
  
	// ���ˢ
	if (Last_leftBurshMotorSpeed != Do_leftBurshMotorSpeed[1])
	{

		uint16_t Check_leftBurshMotorSpeed[2] = {0, 0};
		if (MODBUS_OK == ModbusRTU_ReadInputRegisters(leftBurshMotorID, 0x1000, 2, Check_leftBurshMotorSpeed))
		{
			if (Check_leftBurshMotorSpeed[1] <= (Do_leftBurshMotorSpeed[1] + 500) && Check_leftBurshMotorSpeed[1] >= ((int16_t)Do_leftBurshMotorSpeed[1] - 500))
			{
				Send_Cleaning_Controller_Data.left_sidebrush_data = Clean_Device_Mode.leftbrushmode;
				Last_leftBurshMotorSpeed = Do_leftBurshMotorSpeed[1];
				
				left_time = 0;
			}
			else
			{
//				if (left_time < 5)
				{
					if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(leftBurshMotorID, 0x00, 0x02, Do_leftBurshMotorSpeed))
					{
					}
//					left_time++;
				}
			}
		}
	}
	// �ұ�ˢ
	if (Last_rightBurshMotorSpeed != Do_rightBurshMotorSpeed)
	{

		uint16_t Check_rightBurshMotorSpeed[2] = {0, 0};
		if (MODBUS_OK == ModbusRTU_ReadInputRegisters(rightBurshMotorID, 0x1000, 2, Check_rightBurshMotorSpeed))
		{
			int32_t full_speed_value = (Check_rightBurshMotorSpeed[0] << 16) | Check_rightBurshMotorSpeed[1];
			if (full_speed_value <= (Do_rightBurshMotorSpeed + 500) && full_speed_value >= (Do_rightBurshMotorSpeed - 500))
			{
				Send_Cleaning_Controller_Data.right_sidebrush_data = Clean_Device_Mode.rightbrushmode;
				Last_rightBurshMotorSpeed = Do_rightBurshMotorSpeed;
				right_time = 0;
			}
			else
			{
//				if (right_time < 5)
//				{
				rightBurshMotorSpeed[0] = (uint16_t)(Do_rightBurshMotorSpeed >> 16);  // �� 16 λ
				rightBurshMotorSpeed[1] = (uint16_t)(Do_rightBurshMotorSpeed & 0xFFFF);
					if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(rightBurshMotorID, 0x00, 0x02, rightBurshMotorSpeed))
					{
					}
//					right_time++;
//				}
			}
		}
	}

	// ��ˢ
	if (Last_mainBurshMotorSpeed != Do_mainBurshMotorSpeed[1])
	{
		uint16_t Check_mainBurshMotorSpeed[2] = {0, 0};
		if (MODBUS_OK == ModbusRTU_ReadInputRegisters(mainBurshMotorID, 0x1000, 2, Check_mainBurshMotorSpeed))
		{
			if (Check_mainBurshMotorSpeed[1] <= (Do_mainBurshMotorSpeed[1] + 500) && Check_mainBurshMotorSpeed[1] >= ((int16_t)Do_mainBurshMotorSpeed[1] - 500))
			{
				Send_Cleaning_Controller_Data.mainbrush_data = Clean_Device_Mode.mainbrushmode;
				Last_mainBurshMotorSpeed = Do_mainBurshMotorSpeed[1];
				main_time = 0;
			}
			else
			{
//				if (main_time < 5)
//				{
					if (MODBUS_OK == ModbusRTU_WriteMultipleRegisters(mainBurshMotorID, 0x00, 0x02, Do_mainBurshMotorSpeed))
					{
					}
//					main_time++;
//				}
			}
		}
	}
	// ���
		if(Last_fanMotorSpeed != Do_fanMotorSpeed[1]){
			uint16_t Check_fanMotorSpeed[2] = {0,0}; 
		 if(MODBUS_OK ==ModbusRTU_ReadInputRegisters(fanMotorID,0x1000,2,Check_fanMotorSpeed)){
		      if(Check_fanMotorSpeed[1] <= (Do_fanMotorSpeed[1] +1000) && Check_fanMotorSpeed[1] >= ((int16_t)Do_fanMotorSpeed[1] - 1000)){
				    Send_Cleaning_Controller_Data.vacuumfan_data = Clean_Device_Mode.fanmode;
					  Last_fanMotorSpeed = Do_fanMotorSpeed[1];
						fan_time = 0;
				 }
		     else{
//					if(fan_time < 5){
				  if(MODBUS_OK == ModbusRTU_WriteMultipleRegisters(fanMotorID,0x00,0x02,Do_fanMotorSpeed)){
	
				  }
//					fan_time ++;
//			   }
		    }
	
		 }
	}
		
	//����	  
  	if(Clean_Device_Mode.sidepushmode == received_sidepushMode){
	        Send_Cleaning_Controller_Data.sidebrush_data = Clean_Device_Mode.sidepushmode;
			//    motor_info.sidepush_err_code = 0; 
			    sidepushtime = 0;
	      }
		else 
		    { 
        if (sidepushtime == 0) {

             sidepushtime = HAL_GetTick();
            } else {
        
        if ((int32_t)(HAL_GetTick() - sidepushtime) >= 5000) {  
    //       motor_info.sidepush_err_code = 1; 
            sidepushtime = 0;
            
         } 
		   	}
		   }
	//����
	  if(Clean_Device_Mode.mainpushmode == received_mainpushMode){
	        Send_Cleaning_Controller_Data.mainbrush_up_dowm_data = Clean_Device_Mode.mainpushmode;
	//		motor_info.mainpush_err_code = 0;
			    mainpushtime = 0;
	     }
		else
			{
				if(mainpushtime == 0){
				 mainpushtime = HAL_GetTick();
				}else{
				    if((int32_t)(HAL_GetTick() - mainpushtime) >= 5000){
				//		 motor_info.mainpush_err_code = 1;
						 mainpushtime = 0;
						}
				}				
		  }
}
