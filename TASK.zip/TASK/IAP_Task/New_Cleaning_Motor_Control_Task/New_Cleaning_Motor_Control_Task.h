#ifndef _NEW_CLEANING_MOTOR_CONTROL_TASK_H
#define _NEW_CLEANING_MOTOR_CONTROL_TASK_H
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include <stdlib.h> // ����rand()��srand()
#include <time.h>   // ����time()
#include "cmsis_os.h"
#include "can.h"
#include "Can_Task.h"
#include <stdio.h>
#include <string.h>
#include "Can_Task.h"
#include "Ultrasonic_Task.h"
#include "Light_Control_Task.h"
#include "Control_Data_Process_Task.h"
#include "modbus_rtu_master.h"
#include "Can_Task.h"

#define mainBurshMotorID  0x10   //��ˢID


#define leftBurshMotorID  0x21   //���ˢID
#define rightBurshMotorID 0x22   //�ұ�ˢID

#define mainPushMotorID   0x31   //��ˢ�Ƹ�ID
#define sidePushMotorID   0x32   //��ˢ�Ƹ�ID

#define fanMotorID        0x40   //���ID

#define mainCanPushMotorID   0x631   //can��ˢ�Ƹ�ID
#define sideCanPushMotorID   0x632   //can��ˢ�Ƹ�ID

#define absolutePositionRegAddr 0x0046  //����λ��ģʽ�Ĵ���
#define resetPositionRegAddr    0x00cf  //��λ���ԼĴ���

#define pduCanID 0XCC 

#define mainbrushMinSpeed 1600
#define sidebrushMinSpeed 1600
#define vacuumfanMinSpeed 10000
#define sidePushMotorMinPosition 100
#define mainPushMotorMinPosition 100


#define mainbrushMaxSpeed 4000
#define sidebrushMaxSpeed 4000
#define vacuumfanMaxSpeed 20000
#define sidePushMotorMaxPosition 750
#define mainPushMotorMaxPosition 750


#define mainbrushSpeedStep        (mainbrushMaxSpeed - mainbrushMinSpeed)/10.0
#define sidebrushSpeedStep        (sidebrushMaxSpeed - sidebrushMinSpeed)/10.0
#define vacuumfanSpeedStep        (vacuumfanMaxSpeed - vacuumfanMinSpeed)/10.0
#define sidePushMotorPositionStep (sidePushMotorMaxPosition - sidePushMotorMinPosition)/10.0
#define mainPushMotorPositionStep (mainPushMotorMaxPosition - mainPushMotorMinPosition)/10.0
typedef struct
{
	uint8_t motor;
	uint8_t Mode;
	uint8_t level;
}Clean_Device_Controller_;

typedef struct
{
  uint8_t mainbrushflag;
	uint8_t rightbrushflag;
	uint8_t leftbrushflag;
	uint8_t fanflag;
}Clean_Device_flag_;

typedef struct
{
  uint8_t mainbrushmode;
	uint8_t rightbrushmode;
	uint8_t leftbrushmode;
	uint8_t fanmode;
	uint8_t sidepushmode;
	uint8_t mainpushmode;
}Clean_Device_Mode_;


void New_Cleaning_Motor_Control_Task(void const * argument);

void Receive_Dn_Cleaning_Controller(uint8_t clean_motor,uint8_t Mode,uint8_t level);

void Query_Check_Cleaning_Controller(void);

#endif








