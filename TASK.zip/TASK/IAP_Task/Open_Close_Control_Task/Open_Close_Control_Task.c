#include "Open_Close_Control_Task.h"

PowerState_t powerState = POWER_STATE_ON;
static uint32_t keyPressCounter = 0;
uint8_t Power_flag = 0;
uint8_t press_action_done = 0; // 0 代表 false (动作未完成), 1 代表 true
uint8_t wait_time = 0;
void Open_Close_Control_Task(void const *argument)
{
	User_BKP_Init();
	delay_ms(1000);
	printf("Read_PowerCloseFlag :%d \r\n",Read_PowerCloseFlag());
  if(Close_PAD == Read_PowerCloseFlag()) //检测到PAD关机，将PAD开机
	{
	 HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET);
	 delay_ms(5000);
	 HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_SET);
	 Write_PowerCloseFlag(0);
	}
	// HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_SET); //平板电源
	// HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_SET); //工控机
     
	uint8_t time = 0;
	Power_flag = 0;
	osEvent event;
	press_action_done = 0;
	while (1)
	{

		Power_Control();
		if (time >= 5)
		{
			HAL_GPIO_TogglePin(LED_SYS_RUN_GPIO_Port, LED_SYS_RUN_Pin);

			time = 0;
		}
		time++;
		event = osSignalWait(Power_Close_Flag, 0);
		// 检查返回事件的状态
		if (event.status == osEventSignal)
		{
			// 如果状态是 osEventSignal，说明我们确实收到了信号

			// 进一步确认是否是我们关心的 Power_Close_Flag 信号
			if (event.value.signals & Power_Close_Flag)
			{
				Power_flag = 1;
				Power_Close_Control();
			}
		}
		// Power_off_dog();
		delay_ms(100);
	}
}
static __INLINE void NVIC_CoreReset1(void)
{
	__DSB();
	// 置位VECTRESET
	SCB->AIRCR = ((0x5FA << SCB_AIRCR_VECTKEY_Pos) |
				  (SCB->AIRCR & SCB_AIRCR_PRIGROUP_Msk) |
				  SCB_AIRCR_VECTRESET_Msk);
	__DSB();
	while (1)
		;
}

void Sys_Soft_Reset1(void) // 系统复位
{
	printf(" >> boot reset <<\r\n ");
	__disable_fault_irq();
	__set_FAULTMASK(1);
	//	NVIC_SystemReset();
	NVIC_CoreReset1();
}

void Power_Control(void)
{
	if (HAL_GPIO_ReadPin(IN_STR_GPIO_Port, IN_STR_Pin) == GPIO_PIN_SET)
	{

		keyPressCounter++;
	//	printf("IN_STR_Pin 1 \r\n");
	}
	else
	{
		keyPressCounter = 0;
		press_action_done = 0; // 重置标志位！
	//	HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET);
	}

		
	if (keyPressCounter >= 100)
	{
		HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);			 // 清洁电机控制器 关闭pdu和风机
		HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET); // 关闭工控机电源
		//			HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_RESET);  //平板断电
		powerState = POWER_STATE_OFF;
		Power_flag = 0;
		delay_ms(8000);
		HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET); //延迟8+2秒，确保PAD能真正关机

	}
	else if (keyPressCounter >= 25 && keyPressCounter < 100)
	{

		if (keyPressCounter >= 80)
		{
			HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_RESET);
		}
		if (press_action_done == 0)
		{
			if (powerState == POWER_STATE_OFF)
			{
				//					HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET);
				//					HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//清洁电机控制器 pdu和风机
				//				  HAL_GPIO_WritePin(CAN_EN_GPIO_Port,CAN_EN_Pin,GPIO_PIN_SET); //开启工控机电源
				//					Power_Open_Control();
				//					delay_ms(3000);
				//					osSignalSet(Motor_Task_Handle,EVENTBIT_1);
				//					HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_RESET); //平板断电
				//					HAL_IWDG_Refresh(&hiwdg);   //看门狗喂狗
				//	       printf("Power_flag:%d",Power_flag);
				Write_PowerCloseFlag(Close_PAD);    
				Sys_Soft_Reset1();
			}
			else
			{
				Power_flag = 1;
				wait_time = 0;
				//				printf("Power_flag:%d",Power_flag);
			}
			press_action_done = 1;
		}
	}

	if (Power_flag == 1)
	{
		wait_time++;
		if(powerState == POWER_STATE_ON)
		{
		if (wait_time >= 170)
		{
			HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_RESET);
		}
		if (wait_time >= 200)
		{
			HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET); // 关闭工控机电源
			HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);			 // 清洁电机控制器 关闭pdu和风机
			delay_ms(7000);
			HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET); //延迟7+3秒，确保PAD能真正关机
			wait_time = 0;
			Power_flag = 0;
			powerState = POWER_STATE_OFF;
		}
	  }
	}

	//        if(powerState == POWER_STATE_ON){
	//				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//清洁电机控制器 pdu和风机
	//				HAL_GPIO_WritePin(CAN_EN_GPIO_Port,CAN_EN_Pin,GPIO_PIN_SET); //开启工控机电源
	//				HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_SET); //平板电源
	//				}
}
void Power_Close_Control()
{
	if (Power_flag == 1)
	{
		Power_flag = 0;
		wait_time = 0;
		delay_ms(5000);													 // 等待工控机自己安全关机再断电
		HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET); // 关闭工控机电源
		HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);			 // 清洁电机控制器 关闭pdu和风机
		//			HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_RESET); //平板断电
		//			  HAL_IWDG_Refresh(&hiwdg);
		//		  osThreadSuspend(Data_Task_Handle);
		//      osThreadSuspend(Motor_Task_Handle);
		//      osThreadSuspend(Can_Task_Handle);
		//      osThreadSuspend(Peripheral_Control_Task_Handle);
		//      osThreadSuspend(Light_Control_Task_Handle);
		//      osThreadSuspend(IAP_Task_Handle);
		//      osThreadSuspend(Alarm_Event_Manager_Task_Handle);
		//      osThreadSuspend(Control_Data_Process_Task_Handle);

		powerState = POWER_STATE_OFF;
	}
}

void Power_off_dog(void)
{
	if (powerState == POWER_STATE_OFF)
	{
		HAL_IWDG_Refresh(&hiwdg);
	}
}

// void Power_Open_Control(void){

//  osThreadResume(Data_Task_Handle);
//  osThreadResume(Motor_Task_Handle);
//  osThreadResume(Can_Task_Handle);
//  osThreadResume(Peripheral_Control_Task_Handle);
//  osThreadResume(Light_Control_Task_Handle);
//  osThreadResume(IAP_Task_Handle);
//  osThreadResume(Alarm_Event_Manager_Task_Handle);
//  osThreadResume(Control_Data_Process_Task_Handle);

//}
