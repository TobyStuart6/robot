#ifndef __OPEN_CLOSE_CONTROL_TASK_H
#define __OPEN_CLOSE_CONTROL_TASK_H
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include <stdio.h>
#include <string.h>
#include "stdlib.h"
#include <stdbool.h>
#include "Peripheral_Control_Task.h"
#include "userbkp.h"
#define Power_Close_Flag  (1<<11)

#define POWER_ON_TIME   250   // 3 秒 (10ms * 300)
#define POWER_OFF_TIME  300   // 3 秒
#define FORCE_OFF_TIME  1000  // 10 秒
#define Close_PAD  1 
extern uint8_t Power_flag ;
typedef enum {
    POWER_STATE_OFF,
    POWER_STATE_ON
} PowerState_t;
extern PowerState_t powerState;
void Open_Close_Control_Task(void const * argument);
void Power_Close_Control(void);
void Power_Open_Control(void);
void Power_Key_Control(void);
void Power_Control(void);
void Power_off_dog(void);
#endif
