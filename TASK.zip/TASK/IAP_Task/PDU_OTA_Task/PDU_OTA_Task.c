#include "PDU_OTA_Task.h"
#include "iwdg.h"
#include "CAN_Task.h"
#include "Open_Close_Control_Task.h"
uint16_t zero = 0x0000;                                                                // 用于清除升级标志
uint16_t PDU_Updata_flag = 0;                                                          // 用于标记是否需要升级，1表示需要升级，0表示不升级
uint8_t CAN_OTA_Command_Flag = 2;                                                      // 用于标记CAN发送OTA命令的状态，0表示发送成功，1表示发送失败，初始化为2
const uint8_t OTA_Commad_By_CAN[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}; // 通过CAN发送的OTA命令  PDU_OTA_ID为0xCC

extern osThreadId New_Cleaning_Motor_Control_Task_Handle; // 新清扫电机控制任务句柄
extern osThreadId Open_Close_Control_Task_Handle;         // 开闭控制任务句柄
extern UART_HandleTypeDef huart3;                         // Modbus通信串口
extern IWDG_HandleTypeDef hiwdg;                          // 独立看门狗句柄

static GPIO_PinState ota_rs485_prev_state = GPIO_PIN_RESET;
static uint8_t ota_rs485_state_saved = 0U;

void OTA_Prepare(void); // 函数原型声明
void OTA_Finish(void);  // 函数原型声明

PDU_OTA_State_t PDU_OTA_Result; // 用于存储OTA结果状态

static __INLINE void NVIC_CoreReset2(void)
{
  __DSB();
  // 置位VECTRESET
  SCB->AIRCR = ((0x5FA << SCB_AIRCR_VECTKEY_Pos) |
                (SCB->AIRCR & SCB_AIRCR_PRIGROUP_Msk) |
                SCB_AIRCR_VECTRESET_Msk);
  __DSB();
  while (1)
    ;
}

void Sys_Soft_Reset2(void) // 系统复位
{
  printf(" >> boot reset <<\r\n ");
  __disable_fault_irq();
  __set_FAULTMASK(1);
  //	NVIC_SystemReset();
  NVIC_CoreReset2();
}

void PDU_OTA_Task(void const *argument)
{
  while (1)
  {
    osSignalWait(Start_PDU_Ota_Flag, osWaitForever);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET); // 打开PDU供电
    // 准备OTA升级，将其他任务挂起，防止干扰升级过程
    Other_Task_Suspend(); // 挂起其他任务
    OTA_Prepare();        // 做OTA前的外围隔离
    delay_ms(100);        // 等待让其他任务完全挂起
    PDU_OTA_Result = PDU_OTA();
    if (PDU_OTA_Result == PDU_OTA_SUCCESS)
    {
      PDU_OTA_OK();
      printf("PDU OTA SUCCESS......\r\n");
      // OTA完成，系统复位
      Power_OFF();
      Sys_Soft_Reset2();
    }
    else if (PDU_OTA_Result == NO_PDU_OTA)
    {
      HAL_IWDG_Refresh(&hiwdg);
      printf("No PDU OTA needed, resuming normal operation...\r\n");
      
      // 清除升级标志，防止重复判断
      uint16_t clear_flag = 0;
      STMFLASH_Write(IAP_Flag2, &clear_flag, 1);
      osDelay(50);
      
      Other_Task_Resume(); // 恢复其他任务
      OTA_Finish();        // 做OTA后的外围恢复
      osDelay(100);
    }
    else
    {
      PDU_OTA_Failed();
      printf("PDU OTA FAILED......\r\n");
      
      // 延时确保Flash写入完成
      osDelay(200);
      
      // 再次验证标志是否已清除
      uint16_t verify_flag = 0xFFFF;
      STMFLASH_Read(IAP_Flag2, &verify_flag, 1);
      printf("Before reset, IAP_Flag2=0x%04X\r\n", verify_flag);
      
      // Other_Task_Resume(); 
      OTA_Finish();        // 做OTA后的外围恢复
      
      // OTA失败，系统复位
      Power_OFF();
      osDelay(100); // 等待关机完成
      Sys_Soft_Reset2();
    }
  }
}

/**
 * @brief  执行OTA的流程
 * @return 无返回值
 */
PDU_OTA_State_t PDU_OTA(void)
{
  STMFLASH_Write(IAP_Flag, &zero, 1);  // 避免重复升级，先清除IPC升级标志
  STMFLASH_Write(IAP_Flag2, &zero, 1); // 避免重复升级，先清除PDU升级标志

  // 先清除PDU OTA状态标志，避免旧状态影响判断
  uint16_t clear_ota_state = 0xFFFF;
  STMFLASH_Write(PDU_OTA_State, &clear_ota_state, 1);

  PDU_Updata_flag = 0; // 重置升级标志
  // 通过CAN通信发送指令，关闭相关的干扰功能，让PDU进入bootloader模式
  CAN_OTA_Command_Flag = Multiple_Can_Send_Msg_OTA(PDU_OTA_ID, (uint8_t *)OTA_Commad_By_CAN); // 通过CAN发送OTA命令
  printf("OTA_command by CAN=%02X %02X %02X %02X %02X %02X %02X %02X \r\n",
         OTA_Commad_By_CAN[0], OTA_Commad_By_CAN[1], OTA_Commad_By_CAN[2], OTA_Commad_By_CAN[3],
         OTA_Commad_By_CAN[4], OTA_Commad_By_CAN[5], OTA_Commad_By_CAN[6], OTA_Commad_By_CAN[7]);

  delay_ms(1);
  HAL_IWDG_Refresh(&hiwdg); // 刷新看门狗

  if (CAN_OTA_Command_Flag == 1) // 发送失败
  {
    CAN_OTA_Command_Flag = 2;
    printf("PDU OTA: CAN command send failed,IPC Normal Start...\r\n");
    return PDU_Connect_FAILED; // 直接返回
  }
  else // 发送成功
  {
    // CAN发送接口内部已经保证重试到成功，因此此处直接进入后续流程
    printf("PDU OTA: CAN command send ok...\r\n");
    ModbusRTU_Deinit(&huart3); // 反初始化Modbus，释放资源
    delay_ms(500);             // 等待500毫秒让PDU进入bootloader模式

    // 检查PDU bootloader连接状态
    if (PDU_CheckBootloaderConnection() == PDU_Connect_SUCCESS)
    {
      // 开始从Flash读取并发送PDU APP数据（自动检测APP大小）
      printf("PDU OTA: APP Send Start...\r\n");
      HAL_IWDG_Refresh(&hiwdg);
      PDU_OTA_State_t ota_result = PDU_SendAppFromFlash(PDU_APP_START_ADDR);
      HAL_IWDG_Refresh(&hiwdg);
      if (ota_result == PDU_OTA_SUCCESS)
      {
        CAN_OTA_Command_Flag = 2;
        printf("PDU OTA: OTA OK\r\n");
        return PDU_OTA_SUCCESS; // OTA成功后返回，继续正常启动流程
      }
      else if (ota_result == NO_PDU_OTA)
      {
        CAN_OTA_Command_Flag = 2;
        printf("PDU OTA: No OTA needed\r\n");
        return NO_PDU_OTA; // 未进行OTA
      }
      else
      {
        CAN_OTA_Command_Flag = 2;
        printf("PDU OTA: OTA Failed\r\n");
        return PDU_OTA_ERROR; // OTA失败
      }
    }
    else
    {
      CAN_OTA_Command_Flag = 2;
      printf("PDU OTA: bootloader connect failed\r\n");
      return PDU_Connect_FAILED; // 连接失败，返回
    }
  }
}

// 非OTA任务挂起
void Other_Task_Suspend(void)
{
  HAL_IWDG_Refresh(&hiwdg);
  osThreadSuspend(New_Cleaning_Motor_Control_Task_Handle);
  // printf("1\r\n");
  osThreadSuspend(Data_Task_Handle);
  // printf("2\r\n");
  osThreadSuspend(Motor_Task_Handle);
  // printf("3\r\n");
  osThreadSuspend(Can_Task_Handle);
  // printf("4\r\n");
  osThreadSuspend(Peripheral_Control_Task_Handle);
  // printf("5\r\n");
  osThreadSuspend(Light_Control_Task_Handle);
  // printf("6\r\n");
  osThreadSuspend(IAP_Task_Handle);
  // printf("7\r\n");
  osThreadSuspend(Alarm_Event_Manager_Task_Handle);
  // printf("8\r\n");
  osThreadSuspend(Control_Data_Process_Task_Handle);
  // printf("9\r\n");
  osThreadSuspend(Ultrasonic_Task_Handle);
  // printf("10\r\n");
  osThreadSuspend(Open_Close_Control_Task_Handle);
  // printf("11\r\n");
  HAL_IWDG_Refresh(&hiwdg);
  printf("PDU OTA: Other Task Suspended\r\n");
}

void OTA_Prepare()
{
  HAL_IWDG_Refresh(&hiwdg);

  ota_rs485_prev_state = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_12);
  ota_rs485_state_saved = 1U;

  uint32_t primask = __get_PRIMASK();
  __disable_irq();

  HAL_UART_Abort(&huart3);
  __HAL_UART_CLEAR_FLAG(&huart3, UART_FLAG_TC);
  __HAL_UART_CLEAR_FLAG(&huart3, UART_FLAG_RXNE);
  __HAL_UART_CLEAR_FLAG(&huart3, UART_FLAG_IDLE);
  __HAL_UART_CLEAR_FLAG(&huart3, UART_FLAG_ORE);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);

  __set_PRIMASK(primask);

  HAL_IWDG_Refresh(&hiwdg);
}

void OTA_Finish()
{
  HAL_IWDG_Refresh(&hiwdg);

  uint32_t primask = __get_PRIMASK();
  __disable_irq(); // 关闭中断

  HAL_UART_Abort(&huart3);

  if (ota_rs485_state_saved)
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, ota_rs485_prev_state);
    ota_rs485_state_saved = 0U;
  }
  else
  {
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, GPIO_PIN_RESET);
  }

  __set_PRIMASK(primask); // 恢复中断状态

  HAL_IWDG_Refresh(&hiwdg);
}

// 标记PDU OTA成功
void PDU_OTA_OK()
{
  uint16_t ota_success_flag = 1; // 标记OTA成功
  STMFLASH_Write(PDU_OTA_State, &ota_success_flag, 1);
}

void PDU_OTA_Failed()
{
  uint16_t ota_failed_flag = 0; // 标记OTA失败
  STMFLASH_Write(PDU_OTA_State, &ota_failed_flag, 1);
}

// 非OTA任务恢复
void Other_Task_Resume(void)
{
  HAL_IWDG_Refresh(&hiwdg);
  osThreadResume(New_Cleaning_Motor_Control_Task_Handle);
  // printf("1\r\n");
  osThreadResume(Data_Task_Handle);
  // printf("2\r\n");
  osThreadResume(Motor_Task_Handle);
  // printf("3\r\n");
  osThreadResume(Can_Task_Handle);
  // printf("4\r\n");
  osThreadResume(Peripheral_Control_Task_Handle);
  // printf("5\r\n");
  osThreadResume(Light_Control_Task_Handle);
  // printf("6\r\n");
  osThreadResume(IAP_Task_Handle);
  // printf("7\r\n");
  osThreadResume(Alarm_Event_Manager_Task_Handle);
  // printf("8\r\n");
  osThreadResume(Control_Data_Process_Task_Handle);
  // printf("9\r\n");
  osThreadResume(Ultrasonic_Task_Handle);
  // printf("10\r\n");
  osThreadResume(Open_Close_Control_Task_Handle);
  // printf("11\r\n");
  HAL_IWDG_Refresh(&hiwdg);
  printf("PDU OTA: Other Task Resumed\r\n");
}

// 关闭工控机电源
void Power_OFF(void)
{
   HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_RESET);
   HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET); // 关闭工控机电源
	 HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);			 // 清洁电机控制器 关闭pdu和风机
	 uint8_t time = 0;
	 while(1){
		 HAL_IWDG_Refresh(&hiwdg); // 看门狗喂狗
	   time ++;
		 if(time > 16){
		    break;
		 }	 
	   delay_ms(500); 
	 }
	 HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port, IPC_PWR_EN_Pin, GPIO_PIN_SET); //延迟10秒，确保PAD能真正关机
	 Write_PowerCloseFlag(Close_PAD);
}
