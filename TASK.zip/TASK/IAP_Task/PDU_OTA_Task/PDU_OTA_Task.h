#ifndef __PDU_OTA_TASK_H__
#define __PDU_OTA_TASK_H__

#include "main.h"
#include "cmsis_os.h"
#include "iap.h"
#include "delay.h"
#include "usart.h"
#include "stmflash.h"
#include "pdu_iap.h"
#include "modbus_rtu_master.h"
#include "freertos.h"


#define PDU_OTA_ID 0xCC

PDU_OTA_State_t PDU_OTA(void); // PDU OTA主流程函数原型声明

void Other_Task_Suspend(void); // 非OTA任务挂起

void Other_Task_Resume(void); // 非OTA任务恢复

void OTA_Prepare(void);

void OTA_Finish(void);

void PDU_OTA_Task(void const *argument);

void PDU_OTA_OK(void);

void PDU_OTA_Failed(void);


//关闭平板和工控机
void Power_OFF(void);

static __INLINE void NVIC_CoreReset1(void);

#endif /* __PDU_OTA_TASK_H__ */
