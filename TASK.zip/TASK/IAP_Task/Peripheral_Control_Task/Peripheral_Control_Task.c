#include "Peripheral_Control_task.h"

uint32_t Manual_cleaning_cnt = 0;//���Զ���ť
uint8_t close_total_power[8] = {0x2B,0x03,0xE8,0x00,0x00,0x00,0x00,0xdc};//����ʢ�Ƽ�ͨѶ �ر����������Դ
uint8_t restart_total_power[8]  = {0x2f,0x04,0x57,0x00,0x00,0x00,0x00,0x24};	//����ʢ�Ƽ�ͨѶ,��������
int Liquid_level_l = 0,Liquid_level_r = 0;

uint8_t Flag_Charging_Switch = 0;//��翪�ر�־λ 0�ر�  1��
uint8_t flag_charge_sta = 0,flag_charge_sta_old = 0,flag_charge_sta_next = 0;    //0��δ���  1���Զ����  2���ֶ����  3���ֶ�����
uint8_t charge_times = 0;
peri_power_con_ peri_power_con;

//const uint8_t Reduce_Electricity_3A_1 [8]  = {0x23,0x2A,0x24,0x00,0x2c,0x01,0x00,0x00};	//���״̬�¼��ٵ������Ϊ3A
//const uint8_t Reduce_Electricity_3A_2 [8]  = {0x23,0x2A,0x34,0x00,0x2c,0x01,0x00,0x00};	//
uint8_t bat_reboot[8] = {07,00,00,00,00,00,00,00};
uint8_t charge_on[8] = {02,02,00,00,00,00,00,00};
uint8_t charge_off[2] = {01,01};
uint8_t charge_query[2] = {0x30,0x30};
uint8_t low_power_sta = 0;
uint8_t hard_auto_sta = 0;
void Peripheral_Control_Task(void const * argument)
{
	  delay_ms(2000);
	
    HAL_GPIO_WritePin(GPIOB, LAN_EN_Pin, GPIO_PIN_SET); 
 //   HAL_GPIO_WritePin(OUT_RS2_GPIO_Port, OUT_RS2_Pin, GPIO_PIN_SET); 
	  //HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//����������� ��pdu�ͷ��
    uint8_t Peripheral_Queue_Value = 0;

    while(1)
    {
		MY_ERROR.tasks_heart.peripheral = 0;
        xQueueReceive(Peripheral_Queue,&Peripheral_Queue_Value,0);
        peripheral_control.Manual_cleaning = Peripheral_Queue_Value&0x0f;
//			  printf("peripheral_control.Manual_cleaning�� %d",peripheral_control.Manual_cleaning);
        BAT.Charger_Sta =  Peripheral_Queue_Value>>4;
        Automatic_hand_switching();
        charge_management();//���״̬����
        Motor_Current_Ctrl();//��챵����С����
//        if(peripheral_control.restart_ipc_flag == 1){
//            Restart_Ipc_Power();
//            peripheral_control.restart_ipc_flag = 0;
//        }
//        if(peripheral_control.Mo_restart == 1){
//            Restart_Mo_Power();
//            peripheral_control.Mo_restart = 0;
//        }
//        if(peripheral_control.Kds_restart == 1){
//            Restart_Kds_Power();
//            peripheral_control.Kds_restart = 0;
//        }
//        if(peripheral_control.All_Power == 1){
//            Restart_All_Power();
//            peripheral_control.All_Power = 0;
//        }
//        if(peripheral_control.Close_All == 1 && forbid_Shutdown == 0)
//		{
//            Close_ALL_Power();
//            Can_Send_Msg_Cnt(zhongshengID,close_total_power,8);//�ر�Կ�׿��ص�Դ
//        }
		Peripheral_power_control();
//        spray_Liquid_level_calibration();//����ˮλУ׼��ˮ�ÿ�����Լ14������䣩
		charge_state();
        delay_ms(100);
    }
}
void Peripheral_power_control(void)
{
	switch(peri_power_con.peri_id)
	{
		case 210://����
		{
			if (peri_power_con.peri_state == 7)
			{
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
				Close_ALL_Power();
				Multiple_Can_Send_Msg(zhongshengID,close_total_power);
				peri_power_con.peri_state = 0;
				peri_power_con.peri_id = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
				Multiple_Can_Send_Msg(zhongshengID,restart_total_power);
				peri_power_con.peri_state = 0;
				peri_power_con.peri_id = 0;
			}
		}
		break;
		
		case 211://��챵��
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_SET); //��챵����
//				xTaskNotify(Motor_Task_Handle,Motor_Init_Bit8,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_RESET); //��챵����
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_RESET); //��챵����
//				delay_ms(3000);
//				HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_SET); //��챵����
				xTaskNotify(Motor_Task_Handle,Motor_Init_Bit8,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 212://��������
		{
			if (peri_power_con.peri_state == 7)
			{
				printf("�ش���\r\n");
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);//�����������
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
				printf("������\r\n");
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);//�����������
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
				printf("��������\r\n");
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);//�����������
				motor_info.Cleaning_motor_error_code1 = 0;
				motor_info.Cleaning_motor_error_code2 = 0;
				delay_ms(2000);
				motor_info.Cleaning_motor_error_code1 = 0;
				motor_info.Cleaning_motor_error_code2 = 0;
				delay_ms(1000);
				HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
				motor_info.Cleaning_motor_error_code1 = 0;
				motor_info.Cleaning_motor_error_code2 = 0;
				motor_info.protect_err_code = 0;
			}
		}
		break;
		
		case 213://���еƴ�
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_SET);   //������pdu ���ƣ���ʱ�򻻳�can��485ͨ��ȥ��  ����һ��
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET);
//				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_RESET);
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET);
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_RESET);
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET);
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_RESET);
//				delay_ms(3000);
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_SET);
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET);
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_SET);
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 214://�ƴ�1
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_SET); 
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_RESET);
				delay_ms(3000);
//				HAL_GPIO_WritePin(LED01_CON_GPIO_Port,LED01_CON_Pin,GPIO_PIN_SET);
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 215://�ƴ�2
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET);
//				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_RESET);
//				delay_ms(3000);
//				HAL_GPIO_WritePin(LED02_CON_GPIO_Port,LED02_CON_Pin,GPIO_PIN_SET);
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 216://�ƴ�3
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_SET);
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_RESET);
				delay_ms(3000);
//				HAL_GPIO_WritePin(LED03_CON_GPIO_Port,LED03_CON_Pin,GPIO_PIN_SET);
				xTaskNotify(Light_Control_Task_Handle,light_reboot,eSetBits);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 217://����ƽ��   ps��Ŀǰ55�Ļ���ƽ���·����ʱͬһ·���磬��ͬ�������ء�����
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,FAN_PWR_EN_Pin,GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,FAN_PWR_EN_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,FAN_PWR_EN_Pin,GPIO_PIN_RESET);
//				delay_ms(3000);
//				HAL_GPIO_WritePin(FAN_PWR_EN_GPIO_Port,FAN_PWR_EN_Pin,GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 218://���ػ�
		{
			if (peri_power_con.peri_state == 7)
			{
		//		HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_SET);
				HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
		//		HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET);
				HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
//				HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET);
//				delay_ms(3000);
//				HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_SET);
				HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_RESET);
				delay_ms(3000);
				HAL_GPIO_WritePin(DC_PWR_EN_GPIO_Port, DC_PWR_EN_Pin, GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
		
		case 219://���
		{
			if (peri_power_con.peri_state == 7)
			{
//				HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_SET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 8)
			{
//				HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET);
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
			else if (peri_power_con.peri_state == 9)
			{
				BAT.BAT_Reboot = 0x01;
				peri_power_con.peri_id = 0;
				peri_power_con.peri_state = 0;
			}
		}
		break;
	}
	if(BAT.BAT_Reboot)
	{
		Can_Send_Msg(0XD0,bat_reboot);
	}
}
void Close_ALL_Power(void)
{
//	HAL_GPIO_WritePin(IPC_PWR_EN_GPIO_Port,IPC_PWR_EN_Pin,GPIO_PIN_RESET); //���ػ�

//	HAL_GPIO_WritePin(GPIOB, OUT_KDS_Pin, GPIO_PIN_RESET);//�رմ��ܿ�������Դ
//	HAL_GPIO_WritePin(CORE_EN_GPIO_Port,CORE_EN_Pin,GPIO_PIN_RESET); //breakout�ĵ�Դ
//	HAL_GPIO_WritePin(RTR_PWR_EN_GPIO_Port,RTR_PWR_EN_Pin,GPIO_PIN_RESET); //
    HAL_GPIO_WritePin(GPIOB,OUT_MTR_Pin,GPIO_PIN_RESET);  //��챵����Դ
//	HAL_GPIO_WritePin(GPIOB,FAN_PWR_EN_Pin,GPIO_PIN_RESET);
//	HAL_GPIO_WritePin(RS3_PWR_EN_GPIO_Port,RS3_PWR_EN_Pin,GPIO_PIN_RESET);
//	HAL_GPIO_WritePin(LED_SYS_ALM_GPIO_Port,LED_SYS_ALM_Pin|LED01_CON_Pin|LED02_CON_Pin|LED03_CON_Pin,GPIO_PIN_RESET); //�ر�LED��
//    HAL_GPIO_WritePin(OUT_RS2_GPIO_Port, OUT_RS2_Pin, GPIO_PIN_RESET); 
}
void charge_state(void)     //�ֶ����״̬�ж�
{
//	Flag_Charging_Switch = HAL_GPIO_ReadPin(GPIOA,OUT_CHR_Pin);
	  Flag_Charging_Switch = charge_check_flag ; 
    static uint8_t Manual_charge_state_delay = 0;  //�ֶ����״̬��ʱ��    
    if (BAT.STA == 1)
    {
        if (Manual_charge_state_delay <= 110 && Flag_Charging_Switch == 0)  //���ڳ��״̬����翪��δ�򿪡���ʱʱ�䲻��40 ���ʱ�������ۼ�
            Manual_charge_state_delay ++;
        else if (Flag_Charging_Switch == 1)		//����翪�عر�������ֶ����״̬��ʱ��    
			Manual_charge_state_delay = 0;
		
        if (Flag_Charging_Switch == 0 && Manual_charge_state_delay >= 100)	//��翪�عر� ���� ��ʱ������40 ��Ϊ�ֶ����		
        {
            flag_charge_sta = 2;	//�ֶ����
        }
    }
    else 
    {
        Manual_charge_state_delay = 0;      //����ز��ڳ��״̬������ֶ�����ʱ
    }
	
	if (0x01 == (clean_peripheral_sta & 0x01))  //�������״̬���ֶ����
	{
		flag_charge_sta = 0;
		flag_charge_sta_old = 0;
		clean_peripheral_sta &= 0xfe;
	}
}
void charge_management(void)//���״̬���� ��챵�������� �򿪳�翪���������� ��Ϊ �򿪳�翪�����ڳ��״̬ �Ż�����
{
    if(BAT.Charger_Sta == 1)
    {
          //�򿪳���
//        HAL_GPIO_WritePin(GPIOA,OUT_CHR_Pin,GPIO_PIN_SET); 
//		printf("�򿪳���\r\n");
			//ModbusError_t result;
   if(peripheral_control.Charger_State == 0){
//        ModbusRTU_WriteSingleCoil(0x01, 0x0006, 1); // �ӻ� 0x01����Ȧ��ַ 0x0006��д 1=��
//			  delay_ms(5);

			Can_Send_Msg(chargeID,charge_on);  
		 Multiple_Can_Send_Msg(chargeID,charge_on);	 
		}
        BAT.Charger_Sta = 0;
		if(charge_check_flag){
        peripheral_control.Charger_State =1;
		   }
    }
    else if(BAT.Charger_Sta == 2)
    {
        //�رճ���
    //    HAL_GPIO_WritePin(GPIOA,OUT_CHR_Pin,GPIO_PIN_RESET); 			
//        printf("�رճ���\r\n");	
			
			  if(peripheral_control.Charger_State == 1){
//          ModbusRTU_WriteSingleCoil(0x01, 0x0006, 0); // �ӻ� 0x01����Ȧ��ַ 0x0006��д 1=��
//					delay_ms(5);

//					Can_Send_Msg(chargeID,charge_off);
					Multiple_Can_Send_Msg(chargeID,charge_off);
				}
        BAT.Charger_Sta = 0;		
//        xTaskNotify(Motor_Task_Handle,Recover_Electricity,eSetBits);
//        Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Recover_Electricity_1);
//        Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Recover_Electricity_2);
				if(charge_check_flag == 0){
        peripheral_control.Charger_State =0;
				}
    }
	static uint8_t time = 0;
		time ++;
	if(time >= 10){
	   time = 0;
		Can_Send_Msg(0xcc,charge_query);
	}
	if(charge_check_flag)
	 {
    peripheral_control.Charger_State =1;
	 }else{
	  peripheral_control.Charger_State =0;
	 }
	
	static uint8_t state = 0;
	state %= 4;
	if(peripheral_control.Charger_State && BAT.STA == 1 && state < 3)
	{
		#if (Machine_model == SW55 || Machine_model == SW55L)
        xTaskNotify(Motor_Task_Handle,Reduce_Electricity_6A,eSetBits);
		#elif(Machine_model == SW80)
        xTaskNotify(Motor_Task_Handle,Reduce_Electricity_10A,eSetBits);
		#endif
		state ++; 
		printf("limit current\n");
	}
	else if (peripheral_control.Charger_State == 0 && BAT.STA != 1 && state > 0)
	{
		xTaskNotify(Motor_Task_Handle,Recover_Electricity,eSetBits);
		state --;
		printf("recover current\n");
	}
}
void Motor_Current_Ctrl(void)
{
	if(peripheral_control.Control_Motor_Current == 1)
	{
	    xTaskNotify(Motor_Task_Handle,Reduce_Electricity_10A,eSetBits);
//		Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Reduce_Electricity_10A_1);
//		Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Reduce_Electricity_10A_2);
		peripheral_control.Control_Motor_Current = 0;
		peripheral_control.Motor_Current_State = 1;
	}
	if(peripheral_control.Control_Motor_Current == 2)
	{
		xTaskNotify(Motor_Task_Handle,Recover_Electricity,eSetBits);
//		Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Recover_Electricity_1);
//		Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)Recover_Electricity_2);
		peripheral_control.Control_Motor_Current = 0;
		peripheral_control.Motor_Current_State = 0;		
	}
}
void Automatic_hand_switching(void)
{
    uint32_t notify_val = 0;
    if(peripheral_control.Manual_cleaning == 1) //ʧ�ܵ�����ֶ�ģʽ
    {
		if(low_power_sta == 0){
		xTaskNotify(Motor_Task_Handle,Motor_Disable,eSetBits);
		xTaskNotifyWait(0,Motor_Enable,&notify_val,0);
		}
//        Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)M_Disable_Motor);
//        Multiple_Can_Send_Msg(MOTOR_R_CAN_ID,(uint8_t*)M_Disable_Motor);
        peripheral_control.Manual_cleaning = 0;
        peripheral_control.motor_state = 1;
		    hard_auto_sta = 1;

//		Can_Send_Msg(0x124,num);
    }
    if(peripheral_control.Manual_cleaning == 2) //����ʹ�ܵ��,�Զ�ģʽ
    {
		if (Stop_Mode == 0)
		{
			xTaskNotify(Motor_Task_Handle,Motor_Enable,eSetBits);
			xTaskNotifyWait(0,Motor_Disable,&notify_val,0);
//			Multiple_Can_Send_Msg(MOTOR_L_CAN_ID,(uint8_t*)M_Eable_Motor);
//			Multiple_Can_Send_Msg(MOTOR_R_CAN_ID,(uint8_t*)M_Eable_Motor);
		}
        peripheral_control.Manual_cleaning = 0;
        peripheral_control.motor_state = 0;
		    hard_auto_sta = 0;
    }
		
		if(peripheral_control.Manual_cleaning == 3) //����ʹ�ܵ�� ����͹���ģʽ
		{
			xTaskNotify(Motor_Task_Handle,Motor_Enable,eSetBits);
			xTaskNotifyWait(0,Motor_Disable,&notify_val,0);
			low_power_sta = 1;
			peripheral_control.Manual_cleaning = 0;
		}
		if(peripheral_control.Manual_cleaning == 4) //ʧ�ܵ��  �˳��͹���ģʽ
		{
//		  xTaskNotify(Motor_Task_Handle,Motor_Disable,eSetBits);
//		  xTaskNotifyWait(0,Motor_Enable,&notify_val,0);
			low_power_sta = 0;
			peripheral_control.Manual_cleaning = 0;
		}
}

//void Read_Hand_Auto_Switch_Button(void)
//{
//	if(HAL_GPIO_ReadPin(IN_STB_GPIO_Port, IN_STB_Pin) == RESET)
//	{
//		 HAL_Delay(2);
//		if(HAL_GPIO_ReadPin(IN_STB_GPIO_Port, IN_STB_Pin) == RESET)
//		{
//			Manual_cleaning_cnt = 1;
//		}
//	}
//	else Manual_cleaning_cnt = 0;
//	
//}

void spray_Liquid_level_calibration(void)//����ˮλУ׼��ˮ�ÿ�����Լ14������䣩
{
    static int times_l = 0,times_r = 0,upload_times_l = 0,upload_times_r = 0;
    static int Liquid_level_l_old_open,Liquid_level_r_old_open;
    static int Liquid_level_l_old_close,Liquid_level_r_old_close;
    static uint8_t flag_l = 0,flag_r = 0;
    uint8_t spray_state_l,spray_state_r;
    float level_l = 0,level_r = 0;
    level_l = (float)Atomization_l.Liquid_level;
    level_r = (float)Atomization_r.Liquid_level;
    spray_state_l = Atomization_l.state;
    spray_state_r = Atomization_r.state;
    
    if (times_l < 500 && ((spray_state_l == 1 && flag_l == 0) || (spray_state_l == 0 && flag_l == 1)))
    {
        times_l ++;
    }
    else if ((spray_state_l == 1 && flag_l == 1) || (spray_state_l == 0 && flag_l == 0))
    {
        times_l = 0;
    }
    
    if (times_r < 500 && ((spray_state_r == 1 && flag_r == 0) || (spray_state_r == 0 && flag_r == 1)))
    {
        times_r ++;
    }
    else if ((spray_state_r == 1 && flag_r == 1) || (spray_state_r == 0 && flag_r == 0))
    {
        times_r = 0;
    }
    
    
    if ((level_r - Liquid_level_r_old_open > 5 && times_r > 80 && times_r < 200) || flag_r == 1)
    {
        float error_r = 0.451 * level_r - 20.257;
        if (error_r < 0 || error_r >= 80)
        error_r = 0;
        
        flag_r = 1;
        level_r = level_r - error_r;
    }
    
    if ((level_l - Liquid_level_l_old_open > 5 && times_l > 80 && times_l < 200) || flag_l == 1)
    {
        float error_l = 0.3936 * level_l - 16.795;
        if (error_l < 0 || error_l >= 80)
        error_l = 0;
        
        flag_l = 1;
        level_l = level_l - error_l;
    }
    
    if (Liquid_level_l_old_close - level_l > 5 && times_l > 80 && times_l < 200 && flag_l == 1 && spray_state_l == 0)
    {
        flag_l = 0;
    }
    else if(flag_l == 1 && spray_state_l == 0 && times_l > 300)
    {
        flag_l = 0;
    }
    
    if (Liquid_level_r_old_close - level_r > 5 && times_r > 80 && times_r < 200 && flag_r == 1 && spray_state_r == 0)
    {
        flag_r = 0;
    }
    else if(flag_r == 1 && spray_state_r == 0 && times_r > 300)
    {
        flag_r = 0;
    }
    
	
	if ((spray_state_l == 1 && flag_l == 1) || (spray_state_l == 0 && flag_l == 0))
	{
		if (upload_times_l <= 100)
		{
			Liquid_level_l =(int)level_l;
			upload_times_l ++;
		}
		else if (upload_times_l > 100 && upload_times_l < 160)
			upload_times_l ++;
		else
			Liquid_level_l =(int)level_l;
	}
	else if (spray_state_l == 1 && flag_l == 0)
	{
		upload_times_l = 110;
		Liquid_level_l = Liquid_level_l_old_open;
	}
	else 
	{
		upload_times_l = 110;
		Liquid_level_l = Liquid_level_l_old_close;
	}
		
	if ((spray_state_r == 1 && flag_r == 1) || (spray_state_r == 0 && flag_r == 0))
	{
		if (upload_times_r <= 100)
		{
			Liquid_level_r =(int)level_r;
			upload_times_r ++;
		}
		else if (upload_times_r > 100 && upload_times_r < 160)
			upload_times_r ++;
		else
			Liquid_level_r =(int)level_r;
	}
	else if (spray_state_r == 1 && flag_r == 0)
	{
		upload_times_r = 110;
		Liquid_level_r = Liquid_level_r_old_open;
	}
	else 
	{
		upload_times_r = 110;
		Liquid_level_r = Liquid_level_r_old_close;
	}
		
	
	
	if(spray_state_l == 0 && flag_l == 0)
		Liquid_level_l_old_open = Liquid_level_l;
	else if(spray_state_l == 1 && flag_l == 1)
		Liquid_level_l_old_close = Liquid_level_l;
	
	if(spray_state_r == 0 && flag_r == 0)
		Liquid_level_r_old_open = Liquid_level_r;
	else if(spray_state_r == 1 && flag_r == 1)
		Liquid_level_r_old_close = Liquid_level_r;
}
