#include "Ultrasonic_Task.h"

#if (Machine_model == SW55 || Machine_model == SW55L)

/*****KS114�ĵ�ַID*****/
#define KS114_fis_ID 0xd0 //�豸��ǰ��������
#define KS114_sec_ID 0xd2  //�豸ǰ���������
#define KS114_thi_ID 0xd4    //�豸ǰ�������ұ�

#define KS114_dis_order0 0x0f		//��Ч̽�ⷶΧ 1cm-110cm��
#define KS114_dis_order1 0x1e		//��Ч̽�ⷶΧ 3cm-3m��

uint8_t send1[3] = {KS114_fis_ID,0x02,KS114_dis_order1};		
uint8_t send2[3] = {KS114_sec_ID,0x02,KS114_dis_order1}; 	
uint8_t send3[3] = {KS114_thi_ID,0x02,KS114_dis_order1}; 	

#elif(Machine_model == SW80)

/*****��Ӧ��A02�ĵ�ַID*****/
#define A02_fis_ID 0x11 //�豸��ǰ��������
#define A02_sec_ID 0x12  //�豸ǰ���������
#endif
Ultrasonic_sensor_ Ultrasonic_sensor = {0};

static uint8_t Ultrasonic_ID = 0;
volatile uint8_t recv_end_flag_usart3 = 0; //һ֡���ݽ�����ɱ�־
volatile uint8_t rx_len_usart3  = 0; //���յ������ݸ���
ModbusMessage_t KS114_receive_se;
uint8_t KS114_receive[BUFFER_SIZE_USART3] = {0};						//KS114_get_data_one�����Ľ�������
//int dis = 0;
QueueHandle_t ultrasonicQueue;
void Ultrasonic_Task(void const * argument)
{
	delay_ms(2000);
//	HAL_GPIO_WritePin(RS3_PWR_EN_GPIO_Port,RS3_PWR_EN_Pin,GPIO_PIN_SET);  
//	__HAL_UART_ENABLE_IT(&huart3, UART_IT_RXNE); //ʹ��IDLE�ж�
//	__HAL_UART_ENABLE_IT(&huart3, UART_IT_IDLE); //ʹ��IDLE�ж�
//	HAL_UART_Receive_DMA(&huart3, KS114_receive, BUFFER_SIZE_USART3);
	const TickType_t Ultrasonic_TimeIncrement = pdMS_TO_TICKS(50);//��ʱ50ms������ʱʱ��ת��Ϊ������
	TickType_t lasttick = xTaskGetTickCount();
	#if (Machine_model == SW80)
	set_crc();
	#endif
   #if (Machine_model == SW55 || Machine_model == SW55L)
   // setUltrasonicRadarDistanceResponse();
	     KS114_Configure_Protocol_0x8B();
	delay_ms(2000); //�ȴ�2�볬��������

	#endif
	
	while(1)
	{
		
		MY_ERROR.tasks_heart.ultrasonic = 0;
		#if (Machine_model == SW55 || Machine_model == SW55L)
		
		Ultrasonic_ID ++;
	//	KS114_get_one_data(Ultrasonic_ID);
	 if (MODBUS_OK == KS114_SendRequest(Ultrasonic_ID)){
	    Ultrasonic_sensor.data_1 = KS114_Revice;
	 	 MY_ERROR.module_heart.ultrasonic = 0;
     	}
		
		if(Ultrasonic_ID>3)
		Ultrasonic_ID = 0;
//		if(recv_end_flag_usart3 == 1)
//		{
//			if(KS114_receive[0] == KS114_fis_ID)
//			{
//				Ultrasonic_sensor.data_1 = (KS114_receive[1]<<8|KS114_receive[2]);
//				printf("���������ݣ�%d",Ultrasonic_sensor.data_1);
//				
//			}
////			printf("����������");
////			else if(KS114_receive[0] == KS114_sec_ID)
////			{
////				Ultrasonic_sensor.data_2 = (KS114_receive[1]<<8|KS114_receive[2]);
////			}
////			else if(KS114_receive[0] == KS114_thi_ID)
////			{
////				Ultrasonic_sensor.data_3 = (KS114_receive[1]<<8|KS114_receive[2]);
////			}
//			
////		    Ultrasonic_sensor.data_1 = KS114_receive[0]<<8|KS114_receive[1];
////			dis = (KS114_receive[1]<<8|KS114_receive[2]);
////			printf("ID=0x%x dis=%d\r\n",KS114_receive[0],dis);
//			memset(KS114_receive,0,sizeof(KS114_receive));
//		//	rx_len_usart3 = 0;//�������
//			recv_end_flag_usart3 = 0;//������ս�����־λ
//			
//		
//			
//			MY_ERROR.module_heart.ultrasonic = 0;
//		}
//		if (xQueueReceive(ultrasonicQueue, &KS114_receive_se, pdMS_TO_TICKS(10)) == pdTRUE){
//		  if(KS114_receive_se.buffer[0] == KS114_fis_ID){
//			Ultrasonic_sensor.data_1 = (KS114_receive_se.buffer[1]<<8|KS114_receive_se.buffer[2]);
//			}
//			
//			
//			MY_ERROR.module_heart.ultrasonic = 0;
//		}
		#elif(Machine_model == SW80)
		
		Ultrasonic_ID++;
		A02_get_one_data(Ultrasonic_ID); 
		if(Ultrasonic_ID>2)
		Ultrasonic_ID = 0;
		if(recv_end_flag_usart3 == 1)
		{
			if(KS114_receive[0] == A02_fis_ID)
			{
				Ultrasonic_sensor.data_1 = (KS114_receive[3]<<8|KS114_receive[4]);
				printf("Ultrasonic_sensor.data_1 = %d\r\n",Ultrasonic_sensor.data_1);
			}
			if(KS114_receive[0] == A02_sec_ID)
			{
				Ultrasonic_sensor.data_2 = (KS114_receive[3]<<8|KS114_receive[4]);
			}
			memset(KS114_receive,0,rx_len_usart3);
			rx_len_usart3 = 0;//�������
			recv_end_flag_usart3 = 0;//������ս�����־λ
			HAL_UART_Receive_DMA(&huart3, KS114_receive, BUFFER_SIZE_USART3);
		}
		#endif
		
		
        vTaskDelayUntil(&lasttick, Ultrasonic_TimeIncrement);//��50HZ��Ƶ������
	}
}


#if (Machine_model == SW55 || Machine_model == SW55L)
/**------------------------------------------
  *��  �ܣ���ȡһ����������������õľ���
  *��  ����ѡ��ڼ��ų�����������
  *����ֵ����
*///-----------------------------------------
void KS114_get_one_data(int num)
{
  HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);					//����ģʽ
	delay_ms(2);
	switch(num)
	{
		case 1:
				HAL_UART_Transmit_DMA(&huart3,(uint8_t*)&send1,sizeof(send1));
		    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
			break;
		case 2:
//				HAL_UART_Transmit_DMA(&huart3,(uint8_t*)&send2,sizeof(send2));
//		    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
			break;
		case 3:
//				HAL_UART_Transmit_DMA(&huart3,(uint8_t*)&send3,sizeof(send3));
//		    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
			break;
	}
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);				//����ģʽ
	delay_ms(20);
}


#elif(Machine_model == SW80)
uint8_t A02_1[8] = {A02_fis_ID,0x03,0x01,0x00,0x00,0x01,0x00,0x00};
uint8_t A02_2[8] = {A02_sec_ID,0x03,0x01,0x00,0x00,0x01,0x00,0x00};

void set_crc(void)
{
	A02_1[6] = crc16table(A02_1,6);
	A02_1[7] = crc16table(A02_1,6)>>8;
	A02_2[6] = crc16table(A02_2,6);
	A02_2[7] = crc16table(A02_2,6)>>8;
}

void A02_get_one_data(int num)
{
  HAL_GPIO_WritePin(RS485_DE_GPIO_Port,RS485_DE_Pin,GPIO_PIN_SET);					//����ģʽ
	delay_ms(2);
	switch(num)
	{
		case 1:
				HAL_UART_Transmit_DMA(&huart3,(uint8_t*)&A02_1,sizeof(A02_1));
		    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
			break;
		case 2:
				HAL_UART_Transmit_DMA(&huart3,(uint8_t*)&A02_2,sizeof(A02_2));
		    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
			break;
	}
	HAL_GPIO_WritePin(RS485_DE_GPIO_Port,RS485_DE_Pin,GPIO_PIN_RESET);				//����ģʽ
	delay_ms(100);
}
#endif

#if (Machine_model == SW55 || Machine_model == SW55L)
bool sendAndReceive(uint8_t* txData, uint16_t txLen, uint16_t waitTimeMs, uint8_t* rxData, uint16_t rxLen, uint8_t* expected, uint8_t expectedLen) {
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET); // ����ģʽ
    delay_ms(5);
    HAL_UART_Transmit_DMA(&huart3, txData, txLen);
    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET); // ����ģʽ
    delay_ms(5);

    HAL_UART_Receive_DMA(&huart3, KS114_receive, BUFFER_SIZE_USART3);
    delay_ms(waitTimeMs);

    if (recv_end_flag_usart3 == 1) {
        recv_end_flag_usart3 = 0;
       	HAL_UART_Receive_DMA(&huart3, KS114_receive, BUFFER_SIZE_USART3);
        if (expected != NULL && expectedLen > 0) {
            for (int i = 0; i < expectedLen; i++) {
                if (rxData[i] != expected[i]) return false;
            }
        }
        return true;
    }
    return false;
}

void setUltrasonicRadarDistanceResponse(void){
    uint8_t setConfigRxDaata[2] = {0x00};
    uint8_t ultrasoundRadarArray[3] = {KS114_fis_ID, 0x02, 0x9c};

    // ��һ�η��� send1 ָ��
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_SET);					//����ģʽ
    delay_ms(5);
    HAL_UART_Transmit_DMA(&huart3, (uint8_t*)&send1, sizeof(send1));
    while (RESET == __HAL_UART_GET_FLAG(&huart3, UART_FLAG_TC));
    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);				//����ģʽ
    delay_ms(150);

    if (recv_end_flag_usart3 == 1 && KS114_receive[0] == KS114_fis_ID) {
        memset(KS114_receive, 0, rx_len_usart3);
        recv_end_flag_usart3 = 0;
        HAL_UART_Receive_DMA(&huart3, KS114_receive, BUFFER_SIZE_USART3);
        return;
    }

    // ���� 0x9C ָ�������� 3 ��
    for (int i = 0; i < 3; i++) {
        if (sendAndReceive(ultrasoundRadarArray, sizeof(ultrasoundRadarArray), 150, KS114_receive, BUFFER_SIZE_USART3, NULL, 0)) {
            setConfigRxDaata[0] = KS114_receive[0];
            setConfigRxDaata[1] = KS114_receive[1];
            break;
        }
    }

    // ��װ��� expected ��Ӧ
    uint8_t expectedResponse[2] = {setConfigRxDaata[0], setConfigRxDaata[1]};

    // ���η��� 0x95, 0x98, 0x8B ָ��
    uint8_t configCodes[] = {0x95, 0x98, 0x8B};
    for (int j = 0; j < 3; j++) {
        ultrasoundRadarArray[2] = configCodes[j];
        for (int i = 0; i < 3; i++) {
            if (sendAndReceive(ultrasoundRadarArray, sizeof(ultrasoundRadarArray), 150, KS114_receive, BUFFER_SIZE_USART3, expectedResponse, 2)) {
                memset(KS114_receive, 0, rx_len_usart3);
                break;
            }
        }
    }

   HAL_GPIO_WritePin(GPIOB,GPIO_PIN_12,GPIO_PIN_RESET);
    delay_ms(2000);
}
#endif


