#ifndef __ULTRASONIC_TASK_H__
#define __ULTRASONIC_TASK_H__
#include "can.h"
#include "Motor_Task.h"
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>
#include "usart.h"
#include "crc.h"
#include <stdbool.h>
#include "modbus_rtu_master.h"
#define BUFFER_SIZE_USART3  10  //�����������ֽ���10



typedef struct
{
  uint16_t  data_1;
  uint16_t  data_2;
  uint16_t  data_3;
}
Ultrasonic_sensor_;
extern Ultrasonic_sensor_ Ultrasonic_sensor;


//extern volatile uint8_t recv_end_flag_usart3; //һ֡���ݽ�����ɱ�־
extern volatile uint8_t rx_len_usart3;
void Ultrasonic_Task(void const * argument);

#if (Machine_model == SW55 || Machine_model == SW55L)
void KS114_get_one_data(int num);
void setUltrasonicRadarDistanceResponse(void);
#elif(Machine_model == SW80)
void set_crc(void);
void A02_get_one_data(int num);
#endif




#endif



